"""RUN THE TREE'S OWN bin/riffle-sign, SANDBOXED: never with riffle's real key.

usage (as a program, exactly like riffle-sign):
    python3 tests/lib/sandboxed_riffle_sign.py pubkey
    python3 tests/lib/sandboxed_riffle_sign.py seal --hash ... --label ...
    python3 tests/lib/sandboxed_riffle_sign.py payout --row listing-16 ...

The real signer reads its key from /var/lib/riffle-signer/citizen.seed, its
limits from /etc/riffle/payout.conf, and appends to
/var/lib/riffle-signer/signatures.log. On the operator's box those are the
REAL key and the REAL audit log. This loads the tree's bin/riffle-sign as a
module and points all four (seed, config, log, and the directories it loads
keyutil.py and ed25519_pure.py from) at $RIFFLE_SIGNER_SANDBOX, a directory
tests/run_all.sh creates for each run with a FRESH RANDOM seed and copies of
the tree's own key libraries. Every signature a test makes is with that
throwaway key.

payout.conf is written for each call from the environment, so a test can
vary it:
    RS_CEIL      max_amount_atomic value ("none", a number, or "-" to omit it)
    RS_ADDR      the payout address in payout.conf
For `payout` and `wallet`, riffle-sign fetches the exact bytes to sign from
the registry. Here that fetch is answered by the registry's OWN message
builders, extracted from its source (see extract_registry_message_builders.sh)
and pointed to by RIFFLE_REGISTRY_MESSAGES. Without them, those two commands
exit 77 ("skipped"), and a test that needs them says so:
    RS_PRICE     the listing price the "registry" quotes
    RS_REG_ADDR  the address the "registry" puts in the preimage (default:
                 the one asked for), to test a mismatch

CHANGELOG
  2026-10-29  Written in the sandbox as signer_wrap.py for Q4 (wiring payout
              signing), against a test seed left in /tmp/sigenv by an earlier
              session.
  2026-11-05  Moved into tests/lib and made safe to run anywhere: a fresh seed
              per run in $RIFFLE_SIGNER_SANDBOX instead of whatever sat in
              /tmp/sigenv; the tree's own bin/riffle-sign instead of a
              hard-coded sandbox path; and the registry extract found through
              RIFFLE_REGISTRY_MESSAGES, with a clean "skip" when it is absent.
"""
import os as _os, sys as _sys  # noqa: E401
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
__import__("riffle_test_safety_net")  # the safety net, however this is started
import importlib.machinery
import importlib.util
import json
import os
import subprocess
import sys
import urllib.parse

SANDBOX = os.environ.get("RIFFLE_SIGNER_SANDBOX")
if not SANDBOX or not os.path.isfile(os.path.join(SANDBOX, "seed")):
    sys.exit("sandboxed_riffle_sign: RIFFLE_SIGNER_SANDBOX is not set up "
             "(run through tests/run_all.sh)")
TREE = os.environ.get("RIFFLE_TREE", ".")
src = os.environ.get("RS_SRC", os.path.join(TREE, "bin", "riffle-sign"))
ld = importlib.machinery.SourceFileLoader("rs", src)
spec = importlib.util.spec_from_loader("rs", ld)
rs = importlib.util.module_from_spec(spec)
ld.exec_module(rs)

addr = os.environ.get("RS_ADDR", "0x0c19bf942294235e53b35af0198f1b629c5f7080")
conf = ["handle=riffle", f"address={addr}",
        "allowed_rows=listing-*,listing-*-verifier"]
if os.environ.get("RS_CEIL", "none") != "-":
    conf.append(f"max_amount_atomic={os.environ.get('RS_CEIL', 'none')}")
with open(os.path.join(SANDBOX, "payout.conf"), "w") as f:
    f.write("\n".join(conf) + "\n")
rs.CONF_PATH = os.path.join(SANDBOX, "payout.conf")
rs.SEED_PATH = os.path.join(SANDBOX, "seed")
rs.LOG_PATH = os.path.join(SANDBOX, "signatures.log")
rs._KEYUTIL_DIRS = (os.path.join(SANDBOX, "lib"),)


def _registry(case):
    ts = os.environ.get("RIFFLE_REGISTRY_MESSAGES")
    if not ts or not os.path.isfile(ts):
        print("SKIPPED: needs the registry's message builders "
              "(RIFFLE_REGISTRY_MESSAGES; see tests/lib/"
              "extract_registry_message_builders.sh)", file=sys.stderr)
        sys.exit(77)
    out = subprocess.run(["node", "--experimental-strip-types", ts, json.dumps([case])],
                         capture_output=True, text=True)
    return json.loads(out.stdout)[0]


def fetch(url):
    q = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(url).query))
    a = os.environ.get("RS_REG_ADDR", q.get("address"))
    if "/api/payout-wallets/preimage" in url:
        return {"preimage": _registry({"kind": "wallet", "handle": q["handle"],
                                       "chain": 8453, "address": a,
                                       "expiry": int(q["expiry"])})}
    return {"preimage": _registry({"kind": "payout", "handle": q["handle"],
                                   "row": q["row"],
                                   "amount": os.environ.get("RS_PRICE", "1000000"),
                                   "chain": 8453, "token": rs.USDC, "address": a,
                                   "expiry": int(q["expiry"])})}


rs.fetch = fetch
sys.argv = ["riffle-sign"] + sys.argv[1:]
rs.main()
