"""Loads the test safety net (riffle_test_safety_net.py) into every Python
process tests/run_all.sh starts: Python imports `sitecustomize` at startup,
and the runner puts tests/lib first on PYTHONPATH. Test files also import the
net by its own name, since a system `sitecustomize` (Debian ships one) would
otherwise be loaded instead when a test is started directly.

CHANGELOG
  2026-11-05  The net's code moved to riffle_test_safety_net.py; this file
              only loads it.
"""
__import__("riffle_test_safety_net")
