#!/bin/bash
# RUN ONE OF update.sh's DEPLOY GATES, EXACTLY AS update.sh RUNS IT.
#
# usage: run_one_update_sh_gate.sh <path to update.sh> <MARKER>
#   e.g. run_one_update_sh_gate.sh ./update.sh PYFIT
#
# update.sh keeps each gate as a Python heredoc (python3 - <<'PYFIT' ... PYFIT).
# This pulls out the body between the two markers and runs it with python3,
# in the current directory, which must be a tree with a config.yaml (the
# runner copies config.example.yaml into its temporary copy of the tree; it
# never touches a real config). Prints the gate's own output, then one line:
# "=> gate passed", or "=> GATE FAILED (update.sh would roll back)".
#
# CHANGELOG
#   2026-10-23  Written in the sandbox as rungate.sh, so every deploy gate
#               could be run on its own against a change before handing it
#               over, the same way update.sh would on the box.
#   2026-11-05  Moved into tests/lib; unchanged in what it does.
src=$1; m=$2
body=$(awk -v m="$m" '$0 ~ "<<.?"m"'"'"'?$" {on=1; next} on && $0==m {exit} on' "$src")
if ! python3 - <<<"$body"; then echo "=> GATE FAILED (update.sh would roll back)"; else echo "=> gate passed"; fi
