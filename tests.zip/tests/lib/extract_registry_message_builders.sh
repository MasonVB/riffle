#!/bin/bash
# BUILD THE REGISTRY'S OWN MESSAGE BUILDERS, for the signing tests.
#
# usage: extract_registry_message_builders.sh <registry checkout> <output .ts>
#   then: export RIFFLE_REGISTRY_MESSAGES=<output .ts>   (and have node >= 22)
#
# A signature only counts if riffle signs exactly the bytes the registry will
# check. The signing tests (tests/signing_and_payouts/) therefore verify
# riffle-sign's output against the registry's OWN code, not a copy of our
# understanding of it. This copies, VERBATIM, the handful of functions that
# build those bytes (jcs, attestationPayload, signedMessage, sealMessage,
# payoutPreimage, payoutWalletPreimage and the version constants) out of a
# checkout of the registry's source, into one file node can run.
#
# The extract is NOT committed to this repository: it is the registry's code,
# and its licence is the registry's to state. Without it, the tests that need
# it print "SKIPPED" and say why.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (extract.sh) for Q4, reading a fixed
#               checkout path and writing /tmp/regfn/registry_messages.ts.
#   2026-11-05  Moved into tests/lib; both paths are arguments.
set -euo pipefail
reg=${1:?usage: $0 <registry checkout> <output .ts>}; out=${2:?usage: $0 <registry checkout> <output .ts>}
cd "$reg"
grab() {  # file, start-regex: from the matching line to the next line that is exactly "}"
  local a; a=$(grep -n "$2" "$1" | head -1 | cut -d: -f1)
  local b; b=$(awk -v a="$a" 'NR>a && /^}$/ {print NR; exit}' "$1")
  [ -n "$a" ] && [ -n "$b" ] || { echo "MISSING $2 in $1" >&2; exit 1; }
  sed -n "${a},${b}p" "$1"
}
{
  echo 'class SocietyError extends Error { constructor(s: number, m: string) { super(m); } }'
  grep -h '^export const ATTESTATION_SIG_PREFIX' src/attestations.ts
  grep -h '^export const SEAL_SIG_PREFIX =' src/seals.ts
  grab src/attestations.ts '^export function jcs'
  grab src/attestations.ts '^export function attestationPayload'
  grab src/attestations.ts '^export function signedMessage'
  grab src/seals.ts '^export function sealMessage'
  grep -h '^export const PAYOUT_VERSION =' src/payouts.ts
  grep -h '^export const PAYOUT_WALLET_VERSION =' src/payouts.ts
  grab src/payouts.ts '^export function payoutPreimage'
  grab src/payouts.ts '^export function payoutWalletPreimage'
  cat <<'EOF'
const cases = JSON.parse(process.argv[2]);
console.log(JSON.stringify(cases.map((c: any) =>
  c.kind === "seal" ? sealMessage(c.handle, c.label, c.hash)
  : c.kind === "payout" ? payoutPreimage({handle: c.handle, row: c.row, amountAtomic: c.amount, chainId: c.chain, token: c.token, address: c.address, expiry: c.expiry})
  : c.kind === "wallet" ? payoutWalletPreimage({handle: c.handle, chainId: c.chain, address: c.address, expiry: c.expiry})
  : signedMessage(c.issuer, attestationPayload(c.cls, c.subject, c.claim.trim(), c.evidence, c.issuer, null, null)))));
EOF
} > "$out"
echo "wrote $out: $(grep -c '^export' "$out") exported builders"
