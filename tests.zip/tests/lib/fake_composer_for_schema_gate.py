"""A FAKE COMPOSER for testing update.sh's gate 5 (the schema gate).

usage: python3 fake_composer_for_schema_gate.py <accept|refuse> <port>

Gate 5 asks the RUNNING composer to compile riffle's proposal schema exactly
as the cycle sends it: POST /v1/chat/completions with response_format
json_schema. This answers that request like llama-server would: 200 when it
accepts the schema, 400 "failed to parse grammar" when told to refuse (or
when the request is not shaped like the cycle's), so the gate test can show
the gate passes on one and fails on the other. Runs until killed.

CHANGELOG
  2026-10-31  Written in the sandbox (tgate5.py) for L21, when gate 5 learned
              to ask the live composer instead of only a Python stand-in for
              llama.cpp's C++ converter. Port fixed at 18099.
  2026-11-05  Moved into tests/lib; the port is an argument, so the test can
              pick a free one instead of assuming 18099 is unused.
"""
import os as _os, sys as _sys  # noqa: E401
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
__import__("riffle_test_safety_net")  # the safety net, however this is started
import http.server
import json
import sys

mode, port = sys.argv[1], int(sys.argv[2])


class H(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n))
        rf = body.get("response_format", {})
        ok = rf.get("type") == "json_schema" and "schema" in rf.get("json_schema", {})
        code = 400 if mode == "refuse" or not ok else 200
        msg = (b'{"error":{"message":"failed to parse grammar: unsupported keyword"}}'
               if code == 400 else b'{"choices":[{"message":{"content":"{}"}}]}')
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(msg)

    def log_message(self, *a):
        pass


http.server.HTTPServer(("127.0.0.1", port), H).serve_forever()
