"""THE SAFETY NET, loaded into EVERY Python process a test starts, two ways:
tests/run_all.sh puts tests/lib first on PYTHONPATH, where sitecustomize.py
(which Python imports at startup) loads this; and every test file imports it
by this name at its top, so it is there however a test is started. It does
two things, and refuses outright under riffle's own accounts.

1. A FIXED RANDOM SEED, so a test that shuffles or samples gives the same
   output every run, and two versions of riffle can be compared line by line.

2. A SAFETY NET, so a test can never act on the real riffle, whatever it does
   by mistake. The tests are written to use only temporary directories and
   stand-ins; this is the second layer, for the day one of them is wrong.
   It REFUSES, with an error that says why:
     - writing, creating, deleting, renaming or changing permissions under
       /opt/riffle, /var/lib/riffle* (the agent's data, the signer's key and
       log, the build workspace), /etc, /usr/local, /usr/lib and /root;
     - opening a SQLite database under those paths (riffle's real state);
     - network connections to anything but loopback, and on loopback to the
       ports riffle's own services use: 80 (dashboard), 8080 (composer),
       8081 (triage), 8888 (SearXNG). Tests use their own servers on other
       ports. Add ports with RIFFLE_TESTS_BLOCKED_PORTS=1234,5678;
     - running `sudo` at all, the installed signer, build sandbox or page
       reader under /usr/local/bin, and any `systemctl` that changes a unit
       (start, stop, restart, enable, ...), unless the program is one of the
       stand-ins in tests/lib. Code under test that tries (the cycle's
       situation check runs `sudo -n ... riffle-sign pubkey`) gets this
       refusal as its error, the same on every machine.
   Reading is never refused: tests read config.example.yaml, /etc/ssl and so
   on freely.

Shell tests cannot be covered by a Python module; they are written to touch
only their own temporary directories, and the runner works on a copy of the
tree, never the tree itself.

CHANGELOG
  2026-10-23  Started as seed/sitecustomize.py in the sandbox: the fixed
              random seed only, so the back-to-back comparison of two
              versions of riffle was not upset by random sampling.
  2026-11-05  Moved into tests/lib and given the safety net. Packaging the
              suite for the operator's box showed that three tests, as
              written for the sandbox, would have deleted /opt/riffle and the
              build workspace and restarted the real composer, and that any
              missed stub would have reached the real registry or composer.
              The tests were fixed; this makes sure the next mistake fails
              loudly instead.
  2026-11-05  The program guard resolves a bare name through PATH before
              judging it: it refused riffle-build's `systemctl stop` even
              though PATH led to the test's stand-in, and riffle-build caught
              the refusal, so the build test silently lost its stop calls.
  2026-11-05  Refuses `sudo` and the installed riffle programs outright (it
              allowed the read-only `riffle-sign pubkey`): the cycle's
              situation check ran it through `sudo -n`, whose answer depends
              on whether sudo has the operator's password cached, so a test's
              output differed by machine and by moment.
  2026-11-05  Refuses to run at all as riffle, riffle-signer or riffle-build:
              the suite is kept zipped as a record, and riffle must never run
              it. Every test also imports this module itself, so the net is
              there however a test is started.
  2026-11-05  Renamed from sitecustomize.py. Debian ships its own
              sitecustomize, which Python loads at startup, so a test started
              directly that imported "sitecustomize" got Debian's module and
              ran with no net at all: shown by a test run directly as the
              riffle user, which ran. sitecustomize.py now only loads this.
"""
import builtins
import os
import pwd
import random
import shutil
import socket
import sqlite3
import subprocess

# NEVER AS ONE OF RIFFLE'S OWN ACCOUNTS. These tests are a record for whoever
# works on riffle next, kept zipped in the repository; riffle itself must never
# run them. Python catches ordinary exceptions raised in sitecustomize and
# carries on, so this exits the process outright.
_ME = pwd.getpwuid(os.getuid()).pw_name
if _ME in ("riffle", "riffle-signer", "riffle-build"):
    import sys as _sys
    _sys.stderr.write(f"refused: riffle's tests are a record, never run by riffle itself ({_ME})\n")
    _sys.stderr.flush()
    os._exit(2)

random.seed(20261027)

_NO_WRITE = ("/opt/riffle", "/var/lib/riffle", "/etc/", "/usr/local/",
             "/usr/lib/", "/root/")
_BLOCKED_PORTS = {80, 8080, 8081, 8888} | {
    int(p) for p in os.environ.get("RIFFLE_TESTS_BLOCKED_PORTS", "").split(",")
    if p.strip().isdigit()}
_TESTS = os.path.realpath(os.environ.get("RIFFLE_TESTS", os.path.dirname(os.path.dirname(__file__))))


class RefusedByTestSafetyNet(PermissionError):
    pass


def _protected(path):
    try:
        p = os.path.realpath(os.fspath(path))
    except TypeError:
        return False                      # a file descriptor, not a path
    return p.startswith(_NO_WRITE) or p in ("/opt/riffle", "/var/lib/riffle")


def _refuse(what, path):
    raise RefusedByTestSafetyNet(
        f"the test safety net refused to {what} {path!r}: tests must "
        f"never touch the real riffle. Use a temporary directory.")


# --- files -------------------------------------------------------------------
_real_open = builtins.open


def _open(file, mode="r", *a, **k):
    if any(c in mode for c in "wax+") and _protected(file):
        _refuse("write", file)
    return _real_open(file, mode, *a, **k)


builtins.open = _open


def _guard(fn, what, n_paths=1):
    def wrapped(*a, **k):
        for p in a[:n_paths]:
            if _protected(p):
                _refuse(what, p)
        return fn(*a, **k)
    return wrapped


for _name, _what, _n in (("remove", "delete", 1), ("unlink", "delete", 1),
                         ("rmdir", "delete", 1), ("mkdir", "create", 1),
                         ("makedirs", "create", 1), ("rename", "rename", 2),
                         ("replace", "rename", 2), ("chmod", "change", 1),
                         ("chown", "change", 1), ("truncate", "truncate", 1)):
    if hasattr(os, _name):
        setattr(os, _name, _guard(getattr(os, _name), _what, _n))
shutil.rmtree = _guard(shutil.rmtree, "delete")
shutil.move = _guard(shutil.move, "move", 2)

_real_connect_db = sqlite3.connect


def _connect_db(database, *a, **k):
    name = os.fspath(database) if not isinstance(database, int) else ""
    if name.startswith("file:"):
        name = name[5:].split("?", 1)[0]
    if name and name != ":memory:" and _protected(name):
        _refuse("open the database", name)
    return _real_connect_db(database, *a, **k)


sqlite3.connect = _connect_db


# --- network -----------------------------------------------------------------
def _check_addr(address):
    if not isinstance(address, tuple) or len(address) < 2:
        return                                     # a Unix socket path
    host, port = address[0], address[1]
    try:
        ips = {ai[4][0] for ai in socket.getaddrinfo(host, port)}
    except Exception:
        ips = {str(host)}
    for ip in ips:
        loop = ip.startswith("127.") or ip == "::1"
        if not loop:
            raise RefusedByTestSafetyNet(
                f"the test safety net refused a connection to {host}:{port}: "
                f"tests may only use loopback (no registry, no internet).")
        if int(port) in _BLOCKED_PORTS:
            raise RefusedByTestSafetyNet(
                f"the test safety net refused a connection to {host}:{port}: "
                f"that is one of riffle's own services. Tests run their own "
                f"servers on other ports.")


_real_sock_connect = socket.socket.connect
_real_sock_connect_ex = socket.socket.connect_ex


def _sock_connect(self, address):
    if self.family in (socket.AF_INET, socket.AF_INET6):
        _check_addr(address)
    return _real_sock_connect(self, address)


def _sock_connect_ex(self, address):
    if self.family in (socket.AF_INET, socket.AF_INET6):
        _check_addr(address)
    return _real_sock_connect_ex(self, address)


socket.socket.connect = _sock_connect
socket.socket.connect_ex = _sock_connect_ex


# --- programs ----------------------------------------------------------------
_MUTATING = {"start", "stop", "restart", "reload", "enable", "disable",
             "daemon-reload", "kill", "mask", "unmask", "reset-failed", "edit",
             "set-property", "isolate"}
_real_popen_init = subprocess.Popen.__init__


def _popen_init(self, args, *a, **k):
    argv = [args] if isinstance(args, (str, bytes)) else list(args or [])
    argv = [os.fspath(x) if not isinstance(x, (str, bytes)) else
            (x.decode() if isinstance(x, bytes) else x) for x in argv]
    flat = argv[0].split() if (len(argv) == 1 and k.get("shell")) else argv
    env = k.get("env") or os.environ
    for i, word in enumerate(flat):
        # A bare name runs whatever PATH finds first, which in the build and
        # deploy tests is one of OUR stand-ins: resolve it the same way.
        found = word if os.path.sep in word else (shutil.which(word, path=env.get("PATH")) or word)
        real = os.path.realpath(found)
        if real.startswith(_TESTS):
            continue                                   # a stand-in of ours
        base = os.path.basename(word)
        rest = flat[i + 1:]
        if base == "systemctl" and _MUTATING & set(rest):
            raise RefusedByTestSafetyNet(
                f"the test safety net refused `systemctl {' '.join(rest)}`: "
                f"tests may not change real units.")
        if base == "sudo":
            raise RefusedByTestSafetyNet(
                f"the test safety net refused `sudo {' '.join(rest)[:60]}`: "
                f"tests never gain privilege.")
        if word.startswith("/usr/local/bin/riffle-"):
            raise RefusedByTestSafetyNet(
                f"the test safety net refused to run the installed "
                f"{base} {' '.join(rest)[:60]}: tests use the tree's copy, "
                f"sandboxed (tests/lib/sandboxed_riffle_sign.py).")
    return _real_popen_init(self, args, *a, **k)


subprocess.Popen.__init__ = _popen_init
