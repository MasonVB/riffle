# ==========================================================================
# riffle-sign's seal and attestation signatures verify, with Ed25519,
# against the exact bytes the registry's own code builds.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For several seals and attestations, that each signature verifies
#   over the message the registry's own message builders produce for the
#   same inputs.
#
# WHY IT EXISTS
#   Found while wiring signing (Q4, audit round 1): riffle-sign signed
#   the wrong bytes for attestations, so the registry would have refused
#   every one.
#
# HOW IT WORKS
#   Loads the tree's riffle-sign as a module with a fresh random key in
#   a temporary directory, signs, and checks each signature against the
#   registry's builders (run with node from the extract
#   RIFFLE_REGISTRY_MESSAGES points to).
#
# READING THE OUTPUT
#   One line per case with `verifies: True`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/signing_and_payouts/test_seal_and_attestation_signatur
#   es_verify_against_the_registrys_own_code.py bin/riffle-sign
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tsig.py) during Q4.
#   2026-11-03  Its attestation class changed from `observation` to `dispute`
#               after the class fix.
#   2026-11-05  Moved into tests/signing_and_payouts; skips cleanly without
#               node or the registry extract.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
# --- skip cleanly when something this test needs is missing ---
try:
    import cryptography  # noqa: F401
except ImportError:
    print("  SKIPPED: needs the Python cryptography package"); raise SystemExit(0)
if not __import__("shutil").which("node"):
    print("  SKIPPED: needs node (version 22 or later) on PATH"); raise SystemExit(0)
if not __import__("os").path.isfile(__import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", "")):
    print("  SKIPPED: needs the registry's message builders: set RIFFLE_REGISTRY_MESSAGES "
          "(see tests/lib/extract_registry_message_builders.sh)"); raise SystemExit(0)
# ---------------------------------------------------------------
# Run the REAL riffle-sign (seal and attest) against the registry's own message functions,
# and verify every signature with Ed25519. argv: path-to-riffle-sign
import sys, os, json, io, contextlib, tempfile, shutil, subprocess, importlib.machinery, importlib.util, base64
src = sys.argv[1]; repo = __import__("os").environ.get("RIFFLE_TREE", ".")
ld = importlib.machinery.SourceFileLoader("rs", src)
spec = importlib.util.spec_from_loader("rs", ld); rs = importlib.util.module_from_spec(spec); ld.exec_module(rs)
d = tempfile.mkdtemp(); libd = os.path.join(d, "lib"); os.makedirs(libd); os.chmod(d, 0o755); os.chmod(libd, 0o755)
for f in ("keyutil.py", "ed25519_pure.py"):
    shutil.copy(os.path.join(repo, f), libd); os.chmod(os.path.join(libd, f), 0o644)
open(os.path.join(d, "seed"), "wb").write(os.urandom(32))
open(os.path.join(d, "payout.conf"), "w").write("handle = riffle\n")
rs.SEED_PATH, rs.CONF_PATH, rs.LOG_PATH = os.path.join(d, "seed"), os.path.join(d, "payout.conf"), os.path.join(d, "sig.log")
if hasattr(rs, "_KEYUTIL_DIRS"): rs._KEYUTIL_DIRS = (libd,)
def run(args):
    out, err = io.StringIO(), io.StringIO()
    sys.argv = ["riffle-sign"] + args
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err): rs.main()
    except SystemExit as e:
        if e.code not in (0, None): return None, err.getvalue().strip()[:120]
    return out.getvalue().strip(), None
pub_b64, _ = run(["pubkey"])
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
pub = Ed25519PublicKey.from_public_bytes(base64.urlsafe_b64decode(pub_b64 + "=" * (-len(pub_b64) % 4)))
H = "a" * 64
cases = [
 {"kind": "seal", "handle": "riffle", "label": "memory-v2", "hash": H},
 {"kind": "attest", "issuer": "riffle", "cls": "dispute", "subject": "coppice", "claim": "Two receipts settle out of order.", "evidence": ["https://1f916.ai/api/post/9823", "c121264"]},
 {"kind": "attest", "issuer": "riffle", "cls": "dispute", "subject": "no-scheduler", "claim": '  She wrote "never" — I found 3 counter\u2010examples.\ttab\n  ', "evidence": []},
 {"kind": "attest", "issuer": "riffle", "cls": "correction", "subject": "riffle", "claim": "Café ✓ 🚀 emoji and back\\slash / slash", "evidence": ["sha256:" + H, "a/b\\c \"q\""]},
]
reg = json.loads(subprocess.run(["node", "--experimental-strip-types", __import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", ""), json.dumps(cases)],
                                capture_output=True, text=True).stdout)
for c, expect in zip(cases, reg):
    if c["kind"] == "seal":
        o, err = run(["seal", f"--hash={c['hash']}", f"--label={c['label']}"])
    else:
        o, err = run(["attest", f"--subject={c['subject']}", f"--claim={c['claim']}", f"--cls={c['cls']}", f"--evidence={json.dumps(c['evidence'])}"])
    if o is None:
        print(f"  {c['kind']:6} {c.get('cls',''):11} REFUSED by the signer: {err}"); continue
    j = json.loads(o); sig = base64.urlsafe_b64decode(j["signature"] + "=" * (-len(j["signature"]) % 4))
    same = j["preimage"] == expect
    try: pub.verify(sig, expect.encode("utf-8")); ok = True
    except Exception: ok = False
    print(f"  {c['kind']:6} {c.get('cls',''):11} preimage == registry's: {same} | signature verifies against the registry's message: {ok}")
