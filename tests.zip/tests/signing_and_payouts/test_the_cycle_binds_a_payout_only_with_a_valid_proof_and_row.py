# ==========================================================================
# The cycle's payout binding (apply_sign): bound with a valid wallet
# proof; refused with no proof, with a stale seal, or for a row
# payout.conf does not allow.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: normal, no-proof, old-seal and bad-row.
#
# WHY IT EXISTS
#   Q4 (audit round 1): a payout binding commits the listing's money to
#   riffle's wallet, so every precondition is checked before signing.
#
# HOW IT WORKS
#   Runs apply_sign with the signer pointed at the sandboxed signer, and
#   a fake registry built on the registry's own preimages.
#
# READING THE OUTPUT
#   `[case] ...` with the outcome.
#
# RUNNING IT ON ITS OWN
#   RS_CEIL=none RS_PRICE=15000000 python3 tests/signing_and_payouts/tes
#   t_the_cycle_binds_a_payout_only_with_a_valid_proof_and_row.py .
#   normal
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tbind.py) during Q4.
#   2026-11-05  Moved into tests/signing_and_payouts. Runs the tree's riffle-
#               sign through tests/lib/sandboxed_riffle_sign.py, with a fresh
#               throwaway key for each run: in the sandbox it read whatever
#               seed sat at the real seed path, which on the operator's box is
#               riffle's real key. Skips cleanly without node or the registry
#               extract.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
# --- skip cleanly when something this test needs is missing ---
if not __import__("shutil").which("node"):
    print("  SKIPPED: needs node (version 22 or later) on PATH"); raise SystemExit(0)
if not __import__("os").path.isfile(__import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", "")):
    print("  SKIPPED: needs the registry's message builders: set RIFFLE_REGISTRY_MESSAGES "
          "(see tests/lib/extract_registry_message_builders.sh)"); raise SystemExit(0)
# ---------------------------------------------------------------
import sys, os, json, tempfile, subprocess, base64, re
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle
from agent.state import State
from agent.client import HttpError
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
cycle._SIGNER = ["python3", __import__("os").environ["RIFFLE_TESTS"] + "/lib/sandboxed_riffle_sign.py"]
def reg(case):
    return json.loads(subprocess.run(["node", "--experimental-strip-types", __import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", ""), json.dumps([case])], capture_output=True, text=True).stdout)[0]
class FakeRegistry:
    def __init__(self, base, secret): pass
    def payout_binding(self, b):
        assert isinstance(b["amount_atomic"], str) and re.fullmatch(r"[1-9][0-9]*", b["amount_atomic"]), "amount_atomic must be a canonical string"
        assert type(b["chain_id"]) is int and type(b["expiry"]) is int, "chain_id and expiry must be numbers"
        if mode == "no-proof":
            raise HttpError(400, {"error": "no live payout-wallet proof for " + b["address"] + " on chain 8453. Prove the wallet once at POST /api/payout-wallets"})
        pre = reg({"kind": "payout", "handle": b["handle"], "row": b["row"], "amount": b["amount_atomic"], "chain": b["chain_id"], "token": b["token"], "address": b["address"], "expiry": b["expiry"]})
        pub = Ed25519PublicKey.from_public_bytes(base64.urlsafe_b64decode(b["citizen_public_key"] + "=" * (-len(b["citizen_public_key"]) % 4)))
        pub.verify(base64.urlsafe_b64decode(b["citizen_signature"] + "=" * (-len(b["citizen_signature"]) % 4)), pre.encode())
        return {"binding": {"id": 7, "row": b["row"], "amount_atomic": b["amount_atomic"]}}
cycle.Writer = FakeRegistry
d = tempfile.mkdtemp(); open(os.path.join(d, "riffle.secret"), "w").write("x")
st = State(os.path.join(d, "s.sqlite")); cid = st.begin_cycle("earn")
cfg = {"data_dir": d, "base": "http://x", "handle": "riffle"}
payload = {"kind": "seal", "hash": "a" * 64, "label": "x"} if mode == "old-seal" else {"kind": "payout", "row": "docket-3" if mode == "bad-row" else "listing-16"}
logs = []
cycle.apply_sign(st, cfg, cid, payload, "earn", lambda t, level="info", **k: logs.append((level, t)))
oc = st.db.execute("SELECT outcome, notes FROM cycles WHERE id=?", (cid,)).fetchone()
rep = st.db.execute("SELECT content FROM messages ORDER BY id DESC LIMIT 1").fetchone()
print(f"  [{mode:9}] outcome={oc[0]!r} | report: {(rep[0] if rep else '')[:120]!r}")
