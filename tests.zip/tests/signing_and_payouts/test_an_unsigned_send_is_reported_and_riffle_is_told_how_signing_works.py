# ==========================================================================
# A seal sent unsigned (here from the dashboard, which cannot run the
# signer) is logged as a warning and reported in chat; and riffle's
# situation text describes signing correctly.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That approving a seal on the dashboard, sent unsigned, produces a
#   journal warning and a chat report; and that the situation text no
#   longer says `sign` makes seals.
#
# WHY IT EXISTS
#   U6 (audit round 2): riffle was told `sign` does seals and
#   attestations (they are signed automatically when sent; `sign` binds
#   payouts), and an unsigned send was recorded only in the action's
#   stored response.
#
# HOW IT WORKS
#   Approves a queued seal through the dashboard's decide(), with the
#   send answered as unsigned.
#
# READING THE OUTPUT
#   `journal warning True, chat report True` and `situation still says
#   sign does seals: False`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tu6.py) for U6.
#   2026-11-05  Moved into tests/signing_and_payouts.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, time, yaml; sys.path.insert(0, sys.argv[1])
from agent import dash, cycle
from agent.state import State, utcnow
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
st = State(os.path.join(d, "s.sqlite"))
dash.execute = lambda w, k, p: {"seal_id": 77, "now_utc": utcnow(), "unsigned_because": "the signer could not run: no sudo here"}
class W:
    def __init__(self, *a, **k): pass
dash.Writer = W
class H(dash.Handler): pass
H.state, H.cfg = st, cfg
h = H.__new__(H); h._update_card = lambda *a, **k: None; h._local_time = lambda: "now"; h.run_cycle = lambda *a, **k: None
aid = st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'seal','witness',?,'r','queued')",
                    (utcnow(), json.dumps({"hash": "ab" * 32, "label": "receipts-run"}))).lastrowid
st.db.commit(); h.decide(aid, "approve"); time.sleep(0.8)
j = st.db.execute("SELECT COUNT(*) FROM journal WHERE text LIKE '%UNSIGNED%'").fetchone()[0]
m = st.db.execute("SELECT COUNT(*) FROM messages WHERE content LIKE '%went out unsigned%'").fetchone()[0]
print(f"  a seal sent unsigned from the dashboard: journal warning {bool(j)}, chat report {bool(m)}")
src = open(os.path.join(sys.argv[1], "agent/cycle.py")).read()
print(f"  situation still says sign does seals: {'seal fingerprints a' in src}")
