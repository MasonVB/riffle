# ==========================================================================
# The cycle sends seals and attestations signed when the signer works,
# unsigned (and says why) when it cannot run, and records a registry
# refusal as a failure.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: `normal` (signed, and the fake registry
#   verifies the signature against the registry's own bytes), `no-
#   signer` (sent unsigned, with the reason recorded) and `registry-
#   rejects` (the registry refuses the signature).
#
# WHY IT EXISTS
#   Q4 and M3 (audit round 1): seals and attestations are signed
#   automatically when sent.
#
# HOW IT WORKS
#   A real cycle executes the action, with the signer pointed at the
#   sandboxed signer (a throwaway key) and a fake registry that verifies
#   signatures.
#
# READING THE OUTPUT
#   One line per case with the status and what the registry saw.
#
# RUNNING IT ON ITS OWN
#   python3 tests/signing_and_payouts/test_seals_and_attestations_go_out
#   _signed_unsigned_or_refused.py . normal
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (texec.py) during Q4.
#   2026-11-03  Its attestation class changed from `observation` to `dispute`.
#   2026-11-05  Moved into tests/signing_and_payouts. Runs the tree's riffle-
#               sign through tests/lib/sandboxed_riffle_sign.py, with a fresh
#               throwaway key for each run: in the sandbox it read whatever
#               seed sat at the real seed path, which on the operator's box is
#               riffle's real key. Skips cleanly without node or the registry
#               extract.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
# --- skip cleanly when something this test needs is missing ---
try:
    import cryptography  # noqa: F401
except ImportError:
    print("  SKIPPED: needs the Python cryptography package"); raise SystemExit(0)
if not __import__("shutil").which("node"):
    print("  SKIPPED: needs node (version 22 or later) on PATH"); raise SystemExit(0)
if not __import__("os").path.isfile(__import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", "")):
    print("  SKIPPED: needs the registry's message builders: set RIFFLE_REGISTRY_MESSAGES "
          "(see tests/lib/extract_registry_message_builders.sh)"); raise SystemExit(0)
# ---------------------------------------------------------------
import sys, os, json, subprocess, base64
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle
from agent.client import HttpError
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
signer = ["python3", __import__("os").environ["RIFFLE_TESTS"] + "/lib/sandboxed_riffle_sign.py"]
pub_b64 = subprocess.run(signer + ["pubkey"], capture_output=True, text=True).stdout.strip()
pub = Ed25519PublicKey.from_public_bytes(base64.urlsafe_b64decode(pub_b64 + "=" * (-len(pub_b64) % 4)))
if mode == "no-signer": signer = ["/nonexistent/riffle-sign"]
if hasattr(cycle, "_SIGNER"): cycle._SIGNER = signer
def registry_message(case):
    return json.loads(subprocess.run(["node", "--experimental-strip-types", __import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", ""), json.dumps([case])],
                                     capture_output=True, text=True).stdout)[0]
class FakeRegistry:
    sent = []
    def _check(self, body, case):
        self.sent.append(dict(body))
        sig = body.get("signature")
        if not sig: return {"signed": False}
        if mode == "registry-rejects":
            raise HttpError(400, {"error": "signature does not verify against any active key for riffle"})
        pub.verify(base64.urlsafe_b64decode(sig + "=" * (-len(sig) % 4)), registry_message(case).encode())
        return {"signed": True}
    def seal(self, h, label, signature=None):
        return self._check({"hash": h, "label": label, **({"signature": signature} if signature else {})},
                           {"kind": "seal", "handle": "riffle", "label": label, "hash": h})
    def attest_claim(self, cls, subject, claim, evidence, signature=None):
        return self._check({"class": cls, "subject": subject, "claim": claim, "evidence": evidence, **({"signature": signature} if signature else {})},
                           {"kind": "attest", "issuer": "riffle", "cls": cls, "subject": subject, "claim": claim, "evidence": evidence})
w = FakeRegistry()
for kind, p in (("seal", {"hash": "b" * 64, "label": "memory-v2"}),
                ("attestation", {"cls": "dispute", "subject": "coppice", "claim": 'She wrote "never"; two settle out of order.', "evidence": ["https://1f916.ai/api/post/9823"]})):
    w.sent.clear()
    try:
        r = cycle.execute(w, kind, p)
        print(f"  [{mode}] {kind:11} requests={len(w.sent)} signed-sent={[('signature' in b) for b in w.sent]} result={r}")
    except Exception as e:
        print(f"  [{mode}] {kind:11} RAISED {type(e).__name__}: {str(e)[:100]}")
