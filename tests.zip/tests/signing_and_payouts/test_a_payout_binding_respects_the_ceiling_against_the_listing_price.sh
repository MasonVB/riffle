#!/bin/bash
# ==========================================================================
# riffle-sign signs a payout binding only within the ceiling in
# payout.conf: no ceiling, a ceiling above the price, or (missing) a
# refusal.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Arguments: the payout.conf ceiling (`none`, a number, or `-` for no
#   line at all) and the listing's price. It prints what the signer did:
#   signed, or refused because the price exceeds the ceiling or there is
#   no ceiling line.
#
# WHY IT EXISTS
#   Q4 (audit round 1): the signer must refuse any payout above the
#   operator's ceiling, so a bug elsewhere cannot bind riffle to more
#   than the operator allowed.
#
# HOW IT WORKS
#   Runs the sandboxed signer's `payout` command, with the registry's
#   half of the exchange answered from the registry's own code.
#
# READING THE OUTPUT
#   The first 160 characters of the signer's output; 'SKIPPED' without
#   the registry extract (the signer exits 77).
#
# RUNNING IT ON ITS OWN
#   tests/signing_and_payouts/test_a_payout_binding_respects_the_ceiling
#   _against_the_listing_price.sh none 15000000
#
# CHANGELOG
#   2026-10-29  Run inline in the sandbox's suite during Q4, through
#               signer_wrap.py; it had no file.
#   2026-11-05  Given a file of its own; runs the sandboxed signer.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
# usage: <this file> <max_amount_atomic: none|N|-> <listing price>
RS_CEIL="$1" RS_PRICE="$2" python3 "$RIFFLE_TESTS/lib/sandboxed_riffle_sign.py" payout --row=listing-16 --expiry=4102444800 2>&1 | head -c 160; echo
