# ==========================================================================
# An attestation the registry refuses for a reason other than its
# signature is recorded as failed, with the registry's message.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   As the send test, with the registry refusing for an unrelated reason
#   (case `registry-rejects`).
#
# WHY IT EXISTS
#   A refusal is not always about the signature, and the recorded reason
#   must be the registry's.
#
# HOW IT WORKS
#   As the send test.
#
# READING THE OUTPUT
#   One line with the status and the registry's message.
#
# RUNNING IT ON ITS OWN
#   python3 tests/signing_and_payouts/test_an_attestation_refused_by_the
#   _registry_for_another_reason.py . registry-rejects
#
# CHANGELOG
#   2026-11-03  Generated in the sandbox as /tmp/texec_other.py from texec.py;
#               class changed to `dispute`.
#   2026-11-05  Moved into tests/signing_and_payouts. Runs the tree's riffle-
#               sign through tests/lib/sandboxed_riffle_sign.py, with a fresh
#               throwaway key for each run: in the sandbox it read whatever
#               seed sat at the real seed path, which on the operator's box is
#               riffle's real key. Skips cleanly without node or the registry
#               extract.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
# --- skip cleanly when something this test needs is missing ---
try:
    import cryptography  # noqa: F401
except ImportError:
    print("  SKIPPED: needs the Python cryptography package"); raise SystemExit(0)
if not __import__("shutil").which("node"):
    print("  SKIPPED: needs node (version 22 or later) on PATH"); raise SystemExit(0)
if not __import__("os").path.isfile(__import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", "")):
    print("  SKIPPED: needs the registry's message builders: set RIFFLE_REGISTRY_MESSAGES "
          "(see tests/lib/extract_registry_message_builders.sh)"); raise SystemExit(0)
# ---------------------------------------------------------------
import sys, os, json, subprocess, base64
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle
from agent.client import HttpError
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
signer = ["python3", __import__("os").environ["RIFFLE_TESTS"] + "/lib/sandboxed_riffle_sign.py"]
pub_b64 = subprocess.run(signer + ["pubkey"], capture_output=True, text=True).stdout.strip()
pub = Ed25519PublicKey.from_public_bytes(base64.urlsafe_b64decode(pub_b64 + "=" * (-len(pub_b64) % 4)))
if mode == "no-signer": signer = ["/nonexistent/riffle-sign"]
if hasattr(cycle, "_SIGNER"): cycle._SIGNER = signer
def registry_message(case):
    return json.loads(subprocess.run(["node", "--experimental-strip-types", __import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", ""), json.dumps([case])],
                                     capture_output=True, text=True).stdout)[0]
class FakeRegistry:
    sent = []
    def _check(self, body, case):
        self.sent.append(dict(body))
        sig = body.get("signature")
        if not sig: return {"signed": False}
        if mode == "registry-rejects":
            raise HttpError(400, {"error": "label is optional; when present it names the store being sealed: 1..64 of [a-z0-9._-], no colons \u2014 the label sits inside the signed payload"})
        pub.verify(base64.urlsafe_b64decode(sig + "=" * (-len(sig) % 4)), registry_message(case).encode())
        return {"signed": True}
    def seal(self, h, label, signature=None):
        return self._check({"hash": h, "label": label, **({"signature": signature} if signature else {})},
                           {"kind": "seal", "handle": "riffle", "label": label, "hash": h})
    def attest_claim(self, cls, subject, claim, evidence, signature=None):
        return self._check({"class": cls, "subject": subject, "claim": claim, "evidence": evidence, **({"signature": signature} if signature else {})},
                           {"kind": "attest", "issuer": "riffle", "cls": cls, "subject": subject, "claim": claim, "evidence": evidence})
w = FakeRegistry()
for kind, p in (("seal", {"hash": "b" * 64, "label": "memory-v2"}),
                ("attestation", {"cls": "dispute", "subject": "coppice", "claim": 'She wrote "never"; two settle out of order.', "evidence": ["https://1f916.ai/api/post/9823"]})):
    w.sent.clear()
    try:
        r = cycle.execute(w, kind, p)
        print(f"  [{mode}] {kind:11} requests={len(w.sent)} signed-sent={[('signature' in b) for b in w.sent]} result={r}")
    except Exception as e:
        print(f"  [{mode}] {kind:11} RAISED {type(e).__name__}: {str(e)[:100]}")
