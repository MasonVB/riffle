# ==========================================================================
# payout_wallet.py, the one-time tool that proves riffle's payout address
# to the registry, sends a valid signature; a bad one is caught.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 1 picks the case: `good` (the proof sent verifies against
#   the registry's own preimage) or `badsig` (a broken signature is
#   detected).
#
# WHY IT EXISTS
#   Q4 (audit round 1): the wallet proof (#133 on the box, expiring
#   2027-10-28) must be renewable with this tool.
#
# HOW IT WORKS
#   Runs the tool with the signer pointed at the sandboxed signer and a
#   fake registry endpoint.
#
# READING THE OUTPUT
#   One line per case.
#
# RUNNING IT ON ITS OWN
#   python3 tests/signing_and_payouts/test_the_payout_wallet_tool_proves
#   _the_address_with_a_valid_signature.py good
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (twallet.py) during Q4.
#   2026-11-05  Moved into tests/signing_and_payouts. Runs the tree's riffle-
#               sign through tests/lib/sandboxed_riffle_sign.py, with a fresh
#               throwaway key for each run: in the sandbox it read whatever
#               seed sat at the real seed path, which on the operator's box is
#               riffle's real key. Skips cleanly without node or the registry
#               extract.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
# --- skip cleanly when something this test needs is missing ---
try:
    import cryptography  # noqa: F401
except ImportError:
    print("  SKIPPED: needs the Python cryptography package"); raise SystemExit(0)
if not __import__("shutil").which("node"):
    print("  SKIPPED: needs node (version 22 or later) on PATH"); raise SystemExit(0)
if not __import__("os").path.isfile(__import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", "")):
    print("  SKIPPED: needs the registry's message builders: set RIFFLE_REGISTRY_MESSAGES "
          "(see tests/lib/extract_registry_message_builders.sh)"); raise SystemExit(0)
# ---------------------------------------------------------------
import sys, os, json, io, subprocess, base64, builtins, urllib.request
sys.path.insert(0, __import__("os").environ.get("RIFFLE_TREE", "."))
import payout_wallet as pw
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
mode = sys.argv[1]
open(__import__("os").environ["RIFFLE_SIGNER_SANDBOX"] + "/payout.conf", "w").write("handle=riffle\naddress=0x0C19bf942294235e53b35af0198f1b629c5f7080\nmax_amount_atomic=none\nallowed_rows=listing-*\n")
pw.CONF = __import__("os").environ["RIFFLE_SIGNER_SANDBOX"] + "/payout.conf"; pw.SIGNER = ["python3", __import__("os").environ["RIFFLE_TESTS"] + "/lib/sandboxed_riffle_sign.py"]
real_run = subprocess.run
def run(argv, **k):
    if argv[:3] == ["sudo", "-u", "riffle"] and argv[3] == "cat":
        return subprocess.CompletedProcess(argv, 0, "the-secret\n", "")
    return real_run(argv, **k)
pw.subprocess.run = run
seen = {}
class Resp(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *a): pass
def urlopen(req, timeout=None):
    b = json.loads(req.data); seen["auth"] = req.headers.get("Authorization")
    expect = json.loads(subprocess.run(["node", "--experimental-strip-types", __import__("os").environ.get("RIFFLE_REGISTRY_MESSAGES", ""),
        json.dumps([{"kind": "wallet", "handle": b["handle"], "chain": b["chain_id"], "address": b["address"], "expiry": b["expiry"]}])], capture_output=True, text=True).stdout)[0]
    assert b["preimage"] == expect, "preimage differs from the registry's"
    assert type(b["chain_id"]) is int and type(b["expiry"]) is int
    pub = Ed25519PublicKey.from_public_bytes(base64.urlsafe_b64decode(b["citizen_public_key"] + "=" * (-len(b["citizen_public_key"]) % 4)))
    pub.verify(base64.urlsafe_b64decode(b["citizen_signature"] + "=" * (-len(b["citizen_signature"]) % 4)), expect.encode())
    seen["ok"] = True
    return Resp(json.dumps({"wallet": {"id": 1, "address": b["address"]}}).encode())
pw.urllib.request.urlopen = urlopen
builtins.input = lambda prompt="": ("0x" + "ab" * 65) if mode == "good" else "0xnotasignature"
out = io.StringIO(); sys.argv = ["payout_wallet.py", "--days", "364"]
import contextlib
try:
    with contextlib.redirect_stdout(out): pw.main()
    print(f"  [{mode}] submitted; registry-side checks passed: {seen.get('ok')}; bearer sent: {seen.get('auth') == 'Bearer the-secret'}")
except SystemExit as e:
    print(f"  [{mode}] stopped before submitting: {str(e.code)[:110]}" if not seen else f"  [{mode}] exit after submit: {e.code}")
shown = [l.strip() for l in out.getvalue().splitlines() if l.strip().startswith("1f916.")]
print(f"    preimage shown to you: {shown[0] if shown else '(none)'}")
