# riffle's tests

207 checks of riffle's behaviour, written while fixing three rounds of audit (round 1,
2026-10-27; round 2, 2026-11-04; round 3, 2026-11-06) and the review before
them. Most run
the real `cycle.main()` against a stub registry and a stub composer, so they
check what riffle would really have done, not a function in isolation.

## A record, kept zipped

These tests are kept as `tests.zip` in the repository root: a record for
whoever works on riffle next, so each fix comes with the evidence that it
works. They are not unpacked in the checkout, and **riffle itself never runs
them**. It could not anyway: riffle cannot write `/opt/riffle`, its build
sandbox cannot see `/opt/riffle`, and nothing in riffle unpacks archives.
If they are ever run by accident, every entry point refuses under riffle's
own accounts (`riffle`, `riffle-signer`, `riffle-build`), and the safety net
below is there however a test is started.

Before changing the zip, scan what goes into it: update.sh's secret scan
cannot see inside a zip, since its contents are compressed. Then record a new
expected output (see Adding a test).

## Running them

Unpack them **somewhere other than the checkout**, and point them at the
tree, as yourself, **not** as root and never as riffle:

```
unzip -q /opt/riffle/tests.zip -d /tmp/riffle-tests
python3 /tmp/riffle-tests/tests/check_against_expected.py /opt/riffle
```

Unpacked into `/opt/riffle`, they would leave an untracked `tests/` there.

This runs everything (about 90 seconds) and compares each test with
`tests/expected_output.txt`, the output of a run read line by line and judged
correct. Every test comes back as one of:

- **ok**: identical to the reviewed output.
- **SKIPPED**: a tool it needs is missing here, with the reason. Not a
  failure, but not a check either.
- **DIFFERS**: its output changed; the changed lines are printed. A
  difference is not automatically a bug, but it must be explained before
  anything is deployed.
- **NEW**: a test with no reviewed output yet.

Before deploying a change, compare the code before and after it, in a
scratch clone of the repository with the tests unpacked inside it:

```
git clone -q /opt/riffle /tmp/riffle-copy && cd /tmp/riffle-copy && unzip -q tests.zip
# make the change here, then:
bash tests/compare_two_versions.sh HEAD WORKTREE
```

Each side is a git ref (`HEAD`, a commit, `origin/master`) or `WORKTREE` for
the files as they are now. It shows every line of output that differs. This
is how every fix in both audits was checked.

The two do different jobs. Comparing two versions shows what a change
changed, and is blind to a check that is wrong in both: two such checks went
unnoticed for days in the sandbox (the TLS test's certificates expired, and
the squeeze test reported WRONG on every run). The expected output catches
those, the day they happen.

To see raw output: `bash /tmp/riffle-tests/tests/run_all.sh /opt/riffle > results.txt`.
To run some tests only: `ONLY='inbox|burst' bash /tmp/riffle-tests/tests/run_all.sh /opt/riffle`.

Always start them with `bash` or `python3` as shown: GitHub's web uploader
does not keep the executable bit. The runner sets it on its own copy of the
suite, so nothing depends on it.

## What it needs

Python 3 with PyYAML (riffle's own), git, and flock (util-linux). Tests that
need more skip cleanly, saying why:

| Missing | Tests skipped |
|---|---|
| `node` (22 or later) | the dashboard-button test; signature checks against the registry |
| the registry extract | 13 signing and payout tests (see below) |
| `openssl` | the HTTPS hostname test |
| `pyflakes` | the lint check |
| Python `cryptography` | signature verification |

The signing tests check riffle-sign's output against the registry's **own**
message-building code. That code is the registry's, so it is not committed
here. To enable them, from a checkout of the registry's source:

```
bash tests/lib/extract_registry_message_builders.sh <registry checkout> /tmp/registry_messages.ts
RIFFLE_REGISTRY_MESSAGES=/tmp/registry_messages.ts python3 tests/check_against_expected.py
```

## Safety

The tests are written so they cannot act on the real riffle on the box, in
three layers:

1. **A copy of the tree.** `run_all.sh` copies the tree to a temporary
   directory and runs everything there. Your checkout and your `config.yaml`
   are never touched (several tests edit files to make a check fail on
   purpose). In the copy's config, riffle's data and library directories
   point into the run's scratch directory.
2. **A safety net**, `tests/lib/riffle_test_safety_net.py`, loaded into every
   Python test, both by the runner and by each test file itself, so it is
   there however a test is started. It refuses to run at all under riffle's
   own accounts, and otherwise refuses: writes under `/opt/riffle`, `/var/lib/riffle*`, `/etc`
   and `/usr/local`; riffle's real database; network connections to anything
   but loopback, and to riffle's own ports (80, 8080, 8081, 8888); `sudo`;
   the installed signer, build helper and reader; and any `systemctl` that
   changes a unit, except the test stand-ins.
3. **Every test written for it.** Each shell test refuses to start unless the
   runner set it up (its stand-ins would otherwise be missing). Signing uses a throwaway key
   (`tests/lib/sandboxed_riffle_sign.py`), never riffle's. The build and
   deploy tests use their own temporary workspace, checkout and lock file,
   and stand-ins for `sudo`, `systemd-run` and `systemctl`.

Packaging found what these layers guard against. As first written in the
sandbox, the deploy test ran `rm -rf /opt/riffle`, the disk test ran
`rm -rf /var/lib/riffle-build/*`, the restart test wrote the real trigger
that restarts the composer, the runner overwrote and deleted `config.yaml`,
signing tests used whatever seed sat at the real seed path, and cycle tests
wrote into `/var/lib/riffle-library`. All were fixed; the safety net
caught the last one on its first run.

## Layout

| Folder | What its tests check |
|---|---|
| `prompt/` | what riffle reads: the board boundary, fitting the prompt into its room, the composer's cache |
| `inbox/` | reading, storing and acknowledging messages; bursts; the backlog |
| `send_checks/` | every check before an action is sent: replies, caps, votes, figures, references, links, listings, hashes |
| `signing_and_payouts/` | the signer, seals and attestations, payout bindings, the wallet proof |
| `memory/` | remembering, corrections, consolidation, reflection, continuity |
| `dashboard/` | approvals, the chat, restarting the model, buttons, notifications |
| `cycle/` | approved actions, crashes, interrupted actions, the trivial findings |
| `witness/` | the witness pass and witness.py |
| `build/` | the build helper's memory and disk limits; the library |
| `web/` | rebinding, HTTPS, search_web, page labels |
| `telemetry/` | readings and what survives a reboot |
| `deploy/` | update.sh's gates, unit install, secret scan, cycle lock, helper drift |
| `harnesses/` | shared cycle runners that several tests build on |
| `lib/` | the safety net, the sandboxed signer, stand-ins, the gate runner |
| `fixtures/` | `registry_me_response.json`, a real answer from the registry's /api/me |

The fixture is a real registry response. It holds other citizens' **public**
posts and comments from the square, so this repository now carries copies of
public text written by others. Replace it with a trimmed or synthetic one if
you would rather it did not.

Every test file starts with a header: what it proves, why it exists (the
finding, and what was wrong), how it works, how to read its output, how to run
it alone, and a changelog. For tests older than the round-1 audit, the
changelog says only what was recorded: the old name and the date last changed.

## Adding a test

1. Write it under the right folder, with a name that says what it proves, and
   the same header as the others.
2. Add a line to `tests/list_of_tests.txt`: `name | command`.
3. Run `python3 tests/check_against_expected.py`; it shows as NEW.
4. Read its output and be sure it is right. Then `--record`, and read
   `git diff tests/expected_output.txt` line by line before committing.

Recording output nobody read turns the expected output back into the blind
comparison it exists to replace.

## Changelog

- **2026-10-23 to 2026-11-04**: the tests lived in the sandbox where the
  fixes were written, run by `regress.sh` and compared back to back by
  `abcompare.sh`.
- **2026-11-05**: packaged here. Every test renamed to say what it proves and
  given a full header; hard-coded paths replaced; the three dangerous tests
  fixed and the safety net added; the reviewed expected output and its check
  added. Packaging also found:
  - a real gap in riffle-build: a build that flooded the disk between two of
    its once-a-second checks was never measured, and if it failed its
    directory was kept. Fixed, with a test that proves it;
  - that every cycle test's output depended on the hour, since the daily
    memory step runs after 09:00 UTC. The runner now turns it off for cycle
    tests;
  - that the deploy test's planted fake token tripped update.sh's own secret
    scan. It is now assembled at run time.
- **2026-11-05**: kept zipped in the repository root as a record. Every entry
  point refuses under riffle's accounts; every test loads the safety net
  itself (it had loaded only through the runner, and a test named its module
  `sitecustomize`, which Debian's own module of that name shadowed); shell
  tests refuse to start outside the runner.
- **2026-11-06** (audit round 3): the four build tests run unprivileged, since
  riffle-build needs root and its own user, which a test of disk and output
  limits does not (V5); peak memory falls back to a Python stand-in without
  GNU `time`. The box-audit test reports whether `sign` is offered and gained
  a set-aside-listing case (V3). 196 tests.
- **2026-11-06**: `prompt/test_the_prompt_is_sent_as_three_user_messages.py`
  for V1: riffle's prompt goes to the composer as three user messages, so the
  composer can resume from a checkpoint at each. 197 tests.
- **2026-11-06**: `deploy/test_the_remaining_gates_fail_on_what_they_must_catch.sh`:
  every update.sh gate has now been seen failing on the fault it exists to
  catch. It found that PYREC checked only seven named files (fixed: every
  file). 198 tests.
- **2026-11-06**: `send_checks/test_riffle_writes_its_rationale_before_choosing_its_action.py`
  for V4: riffle reasons before it picks its action and target. The tests now
  run under the 62,000-character ceiling (option C). 199 tests.
- **2026-11-07**: box-audit cases `refused-twice` and `refused-once`: riffle's
  next prompt shows its last refusal in the check's own words, and says when
  the same thing has been refused several times running. 201 tests.
- **2026-11-07**: box-audit cases `dup-close`, `close-once`, `dup-ask` and
  `ask-new`: an action identical to one already waiting for the operator, or
  a second close for the same project, is refused. 205 tests.
- **2026-11-07**: box-audit cases `seal-invented` and `seal-library`: a seal's
  hash must be the full sha256 of a document in riffle's library. riffle had
  signed and sealed an invented hash into the registry's permanent record.
  207 tests.
- **2026-11-07**: riffle's prompt goes as four user messages, the project
  separate from what changes nearly every cycle, and the project's age is
  shown as a fixed opening time. The message-split test is renamed
  `..._as_four_user_messages.py`; the realistic two-cycle test reports where
  the composer resumes. 207 tests.
