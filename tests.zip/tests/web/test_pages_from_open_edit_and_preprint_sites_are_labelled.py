# ==========================================================================
# A page read from an open-edit site (Wikipedia) or a preprint server is
# labelled as such in its library title, the next cycle's note and the
# report.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For each kind of site, the three places the label must appear.
#
# WHY IT EXISTS
#   M12 (audit round 1): unreviewed sources were indistinguishable from
#   reviewed ones in everything riffle read afterwards.
#
# HOW IT WORKS
#   Runs the page-reading action with the reader stubbed for each kind
#   of URL.
#
# READING THE OUTPUT
#   Per host: the title's end, the note and the report.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm12.py) for M12.
#   2026-11-05  Moved into tests/web.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, subprocess; sys.path.insert(0, sys.argv[1])
from agent import cycle, library
from agent.state import State
real_run = subprocess.run
def fake_run(argv, **k):
    if "--url" in argv:
        u = argv[argv.index("--url") + 1]
        return subprocess.CompletedProcess(argv, 0, json.dumps({"ok": True, "url": u, "text": "The boiling point is 373.15 K. Page: " + u, "chars": 60}), "")
    return real_run(argv, **k)
cycle.subprocess.run = fake_run
d = tempfile.mkdtemp(); root = tempfile.mkdtemp()
st = State(os.path.join(d, "s.sqlite")); library.ensure(st, root)
cfg = {"data_dir": d, "library": {"root": root}}
for url in ("https://en.wikipedia.org/wiki/Water", "https://arxiv.org/abs/2401.01234", "https://physics.nist.gov/cuu/Constants/"):
    cid = st.begin_cycle("understand")
    cycle.apply_read_page(st, cfg, cid, {"url": url, "why": "checking a figure"}, "understand", lambda *a, **k: None)
    title = st.db.execute("SELECT title FROM library ORDER BY id DESC LIMIT 1").fetchone()[0]
    note = (st.note("last_library_read") or "").split("\n")[1]
    rep = st.db.execute("SELECT content FROM messages ORDER BY id DESC LIMIT 1").fetchone()[0].split("\n")[0]
    print(f"  {url.split('/')[2]:20} title: {title[-34:]!r}\n  {'':20} next-cycle note: {note[:64]!r}\n  {'':20} report: {rep[-40:]!r}")
