# ==========================================================================
# The chat's web fetch connects only to the address it checked: a DNS
# answer that changes between the check and the connection cannot steer it
# to the local network.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks `ok` or `err` (the internal server answers 404):
#   the internal server is never contacted, and the public page is
#   returned.
#
# WHY IT EXISTS
#   L19 (audit round 1): the fetch resolved a name twice, checked the
#   real address only after connecting, let the request through when it
#   could not tell, and skipped the check on HTTP errors.
#
# HOW IT WORKS
#   A 'public' server on 127.0.0.2 (counted as public for the test) and
#   an 'internal' one on 127.0.0.1; DNS answers 127.0.0.2 first and
#   127.0.0.1 after.
#
# READING THE OUTPUT
#   `[case] internal server was hit 0 time(s), public 1 | returned:
#   ...`.
#
# RUNNING IT ON ITS OWN
#   python3
#   tests/web/test_a_web_fetch_cannot_be_rebound_to_the_local_network.py
#   . ok
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl19.py) for L19; it showed my first
#               version resolving twice.
#   2026-11-05  Moved into tests/web.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, socket, threading, ipaddress, http.server; sys.path.insert(0, sys.argv[1])
from agent import web
mode = sys.argv[2]
hits = {"public": 0, "internal": 0}
def server(addr, name, code):
    class Hd(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            hits[name] += 1
            self.send_response(code); self.send_header("Content-Type", "text/html"); self.end_headers()
            self.wfile.write(f"<p>{name} page</p>".encode())
        def log_message(self, *a): pass
    srv = http.server.HTTPServer(addr, Hd); threading.Thread(target=srv.serve_forever, daemon=True).start(); return srv
pub = server(("127.0.0.2", 0), "public", 200); port = pub.server_address[1]
server(("127.0.0.1", port), "internal", 404 if mode == "err" else 200)
real_gai = socket.getaddrinfo; calls = [0]
def rigged(host, *a, **k):
    try:
        ipaddress.ip_address(host); return real_gai(host, *a, **k)           # an address resolves to itself
    except ValueError:
        pass
    calls[0] += 1
    ip = "127.0.0.2" if calls[0] == 1 else "127.0.0.1"                       # public for the check, internal after
    return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, a[0] if a and a[0] else port))]
socket.getaddrinfo = rigged
real_blocked = web._ip_blocked
web._ip_blocked = lambda ip: False if str(ip) == "127.0.0.2" else real_blocked(ip)
try:
    out = web.read(f"http://rebind.test:{port}/page") if hasattr(web, "read") else None
    res = f"returned: {str(out)[:60]!r}"
except Exception as e:
    res = f"{type(e).__name__}: {str(e)[:70]}"
print(f"  [{mode:7}] internal server was hit {hits['internal']} time(s), public {hits['public']} | {res}")
