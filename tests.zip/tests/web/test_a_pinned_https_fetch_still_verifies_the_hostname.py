# ==========================================================================
# Fetching over HTTPS through the pinned connection still verifies the
# certificate against the hostname: the right certificate is accepted, one
# for another name refused.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the certificate the server presents: `secure.test`
#   (the page arrives) or `other.test` (CERTIFICATE_VERIFY_FAILED).
#
# WHY IT EXISTS
#   L19 (audit round 1): connecting to a checked address while verifying
#   a hostname is where such code usually goes wrong.
#
# HOW IT WORKS
#   Makes a private certificate authority and two certificates in
#   $RIFFLE_TMP/tlsca (with openssl), runs a TLS server on 127.0.0.2,
#   and points SSL_CERT_FILE at that authority.
#
# READING THE OUTPUT
#   `server presents a certificate for NAME -> ...`.
#
# RUNNING IT ON ITS OWN
#   python3
#   tests/web/test_a_pinned_https_fetch_still_verifies_the_hostname.py .
#   secure.test
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl19s.py) for L19, with a certificate
#               authority made by hand in /tmp/tlsca.
#   2026-11-05  Moved into tests/web; makes its own authority in $RIFFLE_TMP,
#               and skips without openssl.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, socket, ssl, threading, http.server, ipaddress; sys.path.insert(0, sys.argv[1])
from agent import web
cert = sys.argv[2]                                   # which certificate the server presents
import shutil, subprocess
if not shutil.which("openssl"):
    print("  SKIPPED: needs openssl"); raise SystemExit(0)
CA = os.environ["RIFFLE_TMP"] + "/tlsca"
if not os.path.exists(CA + "/other.test.pem"):        # a private authority, made once per run
    os.makedirs(CA, exist_ok=True)
    q = dict(capture_output=True, cwd=CA)
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", "ca.key", "-out", "ca.pem", "-days", "2", "-subj", "/CN=Test CA"], **q)
    for n in ("secure.test", "other.test"):
        subprocess.run(["openssl", "req", "-newkey", "rsa:2048", "-nodes", "-keyout", n + ".key", "-out", n + ".csr", "-subj", "/CN=" + n], **q)
        open(CA + "/" + n + ".ext", "w").write("subjectAltName=DNS:" + n)
        subprocess.run(["openssl", "x509", "-req", "-in", n + ".csr", "-CA", "ca.pem", "-CAkey", "ca.key", "-CAcreateserial", "-out", n + ".pem", "-days", "2", "-extfile", n + ".ext"], **q)
os.environ["SSL_CERT_FILE"] = CA + "/ca.pem"
class Hd(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200); self.send_header("Content-Type", "text/html"); self.end_headers(); self.wfile.write(b"<p>tls page</p>")
    def log_message(self, *a): pass
srv = http.server.HTTPServer(("127.0.0.2", 0), Hd); port = srv.server_address[1]
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(f"{CA}/{cert}.pem", f"{CA}/{cert}.key")
srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
threading.Thread(target=srv.serve_forever, daemon=True).start()
real_gai = socket.getaddrinfo
def rigged(host, *a, **k):
    try: ipaddress.ip_address(host); return real_gai(host, *a, **k)
    except ValueError: return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.2", port))]
socket.getaddrinfo = rigged
real_blocked = web._ip_blocked
web._ip_blocked = lambda ip: False if str(ip) == "127.0.0.2" else real_blocked(ip)
out = web.read(f"https://secure.test:{port}/")
print(f"  server presents a certificate for {cert:12} -> {str(out)[:90]!r}")
