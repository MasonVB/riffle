# ==========================================================================
# search_web searches one site on the reader's allowlist, sends `site:`
# with the terms, drops results from other sites, and shows them on the
# board side next cycle.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks `ok` (the query sent, results on the board side,
#   off-site results dropped), `offlist` (a site not on the list:
#   refused) or `wikionly` (with the Wikipedia search setting, any other
#   site: refused).
#
# WHY IT EXISTS
#   search_web (2026-10-29), at the operator's request, to find pages
#   riffle can then read and quote.
#
# HOW IT WORKS
#   Two forced real cycles; the reader's domain list and the search are
#   stubbed.
#
# READING THE OUTPUT
#   `[case] outcomes [...] | query sent: [...]`, then where the results
#   appeared.
#
# RUNNING IT ON ITS OWN
#   python3 tests/web/test_search_web_searches_only_the_one_listed_site_
#   it_names.py . ok
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tsearch.py) for search_web; its first
#               run tested nothing, as no project was open.
#   2026-11-05  Moved into tests/web.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, subprocess
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, web
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "understand"
real_run = subprocess.run
def fake_run(argv, **k):
    if argv[:2] == ["/usr/local/bin/riffle-reader", "--list-domains"]:
        return subprocess.CompletedProcess(argv, 0, json.dumps({"domains": ["en.wikipedia.org", "plato.stanford.edu", "physics.nist.gov"]}), "")
    return real_run(argv, **k)
cycle.subprocess.run = fake_run
asked = []
def fake_search(cfg, query, n=5):
    asked.append(query)
    return [{"title": "Henry VIII", "url": "https://en.wikipedia.org/wiki/Henry_VIII", "snippet": "King of England 1509-1547"},
            {"title": "Spam", "url": "https://www.reddit.com/r/history", "snippet": "a forum"},
            {"title": "Tudor", "url": "https://en.wikipedia.org/wiki/House_of_Tudor", "snippet": "royal house"}], None
web.search = fake_search
site = {"ok": "en.wikipedia.org", "offlist": "www.reddit.com", "wikionly": "plato.stanford.edu"}[mode]
users = []; step = [0]
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    users.append(user); step[0] += 1
    if step[0] == 1:
        return json.dumps({"action": "search_web", "payload": {"site": site, "query": "Henry VIII break with Rome"}, "rationale": "finding a source for my post"})
    return json.dumps({"action": "noop", "payload": {"why": "reading what the search found"}, "rationale": "nothing to do this cycle"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg["autonomy"]["search_web"] = "auto"
cfg["web"]["provider"] = "wikipedia" if mode == "wikionly" else "searxng"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','Tudor sources','Q?','active')"); st.db.commit()
for run in (1, 2):
    sys.argv = ["cycle", "--config", cp, "--force"]            # forced both times: the _dt path
    try: cycle.main()
    except SystemExit: pass
    if cycle._CYCLE_LOCK: cycle._CYCLE_LOCK.close(); cycle._CYCLE_LOCK = None
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
oc = [r[0] for r in db.execute("SELECT outcome FROM cycles ORDER BY id")]
u = users[-1] if users else ""
own, board = (u.split("<board>", 1) + [""])[:2]
print(f"  [{mode:8}] outcomes {oc} | query sent: {asked[:1]}")
print(f"  {'':10} next cycle: results on board side {'WHAT YOUR SEARCH FOUND' in board}, in own section {'WHAT YOUR SEARCH FOUND' in own}, "
      f"reddit dropped {'reddit' not in u}, tudor kept {'House_of_Tudor' in board}")
