# ==========================================================================
# A reply is sent only to a comment riffle has seen, in the thread
# snapshot it read or in its inbox; a reply naming any other comment is
# refused or moved only when riffle has seen it.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For a parent comment id and post id given as arguments 2 and 3:
#   whether the reply was sent, and the cycle's outcome. Riffle read
#   post 4 before comment 2 existed, so the snapshot holds only c3.
#
# WHY IT EXISTS
#   H2 (audit round 1): replies were retargeted to a different post for
#   comments riffle had never seen. The earlier review also needed this:
#   a reply to a comment absent from the snapshot was sent blind.
#
# HOW IT WORKS
#   Runs a real cycle whose composer proposes a reply to the given
#   parent; the stub registry records what is sent.
#
# READING THE OUTPUT
#   `parent P on post Q (...): sent=[...] outcome=...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_a_reply_goes_only_to_a_comment_riffle
#   _has_actually_seen.py . 2 4
#
# CHANGELOG
#   2026-10-25  Written in the sandbox (hsnap.py) during the earlier review.
#   2026-10-28  Also run with other arguments for H2 (th2.sh).
#   2026-11-05  Moved into tests/send_checks. Its sandbox wrapper (tsnap.sh
#               and th2.sh) ran it on an extracted copy of the previous
#               version and on the change, labelled 'original' and 'fixed';
#               packaged, it checks the one tree it is given, and
#               tests/compare_two_versions.sh does the comparison.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, par, post = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]); sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project
from agent.client import HttpError
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))                  # inbox: comment 2 on post 4
sent = []
class Stub:
    def __init__(self, *a, **k): pass
    def get(self, path, **k):
        if path.startswith("/api/comment/"):
            c = int(path.rsplit("/", 1)[1])
            if c == 999999: raise HttpError(404, {"error": "not found"})
            return {"comment": {"id": c, "post_id": 777}}
        return {}
    def create_comment(self, post_id, body, parent_id=None):
        sent.append((post_id, parent_id)); return {"id": 1}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "answer"
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps({"action": "comment", "payload": {"post_id": post, "parent_id": par,
    "body": "You wrote that the receipts settle in order. I checked the last forty and two settle out of order."}, "rationale": "answering their new comment"}) \
    if "Choose ONE action" in user else json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d; cfg["autonomy"]["comment"] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')"); st.db.commit()
# riffle read post 4 BEFORE comment 2 existed: the snapshot holds only c3
project.record_read(st, project.active(st)["id"], 1, 4, "Receipts", "neighbor", 1, 1, "body", "  [c3] other (1 votes): an older comment", "d")
sys.argv = ["cycle", "--config", cp]
try: cycle.main()
except SystemExit: pass
oc = sqlite3.connect(os.path.join(d, "state.sqlite")).execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
print(f"  parent {par} on post {post} (read post 4 earlier, snapshot has only c3): sent={sent} outcome={oc}")
