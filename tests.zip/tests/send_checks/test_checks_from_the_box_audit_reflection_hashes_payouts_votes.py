# ==========================================================================
# Checks written from a three-day audit of the box's records: reflection,
# invented hashes, payouts without work, posts while one waits, the
# ALREADY DONE list, and votes on riffle's own comments.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: reflect; queued; done; hash-fake, hash-
#   library, hash-thread, hash-ownfake and hash-insources; sign-nowork
#   and sign-withwork; note; voteown.
#
# WHY IT EXISTS
#   The box audit (2026-11-03): reflection failed on 182 of ~260
#   attempts and ran a week behind; seven posts cited a placeholder
#   hash; riffle bound listing 13's payout without work and submitted
#   invented prices; it wrote posts while one waited; it repeated
#   refused actions. Then audit round 2: U3 (a hash vouched for by
#   riffle's own sources), U11 (payout refusals in ALREADY DONE) and U15
#   (the self-vote check read the wrong field).
#
# HOW IT WORKS
#   A real cycle per case against a stub registry and composer.
#
# READING THE OUTPUT
#   `[case] outcome '...'` plus a case-specific detail.
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_checks_from_the_box_audit_reflection_
#   hashes_payouts_votes.py . hash-fake
#
# CHANGELOG
#   2026-11-03  Written in the sandbox (taudit.py) for the box audit. Its
#               first run tested nothing in four cases (rationales under 10
#               characters, a wrong library kind, a schema check that matched
#               'post' in another list), fixed before it was trusted.
#   2026-11-04  Cases hash-insources (U3), voteown (U15) and the payout line
#               in done (U11) added.
#   2026-11-05  Moved into tests/send_checks.
#   2026-11-06  Audit round 3, V3: the sign cases also report whether `sign`
#               is offered in the grammar, and a sign-ignored case (riffle
#               submitted to a listing the operator set aside) was added. Its
#               first version set listings.ignore after the harness had
#               written c.yaml, which the cycle reads, so it tested nothing;
#               it now writes the file.
#   2026-11-07  Cases refused-twice and refused-once: riffle's next prompt
#               shows its last refusal in the check's own words, and says when
#               the same thing was refused several times running. On the box
#               riffle proposed one post twenty times, each refused, never
#               told why.
#   2026-11-07  Cases dup-close, close-once, dup-ask and ask-new: an action
#               identical to one already waiting for the operator, or a second
#               close_project for the same project, is refused (already-
#               queued); a different one still goes through. On the box two
#               closes for one project were queued.
#   2026-11-07  Cases seal-invented and seal-library: a seal's hash must be
#               the full sha256 of a library document. On the box riffle
#               signed and sealed an invented hash (eight real characters,
#               then 1234567890abcdef twice) into the registry's permanent
#               record; seals were the one hash-carrying action the invented-
#               hash check skipped.
#   2026-11-09  Cases send-timeout, send-dns and send-429: a comment whose
#               send gets no answer counts against the day unless the request
#               never left (a name-resolution failure), and a 429 'Daily
#               comments spent' raises the day's count to the cap. On the box
#               a timed-out comment that landed left riffle one short, and its
#               20th was refused.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, time
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, memory, library
from agent.state import State, utcnow
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
THREAD_HASH = "9f3c2e7d1b4a6f08"
class Stub:
    def __init__(self, *a, **k): pass
    def listings(self, *a, **k): return {"listings": [{"id": 13, "lifecycle": "open", "title": "Fund MaciekTMPL"}]}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {"id": 1}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
if mode == "queued":
    project.ready = lambda *a, **k: (True, "ready"); project.in_cooldown = lambda *a, **k: (False, None, 0)
drives.pick_drive = lambda *a, **k: {"sign": "earn", "note": "earn"}.get(mode.split("-")[0], "contribute")
seen = {"reflect_calls": 0, "max_tokens": [], "schema_has_post": None, "schema_has_sign": None, "user": ""}
def proposal():
    if mode.startswith("hash"):
        h = {"hash-fake": "a1b2c3d4e5f6...", "hash-library": LIBSHA[:16], "hash-thread": THREAD_HASH, "hash-ownfake": "c0ffee1234abcd99", "hash-insources": "a1b2c3d4e5f60718"}[mode]
        p = {"action": "comment", "payload": {"post_id": 4, "parent_id": 2, "body": f"The script is shelved; its hash is {h} for anyone replicating."}, "rationale": "answering their question about the script"}
        if mode == "hash-insources":
            p["sources"] = {"my_build": f"the build's sha256 is {h}"}
        return p
    if mode == "voteown":
        return {"action": "vote", "payload": {"target_type": "comment", "target_id": 777}, "rationale": "a good comment worth an upvote"}
    # The hash riffle really sealed on the box, assembled here so this file
    # holds no 64-hex run for the deploy's secret scan to take for a key.
    if mode.startswith("send-"):                 # a plain reply, whose send then fails
        return {"action": "comment", "payload": {"post_id": 4, "parent_id": 2, "body": "A plain reply with no figures in it."}, "rationale": "answering their question about the receipts"}
    if mode == "seal-invented":
        return {"action": "seal", "payload": {"hash": ("78805fea5876ac16d" + "1234567890abcdef" * 2 + "1234567890abcd1"), "label": "listing-13-binding-proof"}, "rationale": "sealing the proof of the binding artifact"}
    if mode == "seal-library":                   # the full sha256 of a library document
        return {"action": "seal", "payload": {"hash": LIBSHA, "label": "solve-py"}, "rationale": "sealing the shelved solve.py artifact"}
    if mode in ("dup-close", "close-once"):
        return {"action": "close_project", "payload": {"reason": "The question is answered by the simulation and the post is written."}, "rationale": "closing the finished project now"}
    if mode in ("dup-ask", "ask-new"):
        return {"action": "ask_operator", "payload": {"question": "Should the project post cite library #233 by its sha256?"}, "rationale": "asking before I post the project"}
    if mode.startswith("sign"):
        return {"action": "sign", "payload": {"kind": "payout", "row": "listing-13"}, "rationale": "bind the payout for this listing"}
    if mode.startswith("note"):
        return {"action": "listing_submission", "payload": {"listing_id": 13, "artifact": "https://example.org/snapshot.json", "note": "Snapshot: BTC $84,120.50, ETH $2,245.30, verified against live endpoints this cycle."}, "rationale": "earning through the open listing"}
    return {"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing this cycle"}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" in user:
        seen["user"] = user
        seen["schema_has_post"] = any(((b.get("properties") or {}).get("action") or {}).get("const") == "post" for b in (schema or {}).get("oneOf", []))
        seen["schema_has_sign"] = any(((b.get("properties") or {}).get("action") or {}).get("const") == "sign" for b in (schema or {}).get("oneOf", []))
        return json.dumps(proposal())
    if "DURABLE" in (system or ""):
        seen["reflect_calls"] += 1; seen["max_tokens"].append((llm or {}).get("max_tokens"))
        return "DURABLE\n- me: I learned something short.\nPASSING\n"
    return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
cortex.complete = complete
d = tempfile.mkdtemp(); root = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d; cfg["library"]["root"] = root
for k in ("comment", "sign", "listing_submission", "vote", "seal"): cfg["autonomy"][k] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
library.put(st, "solve.py", "print(1)", kind="code", source="build", root=root)
LIBSHA = st.db.execute("SELECT sha256 FROM library").fetchone()[0]
pid = project.active(st)["id"]
project.record_read(st, pid, 1, 9823, "A thread", "coppice", 1, 1, f"Commit {THREAD_HASH} fixed the ordering.", "  [c1] x: ok", "d")
def act(kind, payload, status="executed", at=None):
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,?,?,?,'r',?)", (at or utcnow(), kind, "x", json.dumps(payload), status))
if mode == "reflect":
    week = "2026-10-20T00:00:00Z"
    for i in range(6): st.db.execute("INSERT INTO cycles (started_at,ended_at,drive,outcome) VALUES (?,?,'understand','noop')", (week, week))
    for i in range(5):
        t = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 3600 * (5 - i)))
        st.db.execute("INSERT INTO cycles (started_at,ended_at,drive,outcome) VALUES (?,?,'understand','noop')", (t, t))
    st.note("last_reflected_cycle", "0")
if mode == "queued": act("post", {"title": "A waiting post", "body": "b"}, "queued")
if mode == "done":
    act("vote", {"target_type": "post", "target_id": 10596}); act("comment", {"post_id": 4, "parent_id": 128800, "body": "a reply"})
    st.db.execute("INSERT INTO cycles (started_at,ended_at,drive,outcome,notes) VALUES (?,?,'earn','payout-without-work','13')", (utcnow(), utcnow()))
if mode.startswith("send-"):                   # the registry's answer replaced by a failure from the box's log
    from agent.client import HttpError
    _fail = {"send-timeout": HttpError(0, "TimeoutError: The read operation timed out"),
             "send-dns": HttpError(0, "URLError: <urlopen error [Errno -3] Temporary failure in name resolution>"),
             "send-429": HttpError(429, {"error": "Daily comments spent (20/day). Return tomorrow."})}[mode]
    def _send_fails(*a, **k):
        raise _fail
    cycle.execute = _send_fails
if mode == "dup-close":                        # a close for this project already waiting
    act("close_project", {"reason": "An earlier close, worded differently, still waiting.", "project_id": pid}, "queued")
if mode == "dup-ask":                          # the very same question already waiting
    act("ask_operator", {"question": "Should the project post cite library #233 by its sha256?", "why": ""}, "queued")
if mode == "ask-new":                          # a different question waiting
    act("ask_operator", {"question": "Is listing 16 still worth working on?", "why": ""}, "queued")
if mode in ("refused-twice", "refused-once"):     # earlier cycles refused, each with its report
    for i in range(2 if mode == "refused-twice" else 1):
        t = utcnow()
        c = st.db.execute("INSERT INTO cycles (started_at,ended_at,drive,outcome,notes) VALUES (?,?,'make','hash-unknown','27fb78dff1d198cef213110d6ba860127f7a090c')", (t, t)).lastrowid
        st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (?,?,'post','make',?,'r','blocked')", (c, t, json.dumps({"title": "T", "body": "b"})))
        st.say("report", f"Cycle {c} \u00b7 I did not send that: it gives the hash 27fb78dff1d198cef213110d, and no build, library document or thread you read carries it.")
if mode == "voteown":
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status,response) VALUES (1,?,'comment','answer',?,'r','executed',?)",
                  (utcnow(), json.dumps({"post_id": 4, "parent_id": 2, "body": "my comment"}), json.dumps({"post_id": 4, "comment_id": 777})))
if mode == "hash-ownfake": act("comment", {"post_id": 7, "body": "earlier I said the hash is c0ffee1234abcd99"})
if mode in ("sign-withwork", "sign-ignored"): act("listing_submission", {"listing_id": 13, "artifact": "https://x.org/a", "note": "n"})
if mode == "sign-ignored":                 # the cycle reads c.yaml, so write it there too
    cfg["listings"] = {"ignore": [13]}; yaml.safe_dump(cfg, open(cp, "w"))
st.db.commit()
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
oc = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
u = seen["user"]; own = u.split("<board>")[0] + (u.split("</board>")[1] if "</board>" in u else "")
extra = ""
if mode == "reflect":
    _thr = db.execute("SELECT value FROM notes WHERE key='last_reflected_cycle'").fetchone()[0]
    _max = db.execute("SELECT MAX(id) FROM cycles").fetchone()[0]
    extra = f"reflections this wake {seen['reflect_calls']}, max_tokens {set(seen['max_tokens'])}, reflected through {_thr} of {_max}"
if mode == "queued": extra = f"post offered in the grammar: {seen['schema_has_post']}"
if mode.startswith("sign"): extra = f"sign offered in the grammar: {seen['schema_has_sign']}"
if mode.startswith("send-"):
    extra = f"comments counted today: {st.db.execute('SELECT COALESCE(MAX(used),0) FROM caps WHERE kind=?', ('comment',)).fetchone()[0]}"
if mode.startswith("refused"):
    _tail = u.split("</board>", 1)[1] if "</board>" in u else ""
    extra = (f"refusal shown after </board>: {'YOUR LAST REFUSAL' in _tail} | the check's words: "
             f"{'no build, library document' in _tail} | repeat line: "
             f"{'REFUSED 2 TIMES IN A ROW' in _tail}")
if mode == "done":
    blk = [l for l in own.split("\n\n") if l.startswith("ALREADY DONE")]
    extra = f"ALREADY DONE on riffle's side: {bool(blk)}" + (f" | payout refusal listed: {'listing 13' in blk[0]}" if blk else "")
print(f"  [{mode:13}] outcome {oc!r:22} {extra}")
if os.environ.get("JRN"):
    for (lvl, t) in db.execute("SELECT level, text FROM journal WHERE level IN ('warn','error') ORDER BY id DESC LIMIT 4"): print("     J", lvl, t[:170])
