# ==========================================================================
# An approved close_project closes the project it was proposed for, and a
# stale one (proposed for a project that is no longer active) is refused.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks `normal` or `stale`: the approved action's status
#   and the projects' states afterwards.
#
# WHY IT EXISTS
#   M7 (audit round 1): a queued close_project recorded no project, so
#   if another project had become active by the time it was approved,
#   the wrong one was closed.
#
# HOW IT WORKS
#   A real cycle runs the approved action.
#
# READING THE OUTPUT
#   `[mode] approved close #900 -> 'status' | projects [...]`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm78.py) for M7.
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, project
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"}) \
    if "Choose ONE action" in user else json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
db = st.db
db.execute("INSERT INTO projects (id,opened_at,title,question,status) VALUES (1,'2026-10-20T00:00:00Z','First question','Q1?','active')")
if mode == "stale":         # #1 closed as posted while the close waited; #2 started
    db.execute("UPDATE projects SET status='posted' WHERE id=1")
    db.execute("INSERT INTO projects (id,opened_at,title,question,status) VALUES (2,'2026-10-26T00:00:00Z','Second question','Q2?','active')")
status = "running" if mode == "interrupted" else "approved"
db.execute("INSERT INTO actions (id,cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (900,1,'2026-10-25T00:00:00Z','close_project','deepen',?,'stuck','%s')" % status,
           (json.dumps({"reason": "I have stopped being able to move this question.", "project_id": 1}),))
db.commit()
sys.argv = ["cycle", "--config", cp]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
a = db.execute("SELECT status FROM actions WHERE id=900").fetchone()[0]
ps = db.execute("SELECT id, status FROM projects ORDER BY id").fetchall()
print(f"  [{mode:11}] approved close #900 -> {a!r} | projects {ps}")
