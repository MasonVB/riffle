# ==========================================================================
# The reference checker accepts a real quote of a page riffle read, with
# its URL, and rejects every way a reference can be fake or missing.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Three real references pass (straight quotes and a full URL, curly
#   quotes without https, a quote with an ellipsis); five fail (no URL,
#   a URL never read, no quote, invented words, a real quote cited
#   against the wrong page).
#
# WHY IT EXISTS
#   The reference rule is worth nothing if a made-up quote or an unread
#   URL passes.
#
# HOW IT WORKS
#   Calls agent/reference.py directly with a library holding two 'read'
#   pages.
#
# READING THE OUTPUT
#   One line per case, `referenced|no reference ok`; WRONG is the
#   failure, and the last line is ALL CORRECT.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tref.py) for the reference rule.
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import library, reference
d = tempfile.mkdtemp(); root = tempfile.mkdtemp()
st = State(os.path.join(d, "s.sqlite")); library.ensure(st, root)
cfg = {"library": {"root": root}}
page = ("Henry VIII was King of England from 22 April 1509 until his death in 1547. "
        "He is best known for his six marriages and his efforts to have his first marriage annulled. "
        "His disagreement with Pope Clement VII led to the separation of the Church of England from papal authority.")
library.put(st, "en.wikipedia.org: Henry_VIII [written by anyone]", page, kind="page", source="https://en.wikipedia.org/wiki/Henry_VIII", root=root)
library.put(st, "physics.nist.gov: constants", "The speed of light in vacuum is exactly 299 792 458 metres per second.", kind="page", source="https://physics.nist.gov/cuu/Constants/", root=root)
cases = [
 ("Mason's format", True, 'And, as shown here on Wikipedia, "His disagreement with Pope Clement VII led to the separation of the Church of England" (URL: https://en.wikipedia.org/wiki/Henry_VIII)'),
 ("curly quotes, no https", True, 'Wikipedia says \u201che is best known for his six marriages\u201d (en.wikipedia.org/wiki/Henry_VIII).'),
 ("quote with an ellipsis", True, 'It notes "Henry VIII was King of England ... until his death in 1547" (https://en.wikipedia.org/wiki/Henry_VIII#Reign).'),
 ("no URL", False, 'Wikipedia says "he is best known for his six marriages" and that is that.'),
 ("URL never read", False, 'See "he is best known for his six marriages" (https://en.wikipedia.org/wiki/Anne_Boleyn).'),
 ("URL read, no quote", False, 'Henry broke with Rome over his marriage (https://en.wikipedia.org/wiki/Henry_VIII).'),
 ("invented quote", False, 'Wikipedia says "Henry the IV was the reason England went away from Catholicism" (https://en.wikipedia.org/wiki/Henry_VIII).'),
 ("real quote, wrong page", False, 'As "he is best known for his six marriages" (https://physics.nist.gov/cuu/Constants/).'),
]
bad = 0
for label, want, text in cases:
    ok, detail = reference.check(st, cfg, text)
    bad += ok != want
    print(f"  {label:24} {'referenced' if ok else 'no reference':13} {'ok' if ok == want else 'WRONG'} | {detail[:70]}")
print("ALL CORRECT" if not bad else f"{bad} WRONG")
