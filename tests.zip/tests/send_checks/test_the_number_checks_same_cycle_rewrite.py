# ==========================================================================
# When one or two figures block a draft, the composer is asked once more
# in the same cycle, under the composer lock, with a retry if that reply
# is cut off; only the new body is used.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: `fixed` (the rewrite drops the figure and
#   is sent, still to the original parent), `still` (still has the
#   figure: blocked), `other` (comes back as another action: blocked),
#   `raise` (the call fails: blocked), `three` (three figures: no
#   rewrite), `crash` (the checker itself fails: numcheck-error), `busy`
#   (a chat turn holds the composer: no rewrite) and `cutoff` (the
#   rewrite is cut off: retried shorter, then sent).
#
# WHY IT EXISTS
#   M13 (audit round 1): 93 of 154 number-check blocks were a single
#   figure, each costing a whole cycle. U8 (round 2): the rewrite ran
#   without the composer lock, and had no cut-off retry.
#
# HOW IT WORKS
#   A real cycle whose stub composer answers the first call with an
#   untraceable figure and the rewrite as each case needs.
#
# READING THE OUTPUT
#   `[case] outcome=... model calls=N | sent=...`.
#
# RUNNING IT ON ITS OWN
#   python3
#   tests/send_checks/test_the_number_checks_same_cycle_rewrite.py .
#   fixed
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tretry.py) for M13.
#   2026-11-04  Cases `busy` and `cutoff` added for U8.
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
sent = []
class Stub:
    def __init__(self, *a, **k): pass
    def create_comment(self, post_id, body, parent_id=None): sent.append((post_id, parent_id, body)); return {"comment_id": 5, "created_at": 1}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "answer"
if mode == "crash":
    cycle.run_numcheck = lambda *a, **k: (False, {"error": "numcheck failed to run: TimeoutExpired after 120 seconds"})
first = {"three": "Receipts: 4,210 late, 7,391 early and 6,644 lost, so the order breaks."}.get(mode, "I counted 4,210 receipts that settled out of order, so the order is not guaranteed.")
calls = []
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    calls.append(user[-200:])
    if "YOUR DRAFT WAS NOT SENT" in user:
        if mode == "raise": raise RuntimeError("composer died")
        if mode == "cutoff" and "YOUR LAST REPLY WAS CUT OFF" not in user:
            Cut = getattr(cortex, "CutOff", None)
            msg = "the model hit its 4000-token ceiling and was cut off mid-output (11608 chars, 3.6 chars/token, 20% whitespace)"
            if Cut: raise Cut(msg, 11608, 3.6, 0.2, 4000)
            raise ValueError(msg)
        if mode == "other": return json.dumps({"action": "vote", "payload": {"target_type": "post", "target_id": 4}, "rationale": "x"})
        b = "I counted 4,210 receipts out of order." if mode == "still" else "Many receipts settled out of order, so the order is not guaranteed."
        return json.dumps({"action": "comment", "payload": {"post_id": 4, "parent_id": 999, "body": b}, "rationale": "rewritten"})
    return json.dumps({"action": "comment", "payload": {"post_id": 4, "parent_id": 2, "body": first}, "rationale": "answering their claim"})
cortex.complete = complete
if mode == "busy":                       # a chat turn holds the composer when the rewrite wants it
    from agent import chat
    _real_acq = chat.ComposerLock.acquire
    _n = [0]
    def _acq(self, *a, **k):
        _n[0] += 1
        return False if _n[0] >= 2 else _real_acq(self, *a, **k)
    chat.ComposerLock.acquire = _acq
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d; cfg["autonomy"]["comment"] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')"); st.db.commit()
sys.argv = ["cycle", "--config", cp]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
oc = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
err = db.execute("SELECT COUNT(*) FROM journal WHERE level='error' AND text LIKE 'numcheck could not run%TimeoutExpired%'").fetchone()[0]
s = sent[0] if sent else None
print(f"  [{mode:5}] outcome={oc!r:22} model calls={len(calls)} | sent={'post %s, parent %s: %r' % (s[0], s[1], s[2][:44]) if s else 'nothing'}" + (f" | error logged={bool(err)}" if mode == "crash" else ""))
