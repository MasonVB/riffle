# ==========================================================================
# The post reference rule: at least one post in four quotes a page riffle
# read, with its URL; and any post that links an outside page must quote
# it.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Arguments: posts in a row without a reference, refusals so far, and
#   the post's kind. Kinds: `plain`, `ref` (a real quote of a page
#   read), `fig` (a figure, which the number check stops first),
#   `linknoread` (links a page never read), `linknoquote` (links a page
#   read without quoting it) and `registry` (links the registry itself).
#   The result: the outcome, whether it was sent, the counts afterwards,
#   and which reminder the prompt carried.
#
# WHY IT EXISTS
#   The operator's reference rule (2026-10-29), and, on 2026-11-04, a
#   post that attached a Wikipedia link nothing in it used.
#
# HOW IT WORKS
#   A real cycle with a page riffle 'read' in its library.
#
# READING THE OUTPUT
#   `start S/F KIND -> outcome '...' sent=... | now S/F | prompt had:
#   ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_post_references_and_links_must_be_quo
#   ted_from_a_page_read.py . 0 0 linknoread
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tpostref.py) for the reference rule;
#               its first runs had a figure in the test post, which the number
#               check stopped before the rule was reached.
#   2026-11-04  Link cases added for the link rule.
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, streak, fails, kind = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
sent = []
class Stub:
    def __init__(self, *a, **k): pass
    def create_post(self, *a, **k): sent.append(a); return {"post_id": 777, "created_at": 1}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "contribute"
project.ready = lambda *a, **k: (True, "ready")
project.in_cooldown = lambda *a, **k: (False, None, 0)
URL = "https://en.wikipedia.org/wiki/Henry_VIII"
body = {"plain": "The settlement under Henry changed English religion for good, and I think the timing matters more than the motive.",
        "fig": "The settlement of 1534 changed English religion for good, and the timing matters more than the motive.",
        "linknoread": "Absence has four routes, and the taxonomy separates them by witness and scope.",
        "linknoquote": "Henry broke with Rome over his marriage, and the timing matters more than the motive.",
        "registry": "As argued on the docket at https://1f916.ai/docket the timing matters more than the motive.",
        "ref": 'As shown on Wikipedia, "His disagreement with Pope Clement VII led to the separation of the Church of England" (URL: ' + URL + '). The timing matters more than the motive.'}[kind]
users = []
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    users.append(user)
    _pl = {"title": "Why the timing matters", "body": body}
    if kind == "linknoread": _pl["url"] = "https://en.wikipedia.org/wiki/Null_(computer_programming)"
    if kind == "linknoquote": _pl["url"] = URL
    return json.dumps({"action": "post", "payload": _pl, "rationale": "my project's answer is ready"})
cortex.complete = complete
d = tempfile.mkdtemp(); root = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg["autonomy"]["post"] = "auto"; cfg["library"]["root"] = root
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','Tudor','Q?','active')"); st.db.commit()
library.put(st, "en.wikipedia.org: Henry_VIII [written by anyone]",
            "Henry VIII was King of England from 1509 until 1547. His disagreement with Pope Clement VII led to the separation of the Church of England from papal authority.",
            kind="page", source=URL, root=root)
st.note("post_ref_streak", streak); st.note("post_ref_forced_fails", fails)
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
oc = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
n = lambda k: (db.execute("SELECT value FROM notes WHERE key=?", (k,)).fetchone() or ["-"])[0]
u = users[-1] if users else ""
own = u.split("<board>", 1)[0]
blk = "NEEDS-A-REFERENCE block" if "A POST NOW NEEDS A REFERENCE" in own else ("light reminder" if "REFERENCES IN POSTS" in own else "no block")
msg = db.execute("SELECT content FROM messages WHERE content LIKE '%could not trace%' ORDER BY id DESC LIMIT 1").fetchone()
if msg: print("  numcheck message ends:", msg[0][-150:])
print(f"  start {streak}/{fails} {kind:5} -> outcome {oc!r:24} sent={bool(sent)} | now {n('post_ref_streak')}/{n('post_ref_forced_fails')} | prompt had: {blk}")
