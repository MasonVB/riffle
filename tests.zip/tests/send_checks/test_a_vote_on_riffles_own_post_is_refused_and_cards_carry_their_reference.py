# ==========================================================================
# A vote on riffle's own post is refused before it reaches the registry,
# and a sent comment's card carries its reference.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: `vote` (on riffle's own post 77: outcome,
#   whether anything was sent, the reason) or `comment` (outcome and the
#   card's ref).
#
# WHY IT EXISTS
#   M2 (audit round 1): the self-vote check read an `id` field the
#   registry's create answers do not have, so it never matched, and each
#   vote on riffle's own work cost a cycle and a 403. U15 (round 2)
#   later made it read the right field for each kind.
#
# HOW IT WORKS
#   A real cycle; the stub registry's create answers carry post_id and
#   comment_id, not id.
#
# READING THE OUTPUT
#   `vote on riffle's own post 77: outcome='voted-own', sent to
#   registry=False | ...` or the comment line.
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_a_vote_on_riffles_own_post_is_refused
#   _and_cards_carry_their_reference.py . vote
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm2.py) for M2.
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
sent = []
class Stub:
    def __init__(self, *a, **k): pass
    def vote(self, *a, **k): sent.append(("vote", a)); return {"ok": True}
    def create_comment(self, post_id, body, parent_id=None):
        sent.append(("comment", post_id)); return {"comment_id": 123456, "created_at": 1}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "curate" if mode == "vote" else "answer"
act = ({"action": "vote", "payload": {"target_type": "post", "target_id": 77}, "rationale": "a strong post worth lifting"} if mode == "vote"
       else {"action": "comment", "payload": {"post_id": 4, "parent_id": 2, "body": "You wrote that receipts settle in order; I checked forty and two did not."}, "rationale": "answering their claim"})
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps(act) if "Choose ONE action" in user else \
    json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
for k in ("vote", "comment"): cfg["autonomy"][k] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status,response) VALUES (1,'2026-10-25T00:00:00Z','post','contribute','{}','r','executed',?)",
              (json.dumps({"post_id": 77, "created_at": 1, "message": "Posted."}),))
st.db.commit()
sys.argv = ["cycle", "--config", cp]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
oc = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
if mode == "vote":
    why = [r[0][:110] for r in db.execute("SELECT text FROM journal WHERE level IN ('warn','error') ORDER BY id DESC LIMIT 3")]
    print(f"  vote on riffle's own post 77: outcome={oc!r}, sent to registry={bool(sent)} | {why}")
else:
    meta = [json.loads(m[0] or "{}") for m in db.execute("SELECT meta FROM messages WHERE meta LIKE '%ref%' ORDER BY id DESC LIMIT 3")]
    print(f"  comment sent: outcome={oc!r}, card ref={[m.get('ref') for m in meta if m.get('ref')][:1]}")
