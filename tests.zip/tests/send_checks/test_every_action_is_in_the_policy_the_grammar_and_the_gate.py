# ==========================================================================
# Every action riffle can take is listed in the policy, has a branch in
# the grammar (proposal_schema.json) and an entry in the gate
# (drives.SCHEMA), with nothing extra in any of them.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The three counts and whether the three sets agree exactly (the
#   policy plus `noop`).
#
# WHY IT EXISTS
#   A new action missing from any one of the three is either impossible
#   to propose or impossible to check. search_web (2026-10-29) was the
#   last one added; this caught nothing then, which is the point.
#
# HOW IT WORKS
#   Reads the three lists.
#
# READING THE OUTPUT
#   `P G S True`: P actions in the policy, G grammar branches and S gate
#   entries (both one more, for noop), and True.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-23  Run inline in the sandbox's suite; it had no file.
#   2026-11-05  Given a file of its own in tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import json
import sys
sys.path.insert(0, ".")                 # the tree: run from its root
from agent import policy, drives
g = {b["properties"]["action"]["const"] for b in json.load(open("proposal_schema.json"))["oneOf"]}
print(len(set(policy.ACTION_KINDS)), len(g), len(set(drives.SCHEMA)),
      set(policy.ACTION_KINDS) | {"noop"} == g == set(drives.SCHEMA))
