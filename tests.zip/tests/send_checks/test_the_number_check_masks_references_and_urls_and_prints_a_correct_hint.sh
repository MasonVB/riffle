#!/bin/bash
# ==========================================================================
# The number check (numcheck.py) does not mistake post references, comment
# ids, HTML character codes or URLs for figures, still checks real
# figures, and prints `%` in its hint.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For a draft citing #1346, c121264 and &#1346; alongside a backed
#   figure (4,210), that nothing is flagged; and that the hint for an
#   ambiguous percentage reads `37.5% [[a/b*100]]`.
#
# WHY IT EXISTS
#   M13 (audit round 1): a recalled '#1346' blocked a post as an
#   unbacked figure, and the hint printed '%%'. URLs were masked later,
#   when a thread link's post id (https://1f916.ai/posts/9823) blocked a
#   post.
#
# HOW IT WORKS
#   Runs numcheck.py (argument 1) on two drafts with a small sources
#   file.
#
# READING THE OUTPUT
#   `figures flagged: none` and the hint's last 40 characters.
#
# RUNNING IT ON ITS OWN
#   tests/send_checks/test_the_number_check_masks_references_and_urls_an
#   d_prints_a_correct_hint.sh numcheck.py
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tnum.sh) for M13.
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
# numcheck.py on a draft with post/comment references and a backed figure; and the hint text.
src=$1; d=$(mktemp -d); mkdir $d/s
printf 'As #1346 argued, and c121264 replied, 4,210 receipts settled out of order. See &#1346; too.\n' > $d/draft.md
echo '{"tally": "receipts out of order: 4,210 of the batch"}' > $d/s/sources.json
python3 $src $d/draft.md $d/s --json --agent | python3 -c "import json,sys; d=json.load(sys.stdin); print('  figures flagged:', [(f['token'], f['status']) for f in d.get('findings', []) if f.get('status') in ('UNBACKED','AMBIGUOUS','MALFORMED')] or 'none')"
printf 'The rate was 37.5%% overall.\n' > $d/draft2.md
echo '{"a": "3 of 8 failed; 6 of 16 failed; 30 of 80 failed"}' > $d/s/sources.json
python3 $src $d/draft2.md $d/s --json --agent | python3 -c "import json,sys; d=json.load(sys.stdin); n=[f.get('note','') for f in d.get('findings',[]) if f.get('status')=='AMBIGUOUS']; print('  ambiguous hint:', n[0][-40:] if n else '(no ambiguous finding)')"
