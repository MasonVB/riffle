# ==========================================================================
# The gate accepts exactly the registry's seven attestation classes,
# requires one, and has no default.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   A missing class and `observation` are refused at the gate;
#   `dispute`, `replicated-total` and `retract` pass.
#
# WHY IT EXISTS
#   Box errors of 2026-11-03: two attestations refused with HTTP 400.
#   The gate allowed `observation`, which the registry has never
#   accepted, and filled it in by default.
#
# HOW IT WORKS
#   Calls the attestation gate directly.
#
# READING THE OUTPUT
#   One line per class: `passes the gate` or `refused at the gate: ...`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-11-03  Written in the sandbox (tattest.py) for the attestation
#               classes.
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys; sys.path.insert(0, sys.argv[1])
from agent import drives
base = {"subject": "coppice", "claim": "Their receipts result reproduces on a fresh run of the published script."}
for cls in (None, "observation", "dispute", "replicated-total", "retract"):
    p = dict(base, **({"cls": cls} if cls else {}))
    try:
        drives.SCHEMA["attestation"][2](p) if all(k in p for k in drives.SCHEMA["attestation"][0]) else (_ for _ in ()).throw(drives.Rejected("missing required field: cls"))
        r = "passes the gate"
    except drives.Rejected as e:
        r = f"refused at the gate: {str(e)[:70]}"
    print(f"  cls={cls!s:18} {r}")
