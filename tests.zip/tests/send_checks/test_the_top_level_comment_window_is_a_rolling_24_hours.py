# ==========================================================================
# Riffle may comment top-level on a post once per rolling 24 hours: a
# comment 23 hours ago blocks, one just over 24 hours ago (on the same
# calendar date as the cutoff) does not, and replies never count.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For four comments (just over 24 h old on the cutoff's date, 23 h
#   old, a 23 h old reply, 49 h old), whether each blocks a new top-
#   level comment on its post.
#
# WHY IT EXISTS
#   The earlier review: the window was compared by date, so it lasted
#   anywhere from 24 to 48 hours. Round-1 T13 later made it count from
#   when a comment was sent.
#
# HOW IT WORKS
#   Inserts the four comments and calls cycle.top_level_today for each
#   post.
#
# READING THE OUTPUT
#   `post N: blocked=... expected=... ok`; WRONG is the failure.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-23  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, datetime as dt; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import cycle
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
now = dt.datetime.now(dt.timezone.utc)
def add(hours_ago, post, parent=None):
    ts = (now - dt.timedelta(hours=hours_ago)).strftime("%Y-%m-%dT%H:%M:%SZ")
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
                  " VALUES (1,?,?,?,?,?,?)", (ts, "comment", "x",
                  json.dumps({"post_id": post, "parent_id": parent, "body": "b"}), "", "sent"))
    st.db.commit()
# same calendar date as the cutoff, but more than 24h old: earliest second of yesterday
yday0 = (now - dt.timedelta(days=1)).replace(hour=0, minute=0, second=1)
h = (now - yday0).total_seconds() / 3600
add(h, 1)          # >24h old, on the cutoff's date
add(23, 2)         # inside 24h
add(23, 3, parent=99)   # a reply, never counts
add(49, 4)         # two days back
for post, want in ((1, False), (2, True), (3, False), (4, False)):
    got = cycle.top_level_today(st, post) is not None
    print(f"  post {post}: blocked={got} expected={want} {'ok' if got == want else 'WRONG'}")
print(f"  (post 1's comment is {h:.1f}h old)")
