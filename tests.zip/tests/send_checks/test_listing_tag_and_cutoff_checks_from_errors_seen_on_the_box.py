# ==========================================================================
# Checks written from errors on the box: submissions only to open listings
# (and never to one the operator set aside), at most five of riffle's tags
# per post, and one shorter retry when the composer is cut off.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: lst-withdrawn, lst-open, lst-nofetch and
#   lst-ignored (listings); tag-sixth, tag-again and tag-afterremove
#   (the five-tag limit); cut-once, cut-loop and cut-twice (the cut-off
#   retry).
#
# WHY IT EXISTS
#   From the box's error log (2026-10-27 to 11-03): a submission to
#   listing 15, withdrawn in September (409); a sixth tag on one post
#   (429); two `make` cycles lost at the 4,000-token ceiling. And from
#   2026-11-04: listing 13, a request to fund another citizen, which
#   riffle kept trying to claim, now set aside in config
#   (listings.ignore).
#
# HOW IT WORKS
#   A real cycle against a stub registry serving one open listing (13)
#   with a unique title, with the composer answering as each case needs.
#
# READING THE OUTPUT
#   `[case] outcome '...' model calls N`, plus for listing cases whether
#   listing 13 was in the prompt.
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_listing_tag_and_cutoff_checks_from_er
#   rors_seen_on_the_box.py . lst-ignored
#
# CHANGELOG
#   2026-11-03  Written in the sandbox (terr.py) for the box's errors.
#   2026-11-04  Case lst-ignored added for listings.ignore; the stub listing's
#               title changed from 'an open row' (which also appears in the
#               make drive's description) to a unique string.
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project
from agent.state import State, utcnow
from agent.client import HttpError
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
LISTINGS = [{"id": 13, "lifecycle": "open", "title": "ZQ-FUND-SOMEONE-ELSE"}]
sent = []
class Stub:
    def __init__(self, *a, **k): pass
    def listings(self, *a, **k):
        if mode == "lst-nofetch": raise HttpError(503, "down")
        return {"listings": LISTINGS}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: (sent.append(n), {"id": 1})[1]
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: {"lst": "earn", "tag": "curate", "cut": "make"}[mode.split("-")[0]]
Cut = getattr(cortex, "CutOff", None)
def cutoff(cpt):
    msg = f"the model hit its 4000-token ceiling and was cut off mid-output (14000 chars, {cpt} chars/token, 20% whitespace; ends '...')"
    if Cut: raise Cut(msg, 14000, cpt, 0.2, 4000)
    raise ValueError(msg)
calls = [0]
PROMPT = [""]
def proposal():
    if mode.startswith("lst"):
        lid = 13 if mode in ("lst-open", "lst-ignored") else 15
        return {"action": "listing_submission", "payload": {"listing_id": lid, "artifact": "https://example.org/artifact.tar", "note": "a submission note for the row"}, "rationale": "submitting work"}
    if mode.startswith("tag"):
        t = {"tag-sixth": "sixth", "tag-again": "three", "tag-afterremove": "sixth"}[mode]
        return {"action": "tag", "payload": {"post_id": 4, "tag": t}, "rationale": "labelling what I read"}
    return {"action": "noop", "payload": {"why": "a short reply after a long cut-off one"}, "rationale": "nothing more this cycle"}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    calls[0] += 1
    PROMPT[0] = user
    if mode.startswith("cut"):
        if mode == "cut-loop": cutoff(1.2)
        if mode == "cut-twice" or calls[0] == 1: cutoff(3.5)
    return json.dumps(proposal())
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
for k in ("listing_submission", "tag", "project_note"): cfg["autonomy"][k] = "auto"
if mode == "lst-ignored": cfg["listings"] = {"ignore": [13]}
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
if mode.startswith("tag"):
    for t in ("one", "two", "three", "four", "five"):
        st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'tag','curate',?,'r','executed')", (utcnow(), json.dumps({"post_id": 4, "tag": t, "remove": False})))
    if mode == "tag-afterremove":
        st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'tag','curate',?,'r','executed')", (utcnow(), json.dumps({"post_id": 4, "tag": "two", "remove": True})))
st.db.commit()
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
oc = sqlite3.connect(os.path.join(d, "state.sqlite")).execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
print(f"  [{mode:16}] outcome {oc!r:26} model calls {calls[0]}" + (f" | listing 13 in the prompt: {'ZQ-FUND-SOMEONE-ELSE' in PROMPT[0]}" if mode.startswith("lst-") and mode != "lst-nofetch" else ""))
