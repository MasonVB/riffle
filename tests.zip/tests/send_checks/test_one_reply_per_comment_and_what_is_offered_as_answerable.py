# ==========================================================================
# Riffle replies once per comment: a comment it answered is no longer
# offered as answerable; and a thread re-read with no new comments counts
# as already read.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The outcomes of two cycles (a reply, then the same reply refused),
#   whether the second cycle's answerable list still offers the answered
#   comment, the porch's place in the grammar after three porch lines,
#   and already_read with the same and a larger comment count.
#
# WHY IT EXISTS
#   The earlier review: riffle answered the same comment more than once.
#
# HOW IT WORKS
#   Two real cycles against a stub registry, the composer proposing the
#   same reply both times.
#
# READING THE OUTPUT
#   `outcomes: run 1 ..., run 2 ...`, then the answerable list, the
#   porch, and already_read.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-25  Written in the sandbox (hrep.py) during the earlier review.
#   2026-11-05  Moved into tests/send_checks. Its sandbox wrapper (trep.sh)
#               ran it on an extracted copy of the previous version and on the
#               change, labelled 'original' and 'fixed'; packaged, it checks
#               the one tree it is given, and tests/compare_two_versions.sh
#               does the comparison.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, project
from agent.state import State, utcnow
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {"id": 1})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
seen = []
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"}) if "continuity" in (schema or {}).get("required", []) else json.dumps({"promote": [], "write": [], "drop": [], "note": ""})
    consts = [b["properties"]["action"].get("const") for b in schema["oneOf"]]
    seen.append({"porch_in_grammar": "porch" in consts, "user": user})
    return json.dumps({"action": "comment", "payload": {"post_id": 4, "parent_id": 2,
        "body": "You wrote that the receipts settle in order. I checked the last forty myself and two settle out of order."}, "rationale": "answering their point about order"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg["autonomy"]["comment"] = "auto"; cfg["caps"].pop("porch", None)    # the box's config.yaml has no porch cap
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')"); st.db.commit()
project.record_read(st, project.active(st)["id"], 1, 4, "Receipts", "neighbor", 2, 2, "body",
                    "  [c2] example-neighbor (5 votes): PROPOSAL 1\n  [c3] other (1 votes): A second comment", "d")
for _ in range(3): st.cap_bump(utcnow()[:10], "porch")
out = []
for run in (1, 2):
    sys.argv = ["cycle", "--config", cp] + (["--force"] if run == 2 else [])
    try: cycle.main()
    except SystemExit: pass
    if cycle._CYCLE_LOCK: cycle._CYCLE_LOCK.close(); cycle._CYCLE_LOCK = None
    out.append(sqlite3.connect(os.path.join(d, "state.sqlite")).execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0])
print(f"  outcomes: run 1 {out[0]}, run 2 {out[1]}")
if seen:
    u = seen[-1]["user"]; blk = u.split("COMMENTS YOU COULD ANSWER")[1][:400] if "COMMENTS YOU COULD ANSWER" in u else ""
    print(f"  run 2 answerable list: offers c2 {'[c2]' in blk}, offers c3 {'[c3]' in blk} | porch in grammar after 3 sent: {seen[-1]['porch_in_grammar']}")
pid = project.active(st)["id"]
print(f"  already_read, same count: {project.already_read(st, pid, 4, total_now=2)}; new comments: {project.already_read(st, pid, 4, total_now=5)}")
