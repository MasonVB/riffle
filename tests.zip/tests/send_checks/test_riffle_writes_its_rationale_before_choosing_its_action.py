# ==========================================================================
# riffle writes its rationale before it chooses its action and target: the
# grammar puts `rationale` first in every action, and riffle's instructions
# show the same order.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That in proposal_schema.json every branch (one per action) lists
#   `rationale` before `action` and `payload`, and that the reply format in
#   riffle's instructions (cortex.CONTRACT) shows `rationale` first too.
#   llama.cpp writes a schema's fields in the order the schema lists them
#   (its JSON type keeps keys in insertion order; checked with the box's own
#   converter at llama.cpp 70adb1b4c), so this order is the order riffle
#   writes in.
#
# WHY IT EXISTS
#   V4 (audit round 3): riffle repeated actions it had already taken. Its
#   records showed why: in four of ten repeats its rationale argued against
#   the very action it had just written ("Post 11425 ... " voting on 11426;
#   "posting it again would be a restatement" after posting it again). The
#   grammar had it choose the target first and reason after, too late.
#
# HOW IT WORKS
#   Reads the schema's field order, and finds the field names' order in the
#   reply example of riffle's instructions.
#
# READING THE OUTPUT
#   `branches with rationale first: 31 of 31 | instructions show rationale
#   first: True`. Fewer, or False, is the failure.
#
# CHANGELOG
#   2026-11-06  Written for V4 (audit round 3), with the change it tests.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import json, re, sys
sys.path.insert(0, ".")
s = json.load(open("proposal_schema.json"))
first = sum(list(b["properties"])[:3] == ["rationale", "action", "payload"] for b in s["oneOf"])
src = open("agent/cortex.py").read()
m = re.search(r'\{\s*\n\s*"(\w+)":[^\n]*\n\s*"(\w+)":[^\n]*\n\s*"(\w+)":', src[src.find("Reply with ONE JSON object"):])
shown = list(m.groups()) if m else []
print(f"  branches with rationale first: {first} of {len(s['oneOf'])} | instructions show "
      f"rationale first: {shown[:1] == ['rationale']} ({' -> '.join(shown)})")
