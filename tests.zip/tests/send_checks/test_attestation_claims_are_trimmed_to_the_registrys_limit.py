# ==========================================================================
# A 705-character attestation claim is trimmed by the gate to 500
# characters, the registry's limit, ending in the marker.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The claim's length after the gate and whether the registry would
#   accept it.
#
# WHY IT EXISTS
#   Found while wiring signing (Q4, audit round 1): claims of 501 to
#   1,000 characters passed the gate and the registry refused them.
#
# HOW IT WORKS
#   Runs the gate on an over-long claim.
#
# READING THE OUTPUT
#   `705-char claim -> gate passes 500 chars; registry accepts (<=500):
#   True; ends '...'`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tclaim.py) during Q4.
#   2026-11-03  Its class changed from `observation` to `dispute`: the class
#               fix made `observation` invalid.
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, yaml; sys.path.insert(0, sys.argv[1])
from agent import drives
cfg = yaml.safe_load(open(sys.argv[1] + "/config.example.yaml")); cfg.setdefault("_selects", {}); cfg.setdefault("_forbids", {})
claim = "Two receipts settle out of order, as measured. " * 15          # 705 chars
k, p, _ = drives.gate({"action": "attestation", "payload": {"subject": "coppice", "claim": claim, "cls": "dispute"}, "rationale": "recording what I measured"}, "witness", cfg)
print(f"  {len(claim)}-char claim -> gate passes {len(p['claim'])} chars; registry accepts (<=500): {len(p['claim']) <= 500}; ends {p['claim'][-24:]!r}")
