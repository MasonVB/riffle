# ==========================================================================
# When riffle reads a thread again, the comments it already answered are
# marked as answered in the thread block.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Over three cycles, with riffle's reply to c2 already sent: the
#   thread block's heading each time, and whether c2 is marked `(you
#   have already replied to this)`. It is marked in the RE-READ block
#   (cycle 2, THE THREAD YOU ASKED TO READ AGAIN), which is what the fix
#   covered; the ordinary most-recent-read block (cycles 1 and 3) shows
#   the stored snapshot and does not mark it. A second reply is refused
#   either way, by the one-reply check.
#
# WHY IT EXISTS
#   The earlier review: on re-reading a thread riffle could not tell
#   which comments it had answered.
#
# HOW IT WORKS
#   Several real cycles: read, reply, read again.
#
# READING THE OUTPUT
#   `outcomes: [...]`, then `cycle 1 ... most recent read; ... False`,
#   `cycle 2 ... ASKED TO READ AGAIN, #4; ... True`, `cycle 3 ... most
#   recent read; ... False`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-26  Written in the sandbox (hreread.py) during the earlier review.
#   2026-11-05  Moved into tests/send_checks. Its sandbox wrapper (treread.sh)
#               ran it on an extracted copy of the previous version and on the
#               change, labelled 'original' and 'fixed'; packaged, it checks
#               the one tree it is given, and tests/compare_two_versions.sh
#               does the comparison.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
class Stub:
    def __init__(self, *a, **k): pass
    def post(self, pid):
        return {"post": {"id": pid, "title": "Receipts", "body": "the post", "author": "neighbor"},
                "comments": [{"id": 2, "author": "example-neighbor", "body": "PROPOSAL 1", "votes": 5},
                             {"id": 3, "author": "other", "body": "A second comment", "votes": 1}], "comments_total": 2}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "understand"
users = []; step = [0]
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    users.append(user); step[0] += 1
    if step[0] == 1:
        return json.dumps({"action": "read_thread", "payload": {"post_id": 4}, "rationale": "I want the replies on #4 again"})
    return json.dumps({"action": "noop", "payload": {"why": "reading what came back this cycle"}, "rationale": "reading the thread again"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')"); st.db.commit()
pid = project.active(st)["id"]
project.record_read(st, pid, 1, 4, "Receipts", "neighbor", 2, 2, "the post",
                    "  [c2] example-neighbor (5 votes): PROPOSAL 1\n  [c3] other (1 votes): A second comment", "d")
project.record_read(st, pid, 1, 7, "Another thread", "x", 0, 0, "another body", "", "d")     # newer read of another post
st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,'2026-10-25T00:00:00Z','comment','answer',?,'r','executed')",
              (json.dumps({"post_id": 4, "parent_id": 2, "body": "b"}),)); st.db.commit()
outs = []
for run in (1, 2, 3):
    sys.argv = ["cycle", "--config", cp] + (["--force"] if run > 1 else [])
    try: cycle.main()
    except SystemExit: pass
    if cycle._CYCLE_LOCK: cycle._CYCLE_LOCK.close(); cycle._CYCLE_LOCK = None
    outs.append(sqlite3.connect(os.path.join(d, "state.sqlite")).execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0])
print(f"  outcomes: {outs}")
for i, u in enumerate(users, 1):
    head = "ASKED TO READ AGAIN, #4" if "THE THREAD YOU ASKED TO READ AGAIN, #4" in u else ("most recent read" if "THE THREAD YOU READ MOST RECENTLY" in u else "none")
    print(f"  cycle {i} thread block: {head}; c2 marked as answered: {'[c2] (you have already replied to this)' in u}")
