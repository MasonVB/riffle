# ==========================================================================
# The greet drive is drawn only while the porch allowance lasts; once it
# is spent, greet stops being drawn and the porch leaves the grammar.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Over eight cycles with the porch allowance spent and posting not
#   ready: which drives were drawn, whether the last grammar offered
#   `porch` or `post`, and the journal's note.
#
# WHY IT EXISTS
#   The earlier review: with the porch capped, `greet` kept being drawn
#   and its cycles had nothing they could do.
#
# HOW IT WORKS
#   Eight real cycles with the porch cap used up.
#
# READING THE OUTPUT
#   `8 cycles drew: {...}` (no greet), the grammar booleans, and the log
#   line.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-25  Written in the sandbox (hgreet.py) during the earlier review.
#   2026-11-05  Moved into tests/send_checks. Its sandbox wrapper (tgreet.sh)
#               ran it on an extracted copy of the previous version and on the
#               change, labelled 'original' and 'fixed'; packaged, it checks
#               the one tree it is given, and tests/compare_two_versions.sh
#               does the comparison.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, collections
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives
from agent.state import State, utcnow
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
offered = {}
real_pick = drives.pick_drive if hasattr(drives, "pick_drive") else None
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    offered["grammar"] = sorted(b["properties"]["action"].get("const") for b in schema["oneOf"])
    offered["drive"] = user.split("SELECTED DRIVE THIS CYCLE: ")[1].split("\n")[0]
    return json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"})
cortex.complete = complete
drawn = collections.Counter()
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite"))
for _ in range(0 if os.environ.get('PORCH_FREE') else 3): st.cap_bump(utcnow()[:10], "porch")       # porch spent; no project, so post not ready
for run in range(8):
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    if cycle._CYCLE_LOCK: cycle._CYCLE_LOCK.close(); cycle._CYCLE_LOCK = None
    drawn[offered.get("drive")] += 1
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
print(f"  8 cycles drew: {dict(drawn)}")
print(f"  last grammar has porch: {'porch' in offered['grammar']}, post: {'post' in offered['grammar']}")
j = db.execute("SELECT text FROM journal WHERE text LIKE 'drives not available%' ORDER BY id DESC LIMIT 1").fetchone()
print(f"  log: {j[0][:150] if j else '(none)'}")
