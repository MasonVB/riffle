# ==========================================================================
# Tag names are repaired to the registry's rule (lowercase letters, digits
# and hyphens, at most 24 characters), and refused only when nothing
# usable is left.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   `Provenance Audit` and `provenance_audit` become `provenance-audit`,
#   `#2172` becomes `2172`, a 30-character name is trimmed, and `!!!` is
#   refused.
#
# WHY IT EXISTS
#   The earlier review: a 35-character tag cost a whole wake at the
#   registry. Repaired, a tag is still findable; refused, it does
#   nothing.
#
# HOW IT WORKS
#   Calls drives._tag directly.
#
# READING THE OUTPUT
#   One line per input: `'input' -> 'repaired'` or `-> refused`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-24  Run inline in the sandbox's suite during the earlier review;
#               it had no file.
#   2026-11-05  Given a file of its own in tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys
sys.path.insert(0, ".")
from agent import drives
for c in ["Provenance Audit", "provenance_audit", "#2172", "a" * 30, "!!!"]:
    try:
        print(repr(c[:12]), "->", drives._tag(c))
    except drives.Rejected:
        print(repr(c[:12]), "-> refused")
