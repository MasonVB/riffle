# ==========================================================================
# When today's comment allowance is spent, the answer drive is not drawn
# and `comment` leaves the grammar; with allowance left, the answer drive
# is drawn, `comment` is offered and the inbox is shown.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The drive drawn, whether `comment` was in the grammar, whether inbox
#   messages were shown, and the outcome. Spent: another drive (deepen),
#   comment False, inbox False, noop. NOT_SPENT=1: answer, comment True,
#   inbox True, executed.
#
# WHY IT EXISTS
#   The earlier review: a cycle drew `answer`, wrote a reply, and only
#   then found the allowance spent.
#
# HOW IT WORKS
#   A real cycle with a live mention in the inbox and the comment cap
#   used up (or not).
#
# READING THE OUTPUT
#   `drive=... comment-in-grammar=False|True inbox-messages-shown=... ->
#   outcome ...`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-25  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/send_checks.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex
from agent.state import State, utcnow
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
it = me["since_last_visit"].pop("comments_on_your_posts")[0]
me["since_last_visit"]["mentions_of_you"] = [it]            # a live mention
seen = {}
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"promote": [], "write": [], "drop": [], "note": "", "continuity": "c"})
    consts = [b["properties"]["action"].get("const") for b in schema["oneOf"]]
    seen.update(drive=user.split("SELECTED DRIVE THIS CYCLE: ")[1].split("\n")[0],
                comment_in_grammar="comment" in consts, inbox_shown="example-neighbor" in user)
    if "comment" in consts:
        return json.dumps({"action": "comment", "payload": {"post_id": 4, "parent_id": 2, "body": "Replying to your point about receipts."}, "rationale": "answering a mention"})
    return json.dumps({"action": "noop", "payload": {"why": "the comment allowance is spent today"}, "rationale": "the comment allowance is spent"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg["autonomy"]["comment"] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite"))
for _ in range(0 if os.environ.get("NOT_SPENT") else cfg["caps"]["comment"]): st.cap_bump(utcnow()[:10], "comment")
sys.argv = ["cycle", "--config", cp]
try: cycle.main()
except SystemExit: pass
oc = sqlite3.connect(os.path.join(d, "state.sqlite")).execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
[print("   J:", l, t[:140]) for (l, t) in sqlite3.connect(os.path.join(d,"state.sqlite")).execute("SELECT level, text FROM journal WHERE level IN ('warn','info') AND (text LIKE '%block%' OR text LIKE '%refus%' OR text LIKE '%noop%') ORDER BY id DESC LIMIT 3")]
print(f"  drive={seen.get('drive')} comment-in-grammar={seen.get('comment_in_grammar')} inbox-messages-shown={seen.get('inbox_shown')} -> outcome {oc}")
