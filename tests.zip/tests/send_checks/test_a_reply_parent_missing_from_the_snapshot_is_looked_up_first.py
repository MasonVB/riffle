# ==========================================================================
# When a reply's parent comment is not in riffle's snapshot of the thread,
# it is looked up on the registry before anything is sent.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For a parent id and post id (arguments 2 and 3), with or without a
#   project open (WITH_PROJECT=1): whether the reply was sent, the
#   outcome, and the journal's explanation.
#
# WHY IT EXISTS
#   The earlier review: a reply to an unknown parent was sent and failed
#   at the registry, costing a cycle.
#
# HOW IT WORKS
#   A real cycle whose stub registry answers the parent lookup.
#
# READING THE OUTPUT
#   `parent P on post Q: sent=... outcome=... <journal line>`.
#
# RUNNING IT ON ITS OWN
#   WITH_PROJECT=1 python3 tests/send_checks/test_a_reply_parent_missing
#   _from_the_snapshot_is_looked_up_first.py . 2 9
#
# CHANGELOG
#   2026-10-24  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/send_checks. Its sandbox wrapper (tpar.sh)
#               ran it on an extracted copy of the previous version and on the
#               change, labelled 'original' and 'fixed'; packaged, it checks
#               the one tree it is given, and tests/compare_two_versions.sh
#               does the comparison.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, par, post = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]); sys.path.insert(0, repo)
from agent import cycle, cortex, drives
from agent.client import HttpError
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))                  # inbox: comment 2 on post 4
sent = []
class Stub:
    def __init__(self, *a, **k): pass
    def get(self, path, **k):
        if path.startswith("/api/comment/"):
            cid = int(path.rsplit("/", 1)[1])
            if cid == 115595: raise HttpError(404, {"error": "comment 115595 not found", "id_class": "absent"})
            return {"comment": {"id": cid, "post_id": 777}}
        return {}
    def create_comment(self, post_id, body, parent_id=None):
        sent.append((post_id, parent_id)); return {"id": 99999}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "answer"
cortex.complete = lambda llm, system, user, **k: json.dumps({"action": "comment", "payload": {
    "post_id": post, "parent_id": par, "body": "You wrote that the receipts settle in order. I checked the last forty and two settle out of order."},
    "rationale": "answering a reply to my post"}) if "Choose ONE action" in user else json.dumps({"promote": [], "write": [], "drop": [], "note": "", "continuity": "c"})
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg["autonomy"]["comment"] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
from agent.state import State as _S; from agent import project as _pj
if os.environ.get("WITH_PROJECT"):
    _s=_S(os.path.join(d,"state.sqlite")); _pj.ensure(_s)
    _s.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')"); _s.db.commit()
sys.argv = ["cycle", "--config", cp]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
oc = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()
j = [t for (t,) in db.execute("SELECT text FROM journal WHERE text LIKE 'parent%' OR text LIKE 'could not check%'")]
[print("   J:", l, t[:150]) for (l, t) in db.execute("SELECT level, text FROM journal WHERE level IN ('warn','error') ORDER BY id DESC LIMIT 4")]
print(f"  parent {par} on post {post}: sent={sent} outcome={oc[0] if oc else None} {j[0][:95] if j else ''}")
