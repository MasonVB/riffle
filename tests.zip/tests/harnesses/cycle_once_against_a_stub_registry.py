# ==========================================================================
# HARNESS: run one real cycle (cycle.main) against a stub registry and a
# stub composer, and save the prompt it built.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Nothing by itself: several tests run it and then check the prompt it
#   saved. It exercises the whole of cycle.main() up to and including
#   the model call, so a test built on it checks the prompt riffle would
#   really have seen.
#
# WHY IT EXISTS
#   Most of riffle's bugs live in the cycle's flow, not in single
#   functions, so the tests run the real main() rather than pieces of
#   it.
#
# HOW IT WORKS
#   Replaces the registry Reader and Writer with a stub that answers
#   from tests/fixtures/registry_me_response.json (a real /api/me
#   answer) and serves one front-page post; skips the witness pass and
#   the changes walk; replaces cortex.complete with a function that
#   saves the system and user prompts to $RIFFLE_TMP/prompt_sys.txt and
#   prompt_user.txt and returns a noop. Argument 2 is `ok` or `fail`
#   (the composer raises). Uses config.example.yaml with a temporary
#   data_dir.
#
# READING THE OUTPUT
#   `[mode] rc=... order=[...]` gives main()'s return code and the order
#   of registry and composer calls (me, ack, COMPOSER); then any inbox
#   or composer journal lines, and whether the inbox reached the prompt.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-30  Last changed in the sandbox as /tmp/hack2.py (written earlier
#               for the inbox work; the exact date was not recorded). The
#               stub's front page was added for the H6 boundary test.
#   2026-11-05  Moved into tests/harnesses. The fixture and prompt paths come
#               from the runner's variables instead of fixed /tmp files.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml
repo = sys.argv[1]; mode = sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
calls = []
class Stub:
    def front(self, *a, **k): return {'posts': [{'id': 9001, 'title': 'A front post', 'author': 'x', 'votes': 1, 'comments': 0, 'body': 'front body'}]}
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        def f(*a, **k):
            calls.append(n)
            if n == "me": return copy.deepcopy(me)
            if n == "ack": return {"mode": "legacy", "advanced": True}
            return {}
        return f
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
_real = cortex.complete
def complete(*a, **k):
    calls.append("COMPOSER"); open(__import__("os").environ["RIFFLE_TMP"] + "/prompt_user.txt","w").write(a[2] if len(a)>2 else k.get("user","")); open(__import__("os").environ["RIFFLE_TMP"] + "/prompt_sys.txt","w").write(a[1])
    if mode == "fail": raise RuntimeError("composer died")
    return json.dumps({"action": "noop", "payload": {}, "rationale": "nothing to do"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
from agent.state import State as _S; _s=_S(os.path.join(d,"state.sqlite")); _s.note("continuity","I am halfway through the detector post."); _s.note("continuity_at","2026-10-24T09:12:03Z")
sys.argv = ["cycle", "--config", cp]
try:
    rc = cycle.main()
except SystemExit as e:
    rc = f"exit {e.code}"
except Exception as e:
    import traceback; traceback.print_exc(limit=3); rc = "RAISED"
import sqlite3
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
seq = [c for c in calls if c in ("me", "ack", "COMPOSER")]
print(f"  [{mode}] rc={rc} order={seq}")
for (t,) in db.execute("SELECT text FROM journal WHERE text LIKE '%inbox%' OR text LIKE 'composer failed%'"):
    print("   journal:", t[:150])
print("   inbox in prompt:", "YOUR INBOX" in open(__import__("os").environ["RIFFLE_TMP"] + "/prompt_user.txt").read() if os.path.exists(__import__("os").environ["RIFFLE_TMP"] + "/prompt_user.txt") else None)
#, "YOUR INBOX" in open(os.path.join(d, "last_prompt.txt")).read() if os.path.exists(os.path.join(d,"last_prompt.txt")) else "(prompt not saved)")
