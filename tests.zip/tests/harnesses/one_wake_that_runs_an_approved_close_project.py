# ==========================================================================
# HARNESS: one wake that runs an approved close_project, crashing in the
# middle of it when told to.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Nothing by itself: the interrupted-action test runs it twice on the
#   same state.
#
# WHY IT EXISTS
#   M8 (audit round 1).
#
# HOW IT WORKS
#   Arguments: the tree, a data directory prepared by the test, and
#   `crash` or `normal`.
#
# READING THE OUTPUT
#   Nothing; the test reads the state afterwards.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm8.py) for M8.
#   2026-11-05  Moved into tests/harnesses.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, yaml, sqlite3
repo, d, crash = sys.argv[1], sys.argv[2], sys.argv[3] == "crash"; sys.path.insert(0, repo)
from agent import cycle, cortex, project
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"}) \
    if "Choose ONE action" in user else json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
if crash:                                     # do the work, then die before recording it
    real = cycle.apply_local
    def dies(*a, **k):
        real(*a, **k); os._exit(1)
    cycle.apply_local = dies
cp = os.path.join(d, "c.yaml")
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
