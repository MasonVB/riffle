# ==========================================================================
# Two realistic consecutive cycles (another drive, and an action taken in
# between) first differ where riffle's own content actually changed, not
# at a block that was merely cut differently.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That riffle's own section is cut the same way from cycle to cycle,
#   so the composer can reuse it from its cache up to the first block
#   whose content really changed.
#
# WHY IT EXISTS
#   Round 2, found on the box after U2: the composer still re-read
#   ~5,500 tokens a cycle. Whether a block was cut depended on how much
#   the WHOLE prompt was over, which changes every cycle with the board,
#   so the library list (fourth in the section) was cut one cycle and
#   whole the next. The fix fits riffle's section on its own budget,
#   with its stable head held to its caps.
#
# HOW IT WORKS
#   The two-cycle test above, plus a change of drive and one comment
#   taken between the cycles.
#
# READING THE OUTPUT
#   `first difference at N ...: in riffle's own section, in the block
#   starting 'WHAT YOU ...'` (a block that genuinely changed) or later
#   is right; a difference in 'YOUR LIBRARY' or another stable head
#   block is the bug coming back.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-11-04  Generated in the sandbox from the U2 test for the round-2
#               cache fix.
#   2026-11-05  Committed as a file.
#   2026-11-07  Also reports where the composer can resume: the start of the
#               user message holding the first difference, and how much of the
#               user prompt that reuses, the figure the message splits exist
#               for.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, time
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, memory
from agent.state import State, utcnow
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
LONG = lambda tag, n: (tag + " ") * (n // (len(tag) + 1))
front = [{"id": 9000 + i, "title": f"Front post {i} about receipts", "author": "x", "votes": 3, "comments": 4, "body": LONG(f"frontbody{i}", 600)} for i in range(15)]
class Stub:
    def __init__(self, *a, **k): pass
    def front(self, *a, **k): return {"posts": front}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [{"id": 8000 + i, "title": f"moved post {i}", "author": "y", "votes": i, "comments": i} for i in range(100)],
                                      'comments': [{"id": 70000 + i, "post_id": 8000 + i, "author": "z", "body": "a moved comment " * 6} for i in range(100)],
                                      'nulls': [], 'saturated': False, 'window_age_ms': 1000}
drives.pick_drive = lambda *a, **k: "understand"
seen = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    seen["system"], seen["user"] = system, user
    return json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','Temporal scope of absence claims','Q?','active')"); st.db.commit()
pid = project.active(st)["id"]
for i in range(12): project.add_note(st, pid, 1, "observation", LONG(f"projectnote{i}", 420), source="x") if hasattr(project, "add_note") else None
project.record_read(st, pid, 1, 9823, "The ever clause", "coppice", 30, 30, LONG("threadbody", 6000), "\n".join(f"  [c{120000+i}] someone (2 votes): " + LONG("reply", 150) for i in range(30)), "d")
for i in range(25): memory.remember(st, f"memory number {i} about the receipts question and its timing " + "x" * 40, kind="self")
st.note("last_build", json.dumps({"run_id": "c1", "entry": "solve.py", "at": utcnow(), "ok": False, "exit_code": 1, "stdout": LONG("buildout", 3000), "stderr": LONG("traceback", 3000), "files": ["solve.py"]}))
st.note("last_fetch", json.dumps({"what": "post/9000", "at": "2026-10-29T00:00:00Z", "body": LONG("STALEFETCH", 5100)}))
st.db.execute("UPDATE notes SET updated_at='2026-10-29T00:00:00Z' WHERE key='last_fetch'")
for t in ("2026-10-29T01:00:00Z", "2026-10-29T02:00:00Z", "2026-10-29T03:00:00Z"):     # three real cycles since that fetch
    st.db.execute("INSERT INTO cycles (started_at,ended_at,drive,outcome) VALUES (?,?,'understand','noop')", (t, t))
st.note("last_library_read", "https://en.wikipedia.org/wiki/X (fetched)\n\n" + LONG("FRESHDOC", 2700))
st.db.commit()
import datetime as _dtt
_until = _dtt.datetime.now(_dtt.timezone.utc) + _dtt.timedelta(hours=13.4)
st.note("post_cooldown_until", _until.isoformat())
st.cap_bump(utcnow()[:10], "comment")
users = []
for run in (1, 2):
    if run == 2:
        drives.pick_drive = lambda *a, **k: "contribute"
        st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'comment','answer',?,'r','executed')",
                      (utcnow(), json.dumps({"post_id": 9001, "parent_id": 120005, "body": "an answer"})))
        st.db.commit()
        _real = project.in_cooldown
        project.in_cooldown = lambda s, _r=_real: (True, _until, 12.9)
        st.cap_bump(utcnow()[:10], "comment")
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    if cycle._CYCLE_LOCK: cycle._CYCLE_LOCK.close(); cycle._CYCLE_LOCK = None
    users.append(seen.get("user", ""))
    time.sleep(1.1)
s, u = seen.get("system", ""), users[0]
common = len(os.path.commonprefix(users))
b = users[1].find("</board>")
where = "after </board>" if common >= b else ("in the board" if common >= users[1].find("<board>") else "in riffle's own section")
head = users[1][:common].rsplit("\n\n", 1)[-1].split("\n", 1)[0][:60]
print(f"  first difference at {common} of {len(users[1])} (</board> at {b}): {where}, in the block starting {head!r}")
# Where the composer can resume: the start of the user message holding the
# first difference (it saves a checkpoint at each message start; V1).
_brk = "\n\u241e\n"
_starts = [0] + [i + len(_brk) for i in range(len(users[1])) if users[1].startswith(_brk, i)]
_resume = max(x for x in _starts if x <= common)
print(f"  the composer resumes at message {_starts.index(_resume) + 1} of {len(_starts)}: "
      f"{_resume} chars of the user prompt reused, {len(users[1]) - _resume} re-read")
if True:
    print("  CYCLE 1 >>", repr(users[0][max(0, common-300):common+250]))
    print("  CYCLE 2 >>", repr(users[1][max(0, common-300):common+250]))
tail = u.split("</board>", 1)[1] if "</board>" in u else ""
own, board = (u.split("<board>", 1) + [""])[:2]
print(f"  sent {len(s) + len(u)} of 50000 chars (system {len(s)})")
print(f"  stale page shown: {'STALEFETCH' in u} | fresh document shown: {'FRESHDOC' in u}")
print(f"  after </board>: {[l[:22] for l in tail.strip().splitlines() if l[:1].isupper() and (l.startswith(('YOUR ACTUAL','YOUR INBOX','TODAY','SELECTED','caps','AN ACTION','YOU MAY NOT','Choose')))]}")
def size(head):
    i = u.find(head)
    if i < 0: return 0
    j = min([k for k in (u.find("\n\n", i + len(head)),) if k > 0] or [len(u)])
    return j - i
blocks = [b for b in u.replace("<board>", "\n\n").replace("</board>", "\n\n").split("\n\n") if b.strip()]
def blen(head):
    # a block runs from its heading until the next block heading
    i = u.find(head)
    if i < 0: return 0
    rest = u[i:]
    ends = [rest.find("\n\n" + h2) for h2 in heads if h2 != head and rest.find("\n\n" + h2) > 0]
    return min(ends) if ends else len(rest)
heads = ("YOUR LAST BUILD", "WHAT ACTUALLY MOVED", "FRONT PAGE", "COMMENTS YOU COULD ANSWER", "THE THREAD YOU READ MOST RECENTLY",
         "YOUR GOALS RIGHT NOW", "THE DOCUMENT YOU OPENED", "WHAT YOU HAVE ALREADY SAID", "THINGS YOU NOTED FROM", "WHAT YOU REMEMBER",
         "POSTING IS CLOSED", "YOUR PROJECT", "MEMORIES THAT CARRY", "THREADS YOU HAVE READ", "YOUR ACTUAL SITUATION", "INBOX \u2014 NEW",
         "WHAT CAN STOP AN ACTION", "THE FIELDS THE API", "YOUR INBOX, AND HOW", "TODAY (server)")
for h in ("YOUR LAST BUILD", "WHAT ACTUALLY MOVED", "FRONT PAGE", "COMMENTS YOU COULD ANSWER", "THE THREAD YOU READ MOST RECENTLY", "YOUR GOALS RIGHT NOW", "THE DOCUMENT YOU OPENED"):
    print(f"    {h:34} {blen(h):6} chars")
print(f"  system prompt lists seed weights: {'understand: 0.' in s or 'witness: 0.' in s}")
