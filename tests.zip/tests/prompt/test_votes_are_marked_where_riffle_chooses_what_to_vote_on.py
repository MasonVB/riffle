# ==========================================================================
# Everything riffle has already voted on is marked where it picks targets:
# front-page rows, comment ids and the thread heading.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   After votes on post 9000, comment c120001 and post 9823 (the thread
#   read): the front-page row carries `"you_voted": true` straight after
#   its id, the comment reads `[c120001, you voted]`, an unvoted comment
#   is untouched, and the heading reads `#9823 (you voted)`.
#
# WHY IT EXISTS
#   U7 (audit round 2): riffle kept proposing votes the registry would
#   refuse (4 in 32 cycles); the ALREADY DONE list held only the 15 most
#   recent votes. The marker sits right after the id because a front
#   page cut to its floor loses the end of a row first.
#
# HOW IT WORKS
#   The box-like prompt test with three votes recorded before the cycle.
#
# READING THE OUTPUT
#   Four True/False lines; all True means every mark is in place.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-11-04  Generated in the sandbox for U7.
#   2026-11-05  Committed as a file.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, time
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, memory
from agent.state import State, utcnow
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
LONG = lambda tag, n: (tag + " ") * (n // (len(tag) + 1))
front = [{"id": 9000 + i, "title": f"Front post {i} about receipts", "author": "x", "votes": 3, "comments": 4, "body": LONG(f"frontbody{i}", 600)} for i in range(15)]
class Stub:
    def __init__(self, *a, **k): pass
    def front(self, *a, **k): return {"posts": front}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [{"id": 8000 + i, "title": f"moved post {i}", "author": "y", "votes": i, "comments": i} for i in range(100)],
                                      'comments': [{"id": 70000 + i, "post_id": 8000 + i, "author": "z", "body": "a moved comment " * 6} for i in range(100)],
                                      'nulls': [], 'saturated': False, 'window_age_ms': 1000}
drives.pick_drive = lambda *a, **k: "understand"
seen = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    seen["system"], seen["user"] = system, user
    return json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','Temporal scope of absence claims','Q?','active')"); st.db.commit()
pid = project.active(st)["id"]
for i in range(12): project.add_note(st, pid, 1, "observation", LONG(f"projectnote{i}", 420), source="x") if hasattr(project, "add_note") else None
project.record_read(st, pid, 1, 9823, "The ever clause", "coppice", 30, 30, LONG("threadbody", 6000), "\n".join(f"  [c{120000+i}] someone (2 votes): " + LONG("reply", 150) for i in range(30)), "d")
for i in range(25): memory.remember(st, f"memory number {i} about the receipts question and its timing " + "x" * 40, kind="self")
st.note("last_build", json.dumps({"run_id": "c1", "entry": "solve.py", "at": utcnow(), "ok": False, "exit_code": 1, "stdout": LONG("buildout", 3000), "stderr": LONG("traceback", 3000), "files": ["solve.py"]}))
st.note("last_fetch", json.dumps({"what": "post/9000", "at": "2026-10-29T00:00:00Z", "body": LONG("STALEFETCH", 5100)}))
st.db.execute("UPDATE notes SET updated_at='2026-10-29T00:00:00Z' WHERE key='last_fetch'")
for t in ("2026-10-29T01:00:00Z", "2026-10-29T02:00:00Z", "2026-10-29T03:00:00Z"):     # three real cycles since that fetch
    st.db.execute("INSERT INTO cycles (started_at,ended_at,drive,outcome) VALUES (?,?,'understand','noop')", (t, t))
st.note("last_library_read", "https://en.wikipedia.org/wiki/X (fetched)\n\n" + LONG("FRESHDOC", 2700))
st.db.commit()
for _t, _i in (("post", 9000), ("comment", 120001), ("post", 9823)):
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'vote','curate',?,'r','executed')",
                  (utcnow(), json.dumps({"target_type": _t, "target_id": _i})))
st.db.commit()
users = []
for run in (1, 2):
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    if cycle._CYCLE_LOCK: cycle._CYCLE_LOCK.close(); cycle._CYCLE_LOCK = None
    users.append(seen.get("user", ""))
    time.sleep(1.1)
s, u = seen.get("system", ""), users[0]
common = len(os.path.commonprefix(users))
print(f"  unchanged opening of the user message across two cycles: {common} of {len(users[1])} chars")
if os.environ.get("FIRSTDIFF"):
    print("  CYCLE 1 >>", repr(users[0][max(0, common-300):common+250]))
    print("  CYCLE 2 >>", repr(users[1][max(0, common-300):common+250]))
tail = u.split("</board>", 1)[1] if "</board>" in u else ""
own, board = (u.split("<board>", 1) + [""])[:2]
print(f"  sent {len(s) + len(u)} of 50000 chars (system {len(s)})")
print(f"  stale page shown: {'STALEFETCH' in u} | fresh document shown: {'FRESHDOC' in u}")
print(f"  after </board>: {[l[:22] for l in tail.strip().splitlines() if l[:1].isupper() and (l.startswith(('YOUR ACTUAL','YOUR INBOX','TODAY','SELECTED','caps','AN ACTION','YOU MAY NOT','Choose')))]}")
def size(head):
    i = u.find(head)
    if i < 0: return 0
    j = min([k for k in (u.find("\n\n", i + len(head)),) if k > 0] or [len(u)])
    return j - i
blocks = [b for b in u.replace("<board>", "\n\n").replace("</board>", "\n\n").split("\n\n") if b.strip()]
def blen(head):
    # a block runs from its heading until the next block heading
    i = u.find(head)
    if i < 0: return 0
    rest = u[i:]
    ends = [rest.find("\n\n" + h2) for h2 in heads if h2 != head and rest.find("\n\n" + h2) > 0]
    return min(ends) if ends else len(rest)
heads = ("YOUR LAST BUILD", "WHAT ACTUALLY MOVED", "FRONT PAGE", "COMMENTS YOU COULD ANSWER", "THE THREAD YOU READ MOST RECENTLY",
         "YOUR GOALS RIGHT NOW", "THE DOCUMENT YOU OPENED", "WHAT YOU HAVE ALREADY SAID", "THINGS YOU NOTED FROM", "WHAT YOU REMEMBER",
         "POSTING IS CLOSED", "YOUR PROJECT", "MEMORIES THAT CARRY", "THREADS YOU HAVE READ", "YOUR ACTUAL SITUATION", "INBOX \u2014 NEW",
         "WHAT CAN STOP AN ACTION", "THE FIELDS THE API", "YOUR INBOX, AND HOW", "TODAY (server)")
for h in ("YOUR LAST BUILD", "WHAT ACTUALLY MOVED", "FRONT PAGE", "COMMENTS YOU COULD ANSWER", "THE THREAD YOU READ MOST RECENTLY", "YOUR GOALS RIGHT NOW", "THE DOCUMENT YOU OPENED"):
    print(f"    {h:34} {blen(h):6} chars")
print(f"  system prompt lists seed weights: {'understand: 0.' in s or 'witness: 0.' in s}")

u = users[1]; board = u.split("<board>", 1)[1].split("</board>", 1)[0]
import re as _re
fr = board[board.find("FRONT PAGE"):]
print("  front-page post 9000 marked:", bool(_re.search(r"\"id\": 9000,\s*\"you_voted\": true", fr)))
print("  comment c120001 marked:", "[c120001, you voted]" in board, "| unvoted c120002 left alone:", "[c120002]" in board)
print("  thread #9823 heading marked:", "#9823 (you voted)" in board)
