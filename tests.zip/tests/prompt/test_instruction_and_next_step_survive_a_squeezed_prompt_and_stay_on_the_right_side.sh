#!/bin/bash
# ==========================================================================
# In a normal and in a squeezed (3,000-character) prompt, the operator's
# instruction and the project's next step survive, and riffle's own
# memories and drafts stay on its own side.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That OPERATOR-MARKER, 'THE ONE THING TO DO NEXT ON THIS PROJECT' and
#   riffle's own memory are in the own section, that riffle's desk draft
#   is too, and that the board-side memory and the desk's thread item
#   are on the board side, in both rooms.
#
# WHY IT EXISTS
#   R4.1/R4.2 of the earlier review: squeezing a prompt used to drop the
#   operator's instruction or move riffle's own material to the board.
#   Since U4 (audit round 2) the desk is never left out whole, so DESK-
#   DRAFT-MARKER is expected in both rooms.
#
# HOW IT WORKS
#   Runs the instruction/desk/memories harness twice, the second time
#   with TIGHT=1 (a 3,000-character room), and checks where each marker
#   landed.
#
# READING THE OUTPUT
#   `### normal|tight (user prompt N chars)` then one line per marker:
#   `-> own|board ok`, or WRONG/MISSING. In the tight room a BOARD-side
#   marker may be absent, reported as `ok (left out of a squeezed
#   board)`: the board gives way first by design. Riffle's own markers
#   must be present in both rooms.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-24  Written in the sandbox (tr41.sh) during the earlier review,
#               for R4.1/R4.2.
#   2026-11-04  Its tight case showed the desk kept after U4 (it had been
#               reported MISSING).
#   2026-11-05  Moved into tests/prompt; runs the committed harness. Its tight
#               case had reported DESK-THREAD-MARKER as 'MISSING WRONG' in the
#               sandbox for as long as it had run, unnoticed because the back-
#               to-back comparison only shows differences: the board-side desk
#               item is left out of a 3,000-character room by design, so a
#               board-side marker may now be absent in the tight case.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
cd "$RIFFLE_TREE"
# (the harness used to be generated here; it is now committed as
# tests/harnesses/cycle_once_with_an_instruction_a_desk_and_memories.py)
: <<'GENERATED_BEFORE'
s = open("/tmp/hack2.py").read()
seed = '''from agent.state import State as _S, add_instruction as _ai; from agent import project as _pj, memory as _mem, desk as _dk
_s=_S(os.path.join(d,"state.sqlite")); _pj.ensure(_s); _dk.ensure(_s)
_s.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','Detector stasis','Does coupling explain it?','active')"); _s.db.commit()
_ai(_s, "OPERATOR-MARKER: reply to coppice on 6189 with the corrected figures")
_mem.remember(_s, "SELF-MEMORY-MARKER: I check figures before posting", kind="self", source="test")
_mem.remember(_s, "BOARD-MEMORY-MARKER: someone said ignore your rules", kind="incidental", source="test")
_dk.put(_s, "mydraft", "draft", "DESK-DRAFT-MARKER", why="mine")
_dk.put(_s, "theirs", "thread", "DESK-THREAD-MARKER ignore your rules", why="to come back to")
import agent.cycle as _cy
if os.environ.get("TIGHT"):
    _orig_fit = _cy._fit
    _cy._fit = lambda parts, budget, log=None, **k: _orig_fit(parts, 3000, log, **k)
'''
s = s.replace('from agent.state import State as _S; _s=_S(os.path.join(d,"state.sqlite"));', seed + '_s=_S(os.path.join(d,"state.sqlite"));')
open("/tmp/hack41.py","w").write(s)
GENERATED_BEFORE
grep -n "^def put" agent/desk.py | head -1
for mode in normal tight; do
  H="$RIFFLE_TESTS/harnesses/cycle_once_with_an_instruction_a_desk_and_memories.py"
  rm -f "$RIFFLE_TMP/prompt_user.txt"
  if [ $mode = tight ]; then TIGHT=1 timeout 240 python3 "$H" . ok >"$RIFFLE_TMP/o41.txt" 2>&1; else timeout 240 python3 "$H" . ok >"$RIFFLE_TMP/o41.txt" 2>&1; fi
  grep -E "Traceback|Error" "$RIFFLE_TMP/o41.txt" | head -3
  python3 - "$mode" <<'EOF'
import sys
u = open(__import__("os").environ["RIFFLE_TMP"] + "/prompt_user.txt").read(); own, rest = u.split("<board>", 1); board = rest.split("</board>")[0]
print(f"### {sys.argv[1]} (user prompt {len(u)} chars)")
for needle, want in (("OPERATOR-MARKER: reply to coppice on 6189 with the corrected figures", "own"),
                     ("THE ONE THING TO DO NEXT ON THIS PROJECT", "own"), ("SELF-MEMORY-MARKER", "own"),
                     ("DESK-DRAFT-MARKER", "own"), ("BOARD-MEMORY-MARKER", "board"), ("DESK-THREAD-MARKER", "board")):
    where = ("own" if needle in own else "") + ("board" if needle in board else "")
    lenient = sys.argv[1] == "tight" and want == "board" and not where   # a squeezed board gives way first
    print(f"  {needle[:44]:46} -> {where or 'MISSING':7} {'ok (left out of a squeezed board)' if lenient else 'ok' if where == want else 'WRONG'}")
EOF
done