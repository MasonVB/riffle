# ==========================================================================
# A prompt as crowded as riffle's real ones fits the 50,000-character
# ceiling, drops stale blocks, keeps the work at hand, and keeps riffle's
# own section stable for the composer's cache.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For a prompt built from the box's measured block sizes (a 15-post
#   front page, 200 rows of changes, a 6,000-character build result, a
#   9,000-character thread, a long project): the total sent against the
#   ceiling; that a page fetched four cycles ago is not shown while a
#   document opened last cycle is; what follows </board>; that the
#   system prompt carries no seed weights; how much of the user prompt
#   is identical between two consecutive identical cycles; and the size
#   each key block was given.
#
# WHY IT EXISTS
#   H6 (audit round 1) measured that riffle wanted ~47,600 characters
#   against a room of ~18,100, that the prompt ran over its ceiling
#   every cycle, and that stale blocks were sent every cycle. M4 removed
#   the seed weights; M5 moved what changes every cycle after </board>.
#   Round 2 found my first budgets broke the cache, and fixed it.
#
# HOW IT WORKS
#   Seeds a state that resembles the box (see the numbers above), runs
#   two forced cycles of the real main() with a stub registry and
#   composer, and measures the prompts. FIRSTDIFF=1 in the environment
#   also prints the text around the first difference between the two
#   cycles.
#
# READING THE OUTPUT
#   `sent N of 50000`, `stale page shown: False | fresh document shown:
#   True`, the headings after </board>, `unchanged opening ... N of M
#   chars`, block sizes, and `system prompt lists seed weights: False`.
#   Numbers move when prompt text changes; check any change is the one
#   intended.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (th6.py) for H6, M4 and M5.
#   2026-11-03  Learned to run two cycles and report the unchanged opening
#               (for the cache), and FIRSTDIFF to show where two prompts first
#               differ.
#   2026-11-05  Moved into tests/prompt.
#   2026-11-06  Measures blocks across the user-message breaks V1 added (audit
#               round 3): the stable head's last block ran on into the next
#               message's blocks, showing 6,133 characters for the goals
#               block.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, time
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, memory
from agent.state import State, utcnow
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
LONG = lambda tag, n: (tag + " ") * (n // (len(tag) + 1))
front = [{"id": 9000 + i, "title": f"Front post {i} about receipts", "author": "x", "votes": 3, "comments": 4, "body": LONG(f"frontbody{i}", 600)} for i in range(15)]
class Stub:
    def __init__(self, *a, **k): pass
    def front(self, *a, **k): return {"posts": front}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [{"id": 8000 + i, "title": f"moved post {i}", "author": "y", "votes": i, "comments": i} for i in range(100)],
                                      'comments': [{"id": 70000 + i, "post_id": 8000 + i, "author": "z", "body": "a moved comment " * 6} for i in range(100)],
                                      'nulls': [], 'saturated': False, 'window_age_ms': 1000}
drives.pick_drive = lambda *a, **k: "understand"
seen = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    seen["system"], seen["user"] = system, user
    return json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','Temporal scope of absence claims','Q?','active')"); st.db.commit()
pid = project.active(st)["id"]
for i in range(12): project.add_note(st, pid, 1, "observation", LONG(f"projectnote{i}", 420), source="x") if hasattr(project, "add_note") else None
project.record_read(st, pid, 1, 9823, "The ever clause", "coppice", 30, 30, LONG("threadbody", 6000), "\n".join(f"  [c{120000+i}] someone (2 votes): " + LONG("reply", 150) for i in range(30)), "d")
for i in range(25): memory.remember(st, f"memory number {i} about the receipts question and its timing " + "x" * 40, kind="self")
st.note("last_build", json.dumps({"run_id": "c1", "entry": "solve.py", "at": utcnow(), "ok": False, "exit_code": 1, "stdout": LONG("buildout", 3000), "stderr": LONG("traceback", 3000), "files": ["solve.py"]}))
st.note("last_fetch", json.dumps({"what": "post/9000", "at": "2026-10-29T00:00:00Z", "body": LONG("STALEFETCH", 5100)}))
st.db.execute("UPDATE notes SET updated_at='2026-10-29T00:00:00Z' WHERE key='last_fetch'")
for t in ("2026-10-29T01:00:00Z", "2026-10-29T02:00:00Z", "2026-10-29T03:00:00Z"):     # three real cycles since that fetch
    st.db.execute("INSERT INTO cycles (started_at,ended_at,drive,outcome) VALUES (?,?,'understand','noop')", (t, t))
st.note("last_library_read", "https://en.wikipedia.org/wiki/X (fetched)\n\n" + LONG("FRESHDOC", 2700))
st.db.commit()
users = []
for run in (1, 2):
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    if cycle._CYCLE_LOCK: cycle._CYCLE_LOCK.close(); cycle._CYCLE_LOCK = None
    users.append(seen.get("user", ""))
    time.sleep(1.1)
s, u = seen.get("system", ""), users[0]
common = len(os.path.commonprefix(users))
print(f"  unchanged opening of the user message across two cycles: {common} of {len(users[1])} chars")
if os.environ.get("FIRSTDIFF"):
    print("  CYCLE 1 >>", repr(users[0][max(0, common-300):common+250]))
    print("  CYCLE 2 >>", repr(users[1][max(0, common-300):common+250]))
tail = u.split("</board>", 1)[1] if "</board>" in u else ""
own, board = (u.split("<board>", 1) + [""])[:2]
print(f"  sent {len(s) + len(u)} of 50000 chars (system {len(s)})")
print(f"  stale page shown: {'STALEFETCH' in u} | fresh document shown: {'FRESHDOC' in u}")
print(f"  after </board>: {[l[:22] for l in tail.strip().splitlines() if l[:1].isupper() and (l.startswith(('YOUR ACTUAL','YOUR INBOX','TODAY','SELECTED','caps','AN ACTION','YOU MAY NOT','Choose')))]}")
# The prompt goes as three user messages (V1); for measuring blocks, the line
# that separates them separates blocks like any blank line.
u = u.replace("\n\u241e\n", "\n\n")
def size(head):
    i = u.find(head)
    if i < 0: return 0
    j = min([k for k in (u.find("\n\n", i + len(head)),) if k > 0] or [len(u)])
    return j - i
blocks = [b for b in u.replace("<board>", "\n\n").replace("</board>", "\n\n").split("\n\n") if b.strip()]
def blen(head):
    # a block runs from its heading until the next block heading
    i = u.find(head)
    if i < 0: return 0
    rest = u[i:]
    ends = [rest.find("\n\n" + h2) for h2 in heads if h2 != head and rest.find("\n\n" + h2) > 0]
    return min(ends) if ends else len(rest)
heads = ("YOUR LAST BUILD", "WHAT ACTUALLY MOVED", "FRONT PAGE", "COMMENTS YOU COULD ANSWER", "THE THREAD YOU READ MOST RECENTLY",
         "YOUR GOALS RIGHT NOW", "THE DOCUMENT YOU OPENED", "WHAT YOU HAVE ALREADY SAID", "THINGS YOU NOTED FROM", "WHAT YOU REMEMBER",
         "POSTING IS CLOSED", "YOUR PROJECT", "MEMORIES THAT CARRY", "THREADS YOU HAVE READ", "YOUR ACTUAL SITUATION", "INBOX \u2014 NEW",
         "WHAT CAN STOP AN ACTION", "THE FIELDS THE API", "YOUR INBOX, AND HOW", "TODAY (server)")
for h in ("YOUR LAST BUILD", "WHAT ACTUALLY MOVED", "FRONT PAGE", "COMMENTS YOU COULD ANSWER", "THE THREAD YOU READ MOST RECENTLY", "YOUR GOALS RIGHT NOW", "THE DOCUMENT YOU OPENED"):
    print(f"    {h:34} {blen(h):6} chars")
print(f"  system prompt lists seed weights: {'understand: 0.' in s or 'witness: 0.' in s}")
