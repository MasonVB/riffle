# ==========================================================================
# With riffle's section full and ~6,000 characters of protected inbox on
# the board, the prompt still fits and the thread riffle is working on is
# kept.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That riffle's share of the room never leaves the board too little
#   for its own protected blocks, so a big inbox cannot push the prompt
#   over the room or force the thread out whole.
#
# WHY IT EXISTS
#   Round 2's split fit gave riffle's section a fixed share; without a
#   guard, a full section plus a large inbox overran the room by 179
#   characters and left the thread out. The share is now the smaller of
#   65% and what the board's protected blocks leave.
#
# HOW IT WORKS
#   Calls the tree's _fit on synthetic own and board blocks in a
#   14,900-character room (the box's).
#
# READING THE OUTPUT
#   `sent N (fits), the thread: kept, M chars`; 'OVER' or 'LEFT OUT' is
#   the failure.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tu2d.py) for the round-2 split fit,
#               after two weaker versions of the test failed to reach the
#               danger.
#   2026-11-05  Moved into tests/prompt.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys; sys.path.insert(0, sys.argv[1])
from agent import cycle
L = lambda tag, n: (tag + " ") * (n // (len(tag) + 1))
own = ["WHAT CAN STOP AN ACTION:\n" + L("rule", 1500), "YOUR GOALS RIGHT NOW:\n" + L("goal", 1400),
       "YOUR PROJECT: T\n" + L("proj", 2900), "WHAT YOU HAVE ALREADY SAID:\n" + L("said", 1900),
       "ALREADY DONE \u2014 x:\n" + L("done", 850), "QUESTIONS YOU HAVE ASKED:\n" + L("q", 600)]
board = ["INBOX \u2014 NEW, newest first:\n" + L("msg", 4700), "INBOX \u2014 OLDER, from before:\n" + L("old", 1280),
         "THE THREAD YOU READ MOST RECENTLY:\n" + L("thr", 3400), "FRONT PAGE — an index:\n" + L("fp", 1900)]
room = 14900
out = cycle._fit(own + board, room, None)
tot = sum(len(x) + 2 for x in out)
thr = next(x for x in out if "THE THREAD YOU READ" in x[:40])
print(f"  room {room}, ~6,000 protected inbox chars: sent {tot} ({'fits' if tot <= room else 'OVER by %d' % (tot - room)}), the thread: {'LEFT OUT' if thr.startswith('[') else 'kept, %d chars' % len(thr)}")
