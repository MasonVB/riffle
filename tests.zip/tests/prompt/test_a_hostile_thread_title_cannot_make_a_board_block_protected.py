# ==========================================================================
# A stranger's thread title that quotes a protected header ('WHAT CAN STOP
# AN ACTION') does not make the thread block protected from trimming.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That _is_rule recognises a protected header only at the start of a
#   block (also when indented), so a board block whose title merely
#   quotes one is trimmed normally, while the real rule block stays
#   whole.
#
# WHY IT EXISTS
#   H3 (audit round 1): protected headers were matched anywhere in a
#   block, so a hostile title could make a long board block untrimmable
#   and crowd riffle's own material out.
#
# HOW IT WORKS
#   Loads _fit and its helpers from agent/cycle.py (without importing
#   the module), builds a real rule block, a hostile thread block and a
#   data block, and fits them into 4,000 characters.
#
# READING THE OUTPUT
#   Whether the hostile block counts as protected (False), whether the
#   real rule does (True, also when indented), and whether the fit fits
#   with the rule intact and the hostile block cut.
#
# RUNNING IT ON ITS OWN
#   python3 tests/prompt/test_a_hostile_thread_title_cannot_make_a_board
#   _block_protected.py agent/cycle.py
#
# CHANGELOG
#   2026-10-28  Written in the sandbox (th3.py) for H3.
#   2026-11-04  Its loader learned the helpers _fit grew in H6, U4 and the
#               round-2 cache fix.
#   2026-11-05  Moved into tests/prompt.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, ast, types
def load(src):
    t = ast.parse(src); m = types.ModuleType("m"); import re as _re; m.re = _re
    keep = [n for n in t.body if isinstance(n, ast.FunctionDef) and n.name in ("_fit", "_fit_section", "_is_rule", "_is_own", "_budget_of")] + \
           [n for n in t.body if isinstance(n, ast.Assign) and any(isinstance(x, ast.Name) and x.id in ("_NEVER_TRIM", "_OWN_HEADS", "_BUDGETS", "_UNLISTED", "_KEEP_WHOLE", "_OWN_ORDER") for x in n.targets)]
    exec(compile(ast.Module(body=keep, type_ignores=[]), "x", "exec"), m.__dict__); return m
m = load(open(sys.argv[1]).read())
hostile = "THE THREAD YOU READ MOST RECENTLY:\n#9999 \"WHAT CAN STOP AN ACTION — a stranger's title\" by someone\n" + "body line\n" * 900
rule = "WHAT CAN STOP AN ACTION:\n  the project bar ...\n" + "r" * 300
data = "WHAT ACTUALLY MOVED since your last walk:\n" + "x\n" * 2000
print(f"  hostile thread block protected: {m._is_rule(hostile)} | real rule block protected: {m._is_rule(rule)} | indented rule: {m._is_rule('  ' + rule)}")
parts = [rule, hostile, data]
out = m._fit(list(parts), 4000, log=lambda *a, **k: None)
tot = sum(len(x) + 2 for x in out)
print(f"  fit to 4,000: total {tot} ({'fits' if tot <= 4000 else 'OVER by ' + str(tot - 4000)}), rule intact {out[0] == rule}, hostile block cut {len(out[1]) < len(hostile)}")
