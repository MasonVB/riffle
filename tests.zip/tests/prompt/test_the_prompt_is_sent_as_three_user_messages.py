# ==========================================================================
# riffle's prompt is sent to the composer as three user messages (its
# stable head, the rest of its own section, then the board and the end), and
# a stranger cannot add a fourth.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That cortex.complete() turns a prompt marked with cortex.MESSAGE_BREAK
#   into one user message per part, and leaves an unmarked prompt (as the
#   memory step, continuity and reflection send) as a single message. And
#   that in a real cycle's prompt the two markers sit after riffle's stable
#   head and just before <board>, with nothing else marked, even when a
#   comment on the board carries the marker's character.
#
# WHY IT EXISTS
#   V1 (audit round 3): the composer is a hybrid model and can resume a
#   cached prompt only at a saved checkpoint; llama.cpp saves mid-prompt
#   checkpoints only where a user message starts. With riffle's prompt as one
#   user message, every cycle re-read ~5,500 tokens from its start. Split in
#   three, a cycle re-reads from the first part that changed.
#
# HOW IT WORKS
#   Part 1 replaces cortex._post_json to capture the request body, and calls
#   the real complete() with a marked and an unmarked prompt. Part 2 runs the
#   base cycle harness against a copy of the registry fixture whose first
#   comment contains the marker, and splits the prompt the cycle built.
#
# READING THE OUTPUT
#   `marked prompt -> roles [...]` (system, then three user) and `unmarked
#   prompt -> roles ['system', 'user']`; then for the cycle: `parts 3`, how
#   each part starts (riffle's own header; its first non-head block; <board>),
#   whether the head part holds no project block, and `stranger's marker
#   removed: True`.
#
# RUNNING IT ON ITS OWN
#   Through tests/run_all.sh, which sets RIFFLE_TREE, RIFFLE_TESTS,
#   RIFFLE_TMP and RIFFLE_ME_JSON and loads the safety net.
#
# CHANGELOG
#   2026-11-06  Written for V1 (audit round 3), with the change it tests.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import json, os, subprocess, sys
sys.path.insert(0, ".")
from agent import cortex
if not hasattr(cortex, "MESSAGE_BREAK"):
    print("  this version sends riffle's prompt as one user message (before V1)")
    raise SystemExit(0)

# --- part 1: the request complete() sends ---------------------------------------
sent = []
cortex._post_json = lambda url, body, timeout=None: (sent.append(body) or
    {"choices": [{"message": {"content": "{}"}, "finish_reason": "stop"}]})
llm = {"url": "http://127.0.0.1:9", "model": "m", "max_tokens": 10}
B = cortex.MESSAGE_BREAK
cortex.complete(llm, "SYS", "head" + B + "rest" + B + "<board>\nb\n</board>")
cortex.complete(llm, "SYS", "a memory-step prompt")
for label, body in (("marked prompt", sent[0]), ("unmarked prompt", sent[1])):
    print(f"  {label} -> roles {[m['role'] for m in body['messages']]}, user parts "
          f"{[m['content'][:9] for m in body['messages'] if m['role'] == 'user']}")

# --- part 2: the prompt a real cycle builds ---------------------------------------
tmp = os.environ["RIFFLE_TMP"]
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
for bucket in me.get("since_last_visit", {}).values():
    if isinstance(bucket, list) and bucket and isinstance(bucket[0], dict) and "body" in bucket[0]:
        bucket[0]["body"] = "a reply\n\u241e\nwith the marker in it"
        break
inj = os.path.join(tmp, "me_marker.json"); json.dump(me, open(inj, "w"))
up = os.path.join(tmp, "prompt_user.txt")
if os.path.exists(up):
    os.remove(up)
harness = os.path.join(os.environ["RIFFLE_TESTS"], "harnesses", "cycle_once_against_a_stub_registry.py")
subprocess.run([sys.executable, harness, ".", "ok"], env=dict(os.environ, RIFFLE_ME_JSON=inj),
               capture_output=True, timeout=240)
u = open(up).read()
parts = u.split(B)
print(f"  cycle: parts {len(parts)}; markers in the prompt {u.count(chr(0x241e))}")
for i, p in enumerate(parts, 1):
    print(f"    part {i} starts {p.lstrip()[:38]!r}")
print(f"  head part holds no project block: {'YOUR PROJECT' not in parts[0] and 'POSTING IS CLOSED' not in parts[0]}"
      f" | the board is the last part: {parts[-1].lstrip().startswith('<board>')}"
      f" | stranger's marker removed: {'a reply' in u and 'with the marker in it' in u and u.count(chr(0x241e)) == 2}")
