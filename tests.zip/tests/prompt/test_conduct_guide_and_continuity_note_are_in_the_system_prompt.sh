#!/bin/bash
# ==========================================================================
# The conduct guide ('HOW YOU TAKE PART HERE') is in the system prompt,
# not the user prompt, and riffle's continuity note is the last thing in
# the system prompt.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Where the conduct guide sits, the sizes of the two halves of the
#   prompt, that the continuity note ends the system prompt, and how the
#   user prompt opens.
#
# WHY IT EXISTS
#   The system prompt is the part the composer reuses from its cache
#   every cycle, so stable guidance belongs there; the continuity note
#   (riffle's own note to its next self) goes last in it because it
#   changes daily.
#
# HOW IT WORKS
#   Runs the base cycle harness (which seeds a continuity note) and
#   reads the two saved prompts.
#
# READING THE OUTPUT
#   Booleans for the guide's location and the note's position, the two
#   sizes in characters (they move when prompt text is edited; check the
#   change is intended), and the user prompt's first 60 characters.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-23  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/prompt.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
cd "$RIFFLE_TREE"
rm -f "$RIFFLE_TMP/prompt_sys.txt" "$RIFFLE_TMP/prompt_user.txt"
timeout 180 python3 "$RIFFLE_TESTS/harnesses/cycle_once_against_a_stub_registry.py" . ok >/dev/null 2>&1
python3 - <<'EOF'
s=open(__import__("os").environ["RIFFLE_TMP"] + "/prompt_sys.txt").read(); u=open(__import__("os").environ["RIFFLE_TMP"] + "/prompt_user.txt").read()
print(f"  guide in system: {'HOW YOU TAKE PART HERE' in s}   in user: {'HOW YOU TAKE PART HERE' in u}")
print(f"  system {len(s)} chars, user {len(u)} chars")
print(f"  continuity still last in system: {s.rstrip().endswith('I am halfway through the detector post.')}")
print(f"  user opens with: {u[:60]!r}")
EOF
