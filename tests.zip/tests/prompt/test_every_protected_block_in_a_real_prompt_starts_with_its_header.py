# ==========================================================================
# In a real prompt, every block protected from trimming starts with its
# protected header.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Counts, over a real cycle's prompt blocks, how many protected blocks
#   start with their header; the runner prints the count. It changes
#   when blocks move: since the round-2 work some protected blocks sit
#   at the end of the prompt, after </board>, where nothing trims them,
#   so they no longer pass through _fit.
#
# WHY IT EXISTS
#   H3 (audit round 1): a protected block that does not start with its
#   header would only be protected by accident, or not at all.
#
# HOW IT WORKS
#   Wraps cycle._fit to capture the blocks it is given, runs the every-
#   kind-of-block harness, and checks each block _is_rule accepts.
#
# READING THE OUTPUT
#   One line per protected block, `... starts with its header: True`;
#   the runner counts the True lines.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-28  Written in the sandbox (hrules.py) for H3.
#   2026-11-05  Moved into tests/prompt; runs the committed harness.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
# Which blocks are protected by _is_rule in a realistic prompt, and does each START with its header?
import sys, os, runpy
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle
captured = []
orig_fit = cycle._fit
def spy(parts, budget, log=None, **k):
    captured.extend(parts); return orig_fit(parts, budget, log, **k)
cycle._fit = spy
sys.argv = ["x", repo, "ok"]
try: runpy.run_path(__import__("os").environ["RIFFLE_TESTS"] + "/harnesses/cycle_once_with_every_kind_of_prompt_block.py", run_name="__main__")
except SystemExit: pass
for p in captured:
    if cycle._is_rule(p):
        head = p.lstrip()[:60].replace("\n", " ")
        starts = any(p.lstrip().startswith(k) for k in cycle._NEVER_TRIM)
        print(f"  protected, starts with its header: {starts}  | {head!r}")
