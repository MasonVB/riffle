# ==========================================================================
# cycle._fit, the function that brings the prompt under budget, keeps
# protected rules whole, never doubles a cut marker, never cuts an item in
# half, and reports when even the rules alone do not fit.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For a protected rule block of 9,888 characters plus twenty data
#   blocks (three large, five medium, twelve small), at three budgets:
#   whether the result fits, whether the rule block is untouched, how
#   many blocks carry two cut markers (must be 0), how many were cut
#   mid-item (must be 0), how many were left out whole, and how many
#   errors were logged (one per section when the rules alone are over
#   budget).
#
# WHY IT EXISTS
#   H6 (audit round 1) replaced longest-first trimming with per-block
#   budgets by importance; round 2 split the fit into riffle's own
#   section and the board and made the own section's cut points stable
#   for the composer's cache. Each change could have broken the basic
#   guarantees this checks.
#
# HOW IT WORKS
#   Loads only _fit and the functions and tables it needs out of
#   agent/cycle.py (by parsing the file, without importing the module),
#   builds the synthetic blocks, and fits them at three budgets.
#
# READING THE OUTPUT
#   One line per budget: `budget N: total M (fits|OVER by K), rules
#   intact True, double markers 0, cut mid-item 0, left out L, errors
#   E`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/prompt/test_fitting_by_importance_keeps_rules_whole_an
#   d_never_cuts_mid_item.py agent/cycle.py
#
# CHANGELOG
#   2026-10-28  Written in the sandbox (tfit.py) for H6, comparing the old and
#               new _fit side by side.
#   2026-11-04  Its loader learned the helpers and tables _fit grew:
#               _budget_of, _BUDGETS, _UNLISTED (H6), _KEEP_WHOLE (U4),
#               _fit_section and _OWN_ORDER (the round-2 cache fix). Without
#               them it crashed with a NameError.
#   2026-11-05  Moved into tests/prompt and made to check one tree: comparing
#               two versions is tests/compare_two_versions.sh's job.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, ast, types, importlib
def load(src):
    t = ast.parse(src); m = types.ModuleType("m"); import re as _re; m.re = _re
    keep = [n for n in t.body if isinstance(n, ast.FunctionDef) and n.name in ("_fit", "_fit_section", "_is_rule", "_is_own", "_budget_of")] + \
           [n for n in t.body if isinstance(n, ast.Assign) and any(isinstance(x, ast.Name) and x.id in ("_NEVER_TRIM", "_OWN_HEADS", "_BUDGETS", "_UNLISTED", "_KEEP_WHOLE", "_OWN_ORDER") for x in n.targets)]
    exec(compile(ast.Module(body=keep, type_ignores=[]), "x", "exec"), m.__dict__); return m
new = load(open(sys.argv[1]).read())
rule_head = new._NEVER_TRIM[0]
def parts():
    ps = [rule_head + "\n" + "r" * 9880]                     # 9,888 protected
    for n in range(20):                                       # data blocks, a few big, many small
        size = 6000 if n < 3 else 1800 if n < 8 else 700
        body = "\n".join(f'{{"comment_id":{n*100+k},"body":"{"x"*60}"}}' for k in range(size // 80))
        ps.append(f"BLOCK {n}:\n" + body)
    return ps
p0 = parts(); total0 = sum(len(x) + 2 for x in p0)
for budget in (total0 - 8000, total0 - 26000, 11000):
    logs = []
    for name, m in (("fit", new),):
        logs.clear()
        out = m._fit(parts(), budget, log=lambda t, level="info": logs.append((level, t)))
        tot = sum(len(x) + 2 for x in out)
        doubled = sum(x.count("characters of this section were cut") > 1 for x in out)
        midline = sum(1 for x in out if "were cut" in x and not x.split("\n[...")[0].endswith("}"))
        print(f"  budget {budget:6}: {name} total {tot:6} ({'OVER by ' + str(tot - budget) if tot > budget else 'fits'}), "
              f"rules intact {out[0] == p0[0]}, double markers {doubled}, cut mid-item {midline}, "
              f"left out {sum(x.startswith('[BLOCK') for x in out)}, errors {sum(l == 'error' for l, _ in logs)}")
