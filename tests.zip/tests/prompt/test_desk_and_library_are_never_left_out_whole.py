# ==========================================================================
# In a crowded prompt, riffle's desk (its drafts) and its library list are
# cut to their floors at worst, never left out whole.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For a room tight enough that the original left both out, the desk
#   and library are kept (cut to their floors) while a lower-ranked
#   block, the nulls note, gives way.
#
# WHY IT EXISTS
#   U4 (audit round 2): on two of three cycles on the box the desk and
#   library were dropped whole, the desk holding riffle's drafts. They
#   now rank with the work at hand and are listed in _KEEP_WHOLE.
#
# HOW IT WORKS
#   Calls the tree's real cycle._fit on synthetic blocks, with the room
#   given as argument 2.
#
# READING THE OUTPUT
#   `desk: kept (N chars) | library: kept (N chars) | nulls note: LEFT
#   OUT | total T of R`.
#
# RUNNING IT ON ITS OWN
#   python3
#   tests/prompt/test_desk_and_library_are_never_left_out_whole.py .
#   4300
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tu4.py) for U4; the room became an
#               argument once the first one tried was not tight enough to show
#               the bug.
#   2026-11-05  Moved into tests/prompt.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys; sys.path.insert(0, sys.argv[1])
from agent import cycle
L = lambda tag, n: (tag + " ") * (n // (len(tag) + 1))
parts = ["WHAT CAN STOP AN ACTION:\n" + L("rule", 3000),
         "YOUR DESK — 1 draft:\n  draft 1: Why the receipts reorder\n" + L("draftline", 700),
         "YOUR LIBRARY — 3 documents:\n" + L("libentry", 330),
         "FRONT PAGE — an index:\n" + "\n".join(L(f"row{i}", 150) for i in range(14)),
         "WHAT ACTUALLY MOVED since your last cycle:\n" + "\n".join(L(f"moved{i}", 120) for i in range(14)),
         "THE NULLS IN WHAT ACTUALLY MOVED:\n" + L("null", 330),
         "YOUR GOALS RIGHT NOW:\n" + "\n".join(L(f"goal{i}", 100) for i in range(12))]
out = cycle._fit(parts, int(sys.argv[2]), None)
def state(head):
    b = next(x for x in out if x.lstrip().startswith(head) or x.lstrip().startswith("[" + head))
    return "LEFT OUT" if b.lstrip().startswith("[") else f"kept ({len(b)} chars)"
print(f"  desk: {state('YOUR DESK')} | library: {state('YOUR LIBRARY')} | nulls note: {state('THE NULLS IN WHAT')} | total {sum(len(x) for x in out)} of {sys.argv[2]}")
