# ==========================================================================
# An approved library_put shelves the document and is recorded as
# executed.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The action's status and response, and the number of documents on the
#   shelf (1).
#
# WHY IT EXISTS
#   The earlier review: local actions approved on the dashboard must
#   run, once, in the next cycle.
#
# HOW IT WORKS
#   Queues an approved library_put and runs a real cycle.
#
# READING THE OUTPUT
#   `approved library_put -> ('executed', ...library-shelved...)` and
#   `documents on the shelf: 1`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-25  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/cycle.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
cortex.complete = lambda *a, **k: json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle"}, "rationale": "nothing to do this cycle"})
d = tempfile.mkdtemp(); lib = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg.setdefault("library", {})["root"] = lib
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite"))
body = "# Coupled Detector Stasis: Final Simulation Results\n\n## Context\n" + "A paragraph of findings.\n" * 200
st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,'2026-10-24T00:00:00Z','library_put','understand',?,'shelving my results','approved')",
              (json.dumps({"title": "Coupled Detector Stasis: Final Simulation Results and Structural Limits", "kind": "note", "body": body, "tags": ["stasis"]}),))
st.db.commit()
sys.argv = ["cycle", "--config", cp]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
print("  approved library_put ->", db.execute("SELECT status, response FROM actions WHERE kind='library_put'").fetchone())
print("  documents on the shelf:", db.execute("SELECT COUNT(*) FROM library").fetchone()[0])
