# ==========================================================================
# The code fixes among audit round 1's trivial findings, one line each:
# T1, T2, T4, T5, T9, T10, T11, T12 and T13.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   T1 a bare-filename state opens; T2 a card 250 back is found; T4 the
#   run-cycle request goes beside the state database; T5 a dump has its
#   own network baseline; T9 the backlog count matches what is shown;
#   T10 a first load gets the newest messages; T11 an error mid-answer
#   raises; T12 lengths are measured in UTF-16 units, as the registry
#   does; T13 the top-level window counts from when a comment was sent.
#
# WHY IT EXISTS
#   Each is a small inconsistency the audit found; together they are
#   cheap to keep fixed.
#
# HOW IT WORKS
#   One small check per item, run in a temporary directory.
#
# READING THE OUTPUT
#   One line per item stating its result.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-31  Written in the sandbox (ttriv.py) for T1 to T13.
#   2026-11-05  Moved into tests/cycle.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, time; sys.path.insert(0, sys.argv[1])
from agent.state import State, utcnow
from agent import inbox, cycle, dash, telemetry, drives, cortex, chat
d = tempfile.mkdtemp(); os.chdir(d)
def T(name, fn):
    try: print(f"  {name:4} {fn()}")
    except Exception as e: print(f"  {name:4} RAISED {type(e).__name__}: {str(e)[:70]}")
T("T1", lambda: f"State('bare.sqlite') opens: {bool(State('bare.sqlite'))}")
st = State(os.path.join(d, "s.sqlite"))
def t2():
    st.db.execute("INSERT INTO messages (ts,role,content,meta) VALUES (?, 'proposal', 'old card', ?)", (utcnow(), json.dumps({"action_id": 4242, "status": "queued"})))
    for i in range(250):
        st.db.execute("INSERT INTO messages (ts,role,content,meta) VALUES (?, 'proposal', 'newer', ?)", (utcnow(), json.dumps({"action_id": 9000 + i})))
    st.db.commit(); mid, meta = dash.card_for(st, 4242)
    return f"a card 250 cards back is found: {mid is not None}"
T("T2", t2)
def t4():
    dash.request_cycle_run(st, "test")
    return f"request written beside the state db: {os.path.exists(os.path.join(d, 'run-cycle.request'))}"
T("T4", t4)
def t5():
    telemetry._LAST.clear() if hasattr(telemetry, "_LAST") else None
    try: telemetry.network("tick"); r = telemetry.network("dump")
    except TypeError: telemetry.network(); r = telemetry.network()
    return f"a dump's first reading has its own baseline: {r == {'note': 'first sample since restart'}}"
T("T5", t5)
def t9():
    inbox.ensure(st)
    st.db.execute("INSERT INTO inbox_items (key,source,buckets,comment_id,post_id,body,created_ms,first_seen,status,shown_count) VALUES ('c777','backlog','replies',777,4,'b',1,?,'pending',0)", (utcnow(),))
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'comment','answer',?,'r','queued')", (utcnow(), json.dumps({"post_id": 4, "parent_id": 777, "body": "b"})))
    st.db.commit()
    return f"backlog count {inbox.counts(st)['backlog']}, shown by pending() {len(inbox.pending(st, 'backlog'))} (should agree)"
T("T9", t9)
def t10():
    for i in range(5): st.say("agent", f"msg {i}")
    rows = st.messages(after=0, limit=3)
    return f"first load of 3 gets: {[r['content'] for r in rows]}"
T("T10", t10)
def t11():
    import urllib.request, io
    lines = [b'data: {"choices":[{"delta":{"content":"Hel"}}]}\n', b'data: {"error":{"message":"KV cache full"}}\n', b'data: [DONE]\n']
    class R(io.BytesIO):
        def __enter__(self): return self
        def __exit__(self, *a): pass
        def __iter__(self): return iter(lines)
    chat.urllib.request.urlopen = lambda *a, **k: R()
    out = chat.stream_completion({"url": "http://x"}, [], lambda d: None)
    return f"an error mid-answer returned quietly: {out!r}"
T("T11", t11)
def t12():
    lim = cortex.TITLE_LIMIT
    title = "Rockets " + "\U0001F680" * 4 + "x" * (lim - 8 - 4)        # lim characters, lim+4 UTF-16 units
    u16 = len(title.encode("utf-16-le")) // 2
    try:
        drives._s(title, 1, lim, "title"); g = "passed the gate"
    except drives.Rejected: g = "refused by the gate"
    body = "word " * 400 + "\U0001F680" * 30
    t = drives._trim(body, 1, 1500, "body")
    return f"title of {len(title)} chars = {u16} registry units vs limit {lim}: {g}; a trimmed body is {len(t.encode('utf-16-le'))//2} units of 1500"
T("T12", t12)
def t13():
    old = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 30 * 3600))
    now = utcnow()
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status,executed_at) VALUES (1,?,'comment','answer',?,'r','executed',?)",
                  (old, json.dumps({"post_id": 555, "body": "a top-level comment"}), now))
    st.db.commit()
    return f"approved 30h after proposal, sent just now, counts today: {bool(cycle.top_level_today(st, 555))}"
T("T13", t13)
