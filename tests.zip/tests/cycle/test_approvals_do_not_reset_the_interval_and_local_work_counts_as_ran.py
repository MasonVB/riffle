# ==========================================================================
# A wake that runs approvals still goes on to a full cycle when one is
# due; and riffle's record counts local work as having run.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The approval's status, that a real cycle ran after it, that 'not
#   due' was not logged, and the YOUR RECORD line (read_thread 3(3
#   ran)).
#
# WHY IT EXISTS
#   L6 (audit round 1): rows opened to run an approval reset the
#   interval gate, so the wake quit 'not due'. L2: the record counted
#   only `executed`, so local work showed as never sent.
#
# HOW IT WORKS
#   A non-forced real cycle with a real cycle 20 minutes old (against a
#   15-minute interval), three accepted read_threads and an approved
#   note.
#
# READING THE OUTPUT
#   `approval ran: ... | real cycle ran after it: True | 'not due'
#   logged: False` and the record line.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl6.py) for L6 and L2. Its approved
#               note uses a wrong field and fails; that does not matter, since
#               the failing approval still opens its row.
#   2026-11-05  Moved into tests/cycle.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, time
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, project
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
prompts = []
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    prompts.append(user)
    return json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg.setdefault("cycle", {})["interval_minutes"] = 15
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
c = st.begin_cycle("understand"); st.end_cycle(c, "noop", "")
twenty = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 20 * 60))
st.db.execute("UPDATE cycles SET started_at=?, ended_at=? WHERE id=?", (twenty, twenty, c))
for i in range(3):
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,'2026-10-25T00:00:00Z','read_thread','understand','{\"post_id\": 4}','r','accepted')")
st.db.execute("INSERT INTO actions (id,cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (900,1,'2026-10-29T00:00:00Z','project_note','deepen',?,'r','approved')",
              (json.dumps({"text": "An approved note about the receipts question."}),))
st.db.commit()
st.note("cycle_interval_minutes", "15")
sys.argv = ["cycle", "--config", cp]                     # NOT forced: the interval gate applies
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
a = db.execute("SELECT status FROM actions WHERE id=900").fetchone()[0]
notdue = db.execute("SELECT COUNT(*) FROM journal WHERE text LIKE 'not due:%'").fetchone()[0]
rec = [l.strip()[:90] for l in (prompts[-1] if prompts else "").splitlines() if "YOUR RECORD" in l]
print(f"  approval ran: {a!r} | real cycle ran after it: {bool(prompts)} | 'not due' logged: {bool(notdue)}")
print(f"  {rec[0] if rec else '(no prompt, so no record line)'}")
