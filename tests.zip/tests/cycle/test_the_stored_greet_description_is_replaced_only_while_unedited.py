# ==========================================================================
# The stored description of the greet drive is replaced by the corrected
# text only while it is still word for word one of the two original seeds;
# an edited one is left alone.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the stored text: `goals` or `cycle` (the two
#   original seeds: REPLACED) or `edited` (the operator's own words:
#   unchanged).
#
# WHY IT EXISTS
#   L22 (audit round 1): the greet description said 'not capped per day'
#   after the porch got a cap of three. A seed is written once, so the
#   box kept the old text; it is replaced in place, but never over an
#   operator's edit.
#
# HOW IT WORKS
#   Stores the given text as the greet description and runs a real
#   cycle. The two original seed strings are embedded below, copied from
#   the code as it was before L22, because the replacement must match
#   what the old code stored character for character.
#
# READING THE OUTPUT
#   `stored KIND seed: REPLACED|unchanged -> '...'`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/cycle/test_the_stored_greet_description_is_replaced_on
#   ly_while_unedited.py . goals
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tgreetdesc.py) for L22, taking the
#               original strings from an extracted copy of the old code.
#   2026-11-05  Moved into tests/cycle with the two original strings embedded.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, re, ast
repo, which = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
# The two seed strings as the code before L22 stored them (agent/goals.py
# and agent/cycle.py), embedded: the old files are not in a later tree.
ORIGINAL_GOALS_SEED = 'the porch: not capped per day, paced — ten seconds between lines at first, slower the more you say. Nothing ranked. Say hello, thank someone, congratulate a result, or disagree in ordinary words'
ORIGINAL_CYCLE_SEED = 'the porch: not capped per day, paced. Nothing ranked. Say hello, congratulate, thank, disagree in plain words — the social room, not the record'
def concat_after(src, start):          # evaluate the run of adjacent string literals beginning at `start`
    i = src.index(start); j = src.index("\n", i)
    m = re.match(r'((?:\s*"(?:[^"\\]|\\.)*"\s*)+)', src[i - 1:])
    return ast.literal_eval("(" + m.group(1) + ")")
old = {"goals": ORIGINAL_GOALS_SEED,
       "cycle": ORIGINAL_CYCLE_SEED,
       "edited": "my own words about the porch"}[which]
from agent import cycle, cortex
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"}) \
    if "Choose ONE action" in user else json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite"))
from agent import goals; goals.ensure(st) if hasattr(goals, "ensure") else None
st.db.execute("INSERT INTO drives (name,weight,locked,description,created_at,created_by) VALUES ('greet',0.08,0,?,'2026-10-01T00:00:00Z','seed')", (old,))
st.note("seeded:greet", "x"); st.db.commit()
sys.argv = ["cycle", "--config", cp]
try: cycle.main()
except SystemExit: pass
new = sqlite3.connect(os.path.join(d, "state.sqlite")).execute("SELECT description FROM drives WHERE name='greet'").fetchone()[0]
print(f"  stored {which:6} seed: {'REPLACED' if new != old else 'unchanged'} -> {new[:60]!r}")
