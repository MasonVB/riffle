#!/bin/bash
# ==========================================================================
# An approved action interrupted by a crash is recorded as unknown and not
# run again on the next wake.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   After a wake that dies in the middle of an approved close_project:
#   the process's exit code and the action's status; after the next,
#   normal wake: the action is still not run again, and the projects are
#   as they were.
#
# WHY IT EXISTS
#   M8 (audit round 1): the action was marked running only after it ran,
#   so a crash in the middle left it approved and the next wake ran it
#   again, closing a second project.
#
# HOW IT WORKS
#   Prepares a state with two projects and an approved close, then runs
#   the one-wake harness twice.
#
# READING THE OUTPUT
#   Two lines, after wake 1 and after wake 2, with the action's status
#   and the projects.
#
# RUNNING IT ON ITS OWN
#   tests/cycle/test_an_action_interrupted_by_a_crash_is_not_run_again.s
#   h .
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm8.sh) for M8.
#   2026-11-05  Moved into tests/cycle.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
# wake 1 crashes mid-action; wake 2 is normal. Does the approved close run twice?
tree=$1; d=$(mktemp -d)
python3 - "$tree" "$d" <<'EOF'
import sys, os, json, yaml; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import project
d = sys.argv[2]
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x"); yaml.safe_dump(cfg, open(os.path.join(d, "c.yaml"), "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (id,opened_at,title,question,status) VALUES (1,'2026-10-20T00:00:00Z','First','Q1?','active')")
st.db.execute("INSERT INTO projects (id,opened_at,title,question,status) VALUES (2,'2026-10-21T00:00:00Z','Second','Q2?','queued')")
st.db.execute("INSERT INTO actions (id,cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (900,1,'2026-10-25T00:00:00Z','close_project','deepen',?,'stuck','approved')",
              (json.dumps({"reason": "I have stopped being able to move this question."}),))
st.db.commit()
EOF
timeout 240 python3 "$RIFFLE_TESTS/harnesses/one_wake_that_runs_an_approved_close_project.py" "$tree" "$d" crash >/dev/null 2>&1; echo "    wake 1 exit code: $? (1 = died mid-action)"
python3 -c "import sqlite3; db=sqlite3.connect('$d/state.sqlite'); print('    after wake 1: action', db.execute('SELECT status FROM actions WHERE id=900').fetchone()[0], '| projects', db.execute('SELECT id,status FROM projects ORDER BY id').fetchall())"
timeout 240 python3 "$RIFFLE_TESTS/harnesses/one_wake_that_runs_an_approved_close_project.py" "$tree" "$d" normal >/dev/null 2>&1
python3 -c "import sqlite3; db=sqlite3.connect('$d/state.sqlite'); print('    after wake 2: action', db.execute('SELECT status FROM actions WHERE id=900').fetchone()[0], '| projects', db.execute('SELECT id,status FROM projects ORDER BY id').fetchall())"
