# ==========================================================================
# An action the operator approved on the dashboard runs on the next wake,
# and a failure is recorded with the reason.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For an approved library_read of a missing document: the action's
#   final status and the cycle's outcome (failed, library-missing), the
#   journal's explanation, and that the wake goes on to a full cycle.
#
# WHY IT EXISTS
#   The earlier review: approved local actions run in the cycle, not the
#   dashboard (the dashboard runs without privilege). L6 (audit round 1)
#   later made the wake go on to a full cycle after running them.
#
# HOW IT WORKS
#   Queues an approved library_read, then runs a real cycle against the
#   stub registry.
#
# READING THE OUTPUT
#   The action and outcome, the journal lines, and the base harness's
#   order line, which shows a full cycle after the approval.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-23  Generated in the sandbox as /tmp/hack10.py from the base
#               harness, during the earlier review.
#   2026-11-05  Committed as a file in tests/cycle.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml
repo = sys.argv[1]; mode = sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
calls = []
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        def f(*a, **k):
            calls.append(n)
            if n == "me": return copy.deepcopy(me)
            if n == "ack": return {"mode": "legacy", "advanced": True}
            return {}
        return f
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
_real = cortex.complete
def complete(*a, **k):
    calls.append("COMPOSER"); open(__import__("os").environ["RIFFLE_TMP"] + "/prompt_user.txt","w").write(a[2] if len(a)>2 else k.get("user",""))
    if mode == "fail": raise RuntimeError("composer died")
    return json.dumps({"action": "noop", "payload": {}, "rationale": "nothing to do"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
from agent.state import State as _S; _s=_S(os.path.join(d,"state.sqlite")); _s.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,'2026-10-24T00:00:00Z','library_read','understand','{\"id\": 999}','r','approved')"); _s.db.commit()
sys.argv = ["cycle", "--config", cp]
try:
    rc = cycle.main()
except SystemExit as e:
    rc = f"exit {e.code}"
except Exception as e:
    import traceback; traceback.print_exc(limit=3); rc = "RAISED"
import sqlite3
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
seq = [c for c in calls if c in ("me", "ack", "COMPOSER")]
r=sqlite3.connect(os.path.join(d,"state.sqlite")).execute("SELECT a.status, c.outcome FROM actions a LEFT JOIN cycles c ON c.id=(SELECT MAX(id) FROM cycles WHERE outcome LIKE 'library%') WHERE a.kind='library_read'").fetchone(); print("  approved library_read of a missing id -> status", r[0], "| outcome", r[1]); [print("   J:", t[:160]) for (t,) in sqlite3.connect(os.path.join(d,"state.sqlite")).execute("SELECT text FROM journal WHERE text LIKE '%library%' OR text LIKE '%approved%' OR level IN ('error','warn') ORDER BY id LIMIT 8")]; [print("   R:", x) for x in sqlite3.connect(os.path.join(d,"state.sqlite")).execute("SELECT * FROM actions WHERE kind='library_read'").fetchall()]
print(f"  [{mode}] rc={rc} order={seq}")
for (t,) in db.execute("SELECT text FROM journal WHERE text LIKE '%inbox%' OR text LIKE 'composer failed%'"):
    print("   journal:", t[:150])
print("   inbox in prompt:", "YOUR INBOX" in open(__import__("os").environ["RIFFLE_TMP"] + "/prompt_user.txt").read() if os.path.exists(__import__("os").environ["RIFFLE_TMP"] + "/prompt_user.txt") else None)
#, "YOUR INBOX" in open(os.path.join(d, "last_prompt.txt")).read() if os.path.exists(os.path.join(d,"last_prompt.txt")) else "(prompt not saved)")
