# ==========================================================================
# A crash in the cycle is recorded as a crash, with its traceback, the
# cycle closed and the operator told; a failed front-page fetch is
# survived.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: `crash` (an exception mid-cycle: the
#   process's code, the last cycle's outcome and that it is closed, the
#   traceback in the journal, a chat report) or `front` (the front page
#   fails: the cycle goes on and says so).
#
# WHY IT EXISTS
#   H5 (audit round 1): a crash left the cycle open, unrecorded and
#   silent, and a front-page failure killed the cycle.
#
# HOW IT WORKS
#   A real cycle, with an exception injected at the right point.
#
# READING THE OUTPUT
#   `[case] process ...; last cycle outcome=...; error with
#   traceback=...; chat report=...; front-page warning=...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/cycle/test_a_crash_is_recorded_and_a_failed_front_page
#   _is_survived.py . crash
#
# CHANGELOG
#   2026-10-28  Written in the sandbox (hcrash.py) for H5.
#   2026-11-05  Moved into tests/cycle.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, runpy
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle as _c, cortex, drives
from agent.client import HttpError
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
class Stub:
    def __init__(self, *a, **k): pass
    def front(self, *a, **k):
        if mode == "front": raise HttpError(503, {"error": "registry blip"})
        return {"posts": []}
    def changes(self, *a, **k): return (304, {}, None)
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
import agent.client as client
client.Reader = client.Writer = Stub
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"}) \
    if "Choose ONE action" in user else json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
if mode == "crash":
    def boom(*a, **k): raise TypeError("'sqlite3.Row' object has no attribute 'get'")
    drives.gate = boom
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
sys.argv = ["agent.cycle", "--config", cp]
import agent.cycle
agent.cycle.do_witness = lambda *a, **k: None
agent.cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
src = open(os.path.join(repo, "agent", "cycle.py")).read()
g = dict(vars(agent.cycle)); g["__name__"] = "__main__"
rc = "returned"
try:
    exec(compile(src, os.path.join(repo, "agent/cycle.py"), "exec"), g)
except SystemExit as e: rc = f"exit {e.code}"
except Exception as e: rc = f"raised {type(e).__name__}"
db = sqlite3.connect(os.path.join(d, "state.sqlite")); print("  rc:", rc); [print("   J:", l, t[:140]) for (l, t) in db.execute("SELECT level, text FROM journal ORDER BY id DESC LIMIT 6")]
c = db.execute("SELECT id, outcome, ended_at IS NULL FROM cycles ORDER BY id DESC LIMIT 1").fetchone()
err = db.execute("SELECT COUNT(*) FROM journal WHERE level='error' AND text LIKE 'cycle crashed:%' AND text LIKE '%Traceback%'").fetchone()[0]
chat = db.execute("SELECT COUNT(*) FROM messages WHERE content LIKE '%I crashed%'").fetchone()[0]
fp = db.execute("SELECT COUNT(*) FROM journal WHERE text LIKE 'front page not fetched%'").fetchone()[0]
print(f"  [{mode}] process {rc}; last cycle outcome={c[1]!r} still-open={bool(c[2])}; error with traceback={err}; chat report={chat}; front-page warning={fp}")
