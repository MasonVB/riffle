#!/bin/bash
# ==========================================================================
# update.sh installs only the unit files git tracks: a changed tracked
# unit is installed, an untracked backup file next to it is not.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Which systemctl calls the install step made, whether the untracked
#   .bak was installed (must not be), and whether the real timer was.
#
# WHY IT EXISTS
#   The earlier review: an editor's backup file in systemd/ was
#   installed as a unit.
#
# HOW IT WORKS
#   Extracts the install step from update.sh and runs it with a stand-in
#   sudo, into a temporary unit directory. It leaves an untracked file
#   in the tree, so it must run on a copy.
#
# READING THE OUTPUT
#   The recorded systemctl calls, then `untracked .bak installed: no`
#   and `real timer installed: yes`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-24  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/deploy.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
cd "$RIFFLE_TREE"
T=$(mktemp -d); mkdir -p $T/units $T/bin
cat > $T/bin/sudo <<'EOF'
#!/bin/bash
if [ "$1" = systemctl ]; then echo "    [systemctl ${*:2}]" >> "$LOG"; exit 0; fi
exec "$@"
EOF
chmod +x $T/bin/sudo
awk '/^# --- install changed unit files/{on=1} /^# --- hand-installed copies/{exit} on' update.sh > $T/step.sh
for f in $(git ls-files systemd/); do cp "$f" $T/units/; done
echo "# old" >> $T/units/riffle-cycle.timer
cp systemd/riffle-cycle.timer systemd/riffle-cycle.timer.bak-notify; echo "# junk" >> systemd/riffle-cycle.timer.bak-notify
echo "stale" > $T/units/riffle-cycle.timer.bak-notify
: > $T/log; PATH=$T/bin:$PATH RIFFLE_UNITDIR=$T/units LOG=$T/log bash -euo pipefail $T/step.sh; cat $T/log
echo "  untracked .bak installed: $(cmp -s systemd/riffle-cycle.timer.bak-notify $T/units/riffle-cycle.timer.bak-notify && echo YES || echo no)"
echo "  real timer installed: $(cmp -s systemd/riffle-cycle.timer $T/units/riffle-cycle.timer && echo yes || echo NO)"
rm systemd/riffle-cycle.timer.bak-notify
