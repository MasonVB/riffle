#!/bin/bash
# ==========================================================================
# update.sh installs each unit from what is committed, not from the file
# on disk, and scans every file a deploy brings in for secrets.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Units: a unit edited on the box (one that would write to /root) is
#   NOT installed; the committed one is, and the difference is reported.
#   Scan: a planted bearer secret is flagged with the instruction to
#   rotate it; a clean file is not.
#
# WHY IT EXISTS
#   L9 (audit round 1): units are installed as root, and were taken from
#   the file on disk. L16: uploads made on GitHub's website never passed
#   the pre-commit secret scan.
#
# HOW IT WORKS
#   Extracts each step from update.sh and runs it against a temporary
#   git checkout, with a stand-in sudo. The scan step names /opt/riffle;
#   the test substitutes its own temporary checkout everywhere that path
#   appears, in the step and in its copy of repo_setup.py, so the real
#   /opt/riffle is never touched.
#
# READING THE OUTPUT
#   `== installing units` with the install's report and `installed now:
#   ...COMMITTED`; `== the secret scan` with the flagged line and the
#   rotation advice.
#
# RUNNING IT ON ITS OWN
#   tests/deploy/test_the_deploy_installs_committed_units_and_scans_for_
#   secrets.sh update.sh
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tdeploy.sh) for L9 and L16. Its scan
#               section built its fake checkout AT /opt/riffle, with `rm -rf
#               /opt/riffle` first: on the operator's box, that would have
#               deleted riffle's installation.
#   2026-11-04  Its lock section defers to the U5 lock test once the lock
#               moved to sudo.
#   2026-11-05  Moved into tests/deploy. The fake checkout is in $RIFFLE_TMP
#               and the scan is pointed at it; /opt/riffle is never touched.
#   2026-11-05  Its planted fake token is assembled at run time: written out
#               literally, update.sh's own secret scan flagged THIS file on
#               the deploy that brought it in, telling the operator to rotate
#               a credential that does not exist.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
# --- skip cleanly when something this test needs is missing ---
git -C "${RIFFLE_TREE:-.}" rev-parse >/dev/null 2>&1 || { echo "  SKIPPED: needs a git checkout"; exit 0; }
# ---------------------------------------------------------------
# update.sh's lock, unit-install and secret-scan steps, extracted from the file itself.
U=$(realpath "${1:-update.sh}")
export PATH="$RIFFLE_TESTS/lib/stand_in_sudo:$PATH"
echo "== the cycle lock"
LOCKSNIP=$(awk '/^LOCK="\$\{RIFFLE_CYCLE_LOCK/{on=1} on{print} on && /^fi$/{exit}' "$U")
if grep -q 'sudo test -e' "$U"; then echo "  (the sudo lock is tested by test_the_deploy_holds_the_cycle_lock_through_sudo.sh)"; elif [ -z "$LOCKSNIP" ]; then echo "  (no lock step in this update.sh)"; else
  L=$(mktemp); export RIFFLE_CYCLE_LOCK=$L RIFFLE_LOCK_WAIT=2
  python3 -c "import fcntl,time,sys; f=open('$L'); fcntl.flock(f, fcntl.LOCK_EX); time.sleep(4)" & H=$!; sleep 0.5
  printf "  while a cycle holds the lock: "; bash -c "$LOCKSNIP"$'\necho proceeded' 2>&1 | tr '\n' ' '; echo; wait $H
  printf "  when no cycle is running:     "; bash -c "$LOCKSNIP"$'\necho proceeded; sleep 2' 2>&1 & D=$!; sleep 0.7
  python3 -c "import fcntl; f=open('$L'); fcntl.flock(f, fcntl.LOCK_EX|fcntl.LOCK_NB)" 2>/dev/null && echo "  | a cycle COULD start during the deploy" || echo "  | a cycle cannot start during the deploy"
  wait $D
fi
echo "== installing units"
T=$(mktemp -d); cd $T && git init -q && mkdir systemd && echo "[Service]
ExecStart=/bin/true # COMMITTED" > systemd/test.service && git add -A && git -c user.email=a@b -c user.name=t commit -qm c
echo "[Service]
ExecStart=/bin/sh -c 'id > /root/owned' # EDITED ON THE BOX" > systemd/test.service
UD=$(mktemp -d); echo "old" > $UD/test.service; export RIFFLE_UNITDIR=$UD
UNITSNIP=$(awk '/^UNITDIR="\$\{RIFFLE_UNITDIR/{on=1} on{print} on && /^done$/{exit}' "$U")
bash -c "changed=(); $UNITSNIP"$'\n' 2>&1 | sed 's/^/  /'
echo "  installed now: $(grep ExecStart $UD/test.service)"
echo "== the secret scan"
SCANSNIP=$(awk '/^python3 - "\$BEFORE" "\$AFTER" <<.PYSCAN./{on=1} on{print} on && /^PYSCAN$/{exit}' "$U")
if [ -z "$SCANSNIP" ]; then echo "  (no secret scan in this update.sh)"; else
  FAKE="$RIFFLE_TMP/fake_checkout"; rm -rf "$FAKE"; mkdir -p "$FAKE"
  sed "s#^RIFFLE = \"/opt/riffle\"#RIFFLE = \"$FAKE\"#" "$RIFFLE_TREE/repo_setup.py" > "$FAKE/repo_setup.py"
  SCANSNIP=${SCANSNIP//\/opt\/riffle/$FAKE}   # the step names /opt/riffle: point it at the fake
  cd "$FAKE" && git init -q && echo "x = 1" > a.py && git add -A && git -c user.email=a@b -c user.name=t commit -qm one && B=$(git rev-parse HEAD)
  p=1f916_sk   # the fake token is assembled at run time, so this file itself never trips the scan
  echo "TOKEN = \"${p}_live_abcdefghijklmnopqrstuv\"" > leaked.py && echo "y = 2" > clean.py && git add -A && git -c user.email=a@b -c user.name=t commit -qm two && A=$(git rev-parse HEAD)
  BEFORE=$B AFTER=$A bash -c "BEFORE=$B; AFTER=$A; $SCANSNIP" 2>&1 | sed 's/^/  /'
fi
