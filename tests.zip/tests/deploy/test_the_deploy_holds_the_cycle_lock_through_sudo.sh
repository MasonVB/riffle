#!/bin/bash
# ==========================================================================
# update.sh takes the cycle lock through sudo and holds it until the
# deploy ends: it refuses while a cycle runs, blocks cycles while it runs,
# releases the lock when it ends, and never creates a lock file.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   With a cycle holding the lock: the deploy waits, then refuses
#   loudly. With the lock free: the deploy runs, no cycle can start, and
#   afterwards the lock is free. With no lock file: it says so loudly
#   and creates none.
#
# WHY IT EXISTS
#   U5 (audit round 2): /var/lib/riffle is 700 riffle:riffle, so the
#   deploy's lock, opened as the operator, looked absent and was skipped
#   without a word. A root-owned lock file would stop the cycle, which
#   runs as riffle, from opening it.
#
# HOW IT WORKS
#   Extracts the lock block from update.sh into a small stand-in deploy,
#   with a stand-in sudo, a lock file in a temporary directory and a
#   2-second wait. Run against an update.sh from before U5 (no sudo
#   lock), and as root, it shows that version skipping the lock
#   silently.
#
# READING THE OUTPUT
#   `[new] ...` lines for each situation.
#
# RUNNING IT ON ITS OWN
#   tests/deploy/test_the_deploy_holds_the_cycle_lock_through_sudo.sh
#   update.sh
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tu5.sh) for U5. The stand-in sudo
#               learned `-u USER` when the first design re-ran the deploy
#               under `sudo -u`; that design asked for the password twice on
#               the box, and the check that the lock is free again after the
#               deploy was added for the design that replaced it.
#   2026-11-05  Moved into tests/deploy; the version-before-U5 case runs only
#               as root.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
# --- skip cleanly when something this test needs is missing ---
command -v flock >/dev/null || { echo "  SKIPPED: needs flock (util-linux)"; exit 0; }
# ---------------------------------------------------------------
# The deploy's lock block, extracted from update.sh, around a stub "rest of the deploy".
U=$(realpath "$1"); export PATH="$RIFFLE_TESTS/lib/stand_in_sudo:$PATH"
SNIP=$(awk '/^LOCK="\$\{RIFFLE_CYCLE_LOCK/{on=1} on{print} on && /^fi$/{exit}' "$U")
D=$(mktemp -d); chmod 755 $D; mkdir -p $D/lib; chmod 700 $D/lib; touch $D/lib/cycle.lock
cat > $D/deploy.sh <<EOF
set -euo pipefail
$SNIP
echo "  proceeded"
sleep 2
EOF
export RIFFLE_CYCLE_LOCK=$D/lib/cycle.lock RIFFLE_SELF=$D/deploy.sh RIFFLE_LOCK_WAIT=2
if grep -q 'sudo test -e' "$U"; then
  echo "[new] while a cycle holds the lock:"
  python3 -c "import fcntl,time; f=open('$D/lib/cycle.lock'); fcntl.flock(f, fcntl.LOCK_EX); time.sleep(4)" & H=$!; sleep 0.5
  bash $D/deploy.sh 2>&1 | sed 's/^/  /'; wait $H
  echo "[new] when no cycle is running:"
  bash $D/deploy.sh 2>&1 | sed 's/^/  /' & P=$!; sleep 1
  python3 -c "import fcntl; f=open('$D/lib/cycle.lock'); fcntl.flock(f, fcntl.LOCK_EX|fcntl.LOCK_NB)" 2>/dev/null && echo "    | a cycle COULD start during the deploy" || echo "    | a cycle cannot start during the deploy"
  wait $P; sleep 1.5
  python3 -c "import fcntl; f=open('$D/lib/cycle.lock'); fcntl.flock(f, fcntl.LOCK_EX|fcntl.LOCK_NB)" 2>/dev/null && echo "    | after the deploy ended, the lock is free again" || echo "    | after the deploy ended, the lock is STILL HELD"
  echo "[new] with no lock file:"; rm $D/lib/cycle.lock
  bash $D/deploy.sh 2>&1 | sed 's/^/  /'; [ -e $D/lib/cycle.lock ] && echo "    | a lock file was CREATED" || echo "    | no lock file was created"
elif [ "$(id -u)" != 0 ]; then
  echo "  (this update.sh has no sudo lock; showing it skip the lock needs root)"
else
  chown -R root:root $D/lib
  echo "[old] run as an unprivileged user, the lock in a 700 directory:"
  su nobody -s /bin/bash -c "RIFFLE_CYCLE_LOCK=$D/lib/cycle.lock bash $D/deploy.sh" 2>&1 | sed 's/^/  /'
fi
