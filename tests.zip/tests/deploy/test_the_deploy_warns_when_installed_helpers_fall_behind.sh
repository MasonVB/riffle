#!/bin/bash
# ==========================================================================
# update.sh says so when a hand-installed helper (the signer, reader or
# build helper, or the signer's libraries) is behind the repository's copy
# or missing.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   With every installed copy current: no warning. With the signer older
#   than the repo's and its libraries missing: a warning naming both,
#   and how to reinstall.
#
# WHY IT EXISTS
#   The earlier review: these helpers are installed by hand, outside the
#   checkout (they hold the key or run as other users), so a deploy
#   could leave them silently stale.
#
# HOW IT WORKS
#   Extracts the check from update.sh and runs it against a temporary
#   install root.
#
# READING THE OUTPUT
#   `### all current` and `### signer behind, libs missing`, each with
#   the step's output and exit code.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-24  Written in the sandbox (tdrift.sh) during the earlier review.
#               It made the 'behind' copy with `git show HEAD:bin/riffle-
#               sign`, which only differed because the sandbox's HEAD was
#               older than the files.
#   2026-11-05  Moved into tests/deploy. The 'behind' copy is now the tree's
#               own signer with one line changed, which differs in any
#               checkout.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
# --- skip cleanly when something this test needs is missing ---
git -C "${RIFFLE_TREE:-.}" rev-parse >/dev/null 2>&1 || { echo "  SKIPPED: needs a git checkout"; exit 0; }
# ---------------------------------------------------------------
cd "$RIFFLE_TREE"
R=$(mktemp -d); mkdir -p $R/usr/local/bin $R/usr/local/lib/riffle-signer
awk '/^# --- hand-installed copies that have fallen behind/{on=1} /^sudo systemctl restart riffle-dash/{exit} on' update.sh > $R/step.sh
echo "### all current"; for f in riffle-sign riffle-reader riffle-build; do cp bin/$f $R/usr/local/bin/; done; cp keyutil.py ed25519_pure.py $R/usr/local/lib/riffle-signer/
RIFFLE_INSTALL_ROOT=$R bash -eu $R/step.sh; echo "  (exit $?)"
echo "### signer behind, libs missing"; { cat bin/riffle-sign; echo "# an older copy"; } > $R/usr/local/bin/riffle-sign; rm $R/usr/local/lib/riffle-signer/*
RIFFLE_INSTALL_ROOT=$R bash -eu $R/step.sh; echo "  (exit $?)"
