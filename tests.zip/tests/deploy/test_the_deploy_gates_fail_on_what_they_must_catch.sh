#!/bin/bash
# ==========================================================================
# update.sh's changed gates each fail on a case they must catch: gate 5 on
# a schema the composer refuses, gate 6 on a unit limit below the worst
# path or a changed wait, gate 8 on a protected header that is only
# mentioned, gate 9 on an unreadable config.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Gate 5: accepted, refused (GRAMMAR RISK), and the composer down
#   (falls back). Gate 6: the unit as shipped (passes), at 10,800 s
#   (fails, listing the waits), and with a timeout line changed (fails).
#   Gate 8: a header only mentioned (ORPHAN). Gate 9: no
#   config.example.yaml (fails).
#
# WHY IT EXISTS
#   L21 (audit round 1): before it, all five failing cases passed. A
#   gate that has never been seen to fail proves nothing; this is also
#   how my own H6 tables were found to have blinded gate 8.
#
# HOW IT WORKS
#   Edits the tree to make each gate fail, runs the gate as update.sh
#   does, and restores the file. It must run on a COPY of the tree,
#   which tests/run_all.sh guarantees. Gate 5 talks to the fake composer
#   in tests/lib on loopback ports 18099 and 18098.
#
# READING THE OUTPUT
#   One line per case with the gate's verdict.
#
# RUNNING IT ON ITS OWN
#   tests/deploy/test_the_deploy_gates_fail_on_what_they_must_catch.sh
#   update.sh (on a copy of the tree only)
#
# CHANGELOG
#   2026-10-31  Written in the sandbox (tgates.sh) for L21.
#   2026-11-04  Its 'unit at 10800' case rewrote only `TimeoutStartSec=18000`;
#               when the units moved to 21,600 the case silently stopped
#               testing anything. The rewrite now matches any value.
#   2026-11-05  Moved into tests/deploy; uses the fake composer and gate
#               runner in tests/lib, and keeps its backups in $RIFFLE_TMP.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
# The changed gates, each against cases it must pass and cases it must fail.
cd "$RIFFLE_TREE"
U=${1:-update.sh}
cfgwith() { python3 -c "import yaml,sys; c=yaml.safe_load(open('config.example.yaml')); c['llm']['composer']['url']=sys.argv[1]; yaml.safe_dump(c, open('config.yaml','w'))" "$1"; }
echo "== gate 5 (schema), by what the running composer says"
for m in accept refuse; do
  python3 "$RIFFLE_TESTS/lib/fake_composer_for_schema_gate.py" $m 18099 & P=$!; sleep 0.6
  cfgwith http://127.0.0.1:18099; printf "  composer %-7s: " $m; "$RIFFLE_TESTS/lib/run_one_update_sh_gate.sh" $U PYGBNF 2>&1 | grep -E "composer|GRAMMAR|gate" | tr '\n' ' '; echo
  kill $P; wait $P 2>/dev/null
done
cfgwith http://127.0.0.1:18098; printf "  composer down   : "; "$RIFFLE_TESTS/lib/run_one_update_sh_gate.sh" $U PYGBNF 2>&1 | grep -E "composer|gate" | tr '\n' ' '; echo
echo "== gate 6 (waits)"
cp config.example.yaml config.yaml
printf "  unit as shipped : "; "$RIFFLE_TESTS/lib/run_one_update_sh_gate.sh" $U PYWAIT 2>&1 | grep -E "allows|gate" | tr '\n' ' '; echo
cp systemd/riffle-cycle.service "$RIFFLE_TMP/unit.bak"; sed -i "s/^TimeoutStartSec=[0-9]*/TimeoutStartSec=10800/" systemd/riffle-cycle.service
printf "  unit at 10800   : "; "$RIFFLE_TESTS/lib/run_one_update_sh_gate.sh" $U PYWAIT 2>&1 | grep -E "allows|TIMEOUT|gate" | head -2 | tr '\n' ' '; echo
cp "$RIFFLE_TMP/unit.bak" systemd/riffle-cycle.service
cp agent/client.py "$RIFFLE_TMP/client.bak"; sed -i 's/token=None, timeout=45):/token=None, timeout=90):/' agent/client.py
printf "  a wait changed  : "; "$RIFFLE_TESTS/lib/run_one_update_sh_gate.sh" $U PYWAIT 2>&1 | grep -E "no longer|gate" | head -2 | tr '\n' ' '; echo
cp "$RIFFLE_TMP/client.bak" agent/client.py
echo "== gate 8 (protected headers at the start)"
cp agent/cycle.py "$RIFFLE_TMP/cycle.bak"
python3 - <<'EOF'
p="agent/cycle.py"; s=open(p).read()
old='"WHAT CAN STOP AN ACTION'
i=[k for k in range(len(s)) if s.startswith(old, k)]
# make every literal that STARTS with the header merely mention it instead
s=s.replace('parts.append(\n            "WHAT CAN STOP AN ACTION', 'parts.append(\n            "Note: WHAT CAN STOP AN ACTION', 1) if 'parts.append(\n            "WHAT CAN STOP AN ACTION' in s else s.replace('"WHAT CAN STOP AN ACTION:', '"Note: WHAT CAN STOP AN ACTION:', 1)
open(p,"w").write(s)
EOF
printf "  header only mentioned: "; "$RIFFLE_TESTS/lib/run_one_update_sh_gate.sh" $U PYTRIM 2>&1 | grep -E "no string literal|gate" | head -2 | cut -c1-120 | tr '\n' ' '; echo
cp "$RIFFLE_TMP/cycle.bak" agent/cycle.py
echo "== gate 9 (config unreadable)"
mv config.example.yaml "$RIFFLE_TMP/cfgex.bak"; printf "  no config.example.yaml: "; "$RIFFLE_TESTS/lib/run_one_update_sh_gate.sh" $U PYCFG 2>&1 | grep -E "could not|gate" | tr '\n' ' '; echo; mv "$RIFFLE_TMP/cfgex.bak" config.example.yaml
cp config.example.yaml config.yaml   # as the runner left it
