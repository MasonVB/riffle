#!/bin/bash
# ==========================================================================
# Each of update.sh's gates that had never been seen to fail is shown
# failing on the fault it exists to catch: PY, PYRENDER, PYFIT, PYREC,
# PYROW, PYSTRAY, PYENUM and PYOUT.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For each gate, that a planted fault of exactly the kind its comment
#   names makes it fail, and that it passes again once the fault is removed:
#     PY        a module under agent/ that raises when imported
#     PYRENDER  the home page raising a NameError while it is built (the
#               gate's own origin: hashlib, misnamed, inside do_GET)
#     PYFIT     a prompt ceiling the composer's window cannot hold
#     PYREC     a function whose whole body is `return itself(...)`
#     PYROW     `(project.active(state) or {}).get("id")`, the bug the gate
#               was written for
#     PYSTRAY   an agent module's name dropped at the repository root
#     PYENUM    the schema's enum for attestation.cls missing a value
#     PYOUT     an apply_* handler writing an outcome in neither list
#
# WHY IT EXISTS
#   A gate that has never been seen to fail may be passing everything. In
#   audit round 1, gate 8 had been blinded by tables of my own that began with
#   header names, and only a must-fail case showed it. Gates 5, 6, 8 and 9
#   got must-fail cases then (test_the_deploy_gates_fail_on_what_they_must_
#   catch.sh); these eight never had one.
#
# HOW IT WORKS
#   On the runner's COPY of the tree only: for each gate, save the file it
#   will break, plant the fault, run the gate as update.sh does
#   (tests/lib/run_one_update_sh_gate.sh), restore the file, and run the
#   gate again to show the restore worked.
#
# READING THE OUTPUT
#   One line per gate: `GATE  with the fault: GATE FAILED ... | restored:
#   gate passed`. "gate passed" with the fault in place is the failure: that
#   gate cannot see what it is for.
#
# RUNNING IT ON ITS OWN
#   Through tests/run_all.sh only: it edits files, and must have a copy.
#
# CHANGELOG
#   2026-11-06  Written after audit round 3, to close the remaining item of
#               "gates with no must-fail case" on the open list since round 1.
#               It found a real hole: PYREC checked seven named files, so its
#               planted self-call in notify.py passed; the gate now checks
#               every file. Its first PYSTRAY case was wrong: the gate checks
#               tracked files, and the planted copy was never added to git.
# ==========================================================================
# --- run only through tests/run_all.sh, and never as one of riffle's accounts ---
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
# -------------------------------------------------------------------------------
cd "$RIFFLE_TREE"
GATE="$RIFFLE_TESTS/lib/run_one_update_sh_gate.sh"
verdict() { PYTHONPATH= bash "$GATE" update.sh "$1" 2>&1 | tail -1 | sed 's/=> //'; }

check() {   # $1 gate, $2 file the fault goes in, $3 python that plants it
  local gate=$1 file=$2 plant=$3 created=0
  [ -e "$file" ] && cp "$file" "$RIFFLE_TMP/backup" || created=1
  FILE="$file" python3 -c "$plant"
  local bad; bad=$(verdict "$gate")
  if [ $created = 1 ]; then git rm -q --cached --ignore-unmatch "$file"; rm -f "$file"
  else cp "$RIFFLE_TMP/backup" "$file"; fi
  printf "  %-9s with the fault: %-42s | restored: %s\n" "$gate" "${bad:0:42}" "$(verdict "$gate")"
}

A='import os; f=os.environ["FILE"]; s=open(f).read()'
check PY       agent/notify.py  "$A; open(f,'w').write(s + '\nraise RuntimeError(\"planted: fails at import\")\n')"
check PYRENDER agent/dash.py    "$A; assert s.count('hashlib.sha256(PAGE.encode())')==1; open(f,'w').write(s.replace('hashlib.sha256(PAGE.encode())', 'hashlibx.sha256(PAGE.encode())'))"
check PYFIT    config.yaml      "$A; import yaml; c=yaml.safe_load(s); c.setdefault('cycle',{})['max_prompt_chars']=90000; open(f,'w').write(yaml.safe_dump(c))"
check PYREC    agent/notify.py  "$A; open(f,'w').write(s + '\n\ndef _planted(x):\n    return _planted(x)\n')"
check PYROW    agent/notify.py  "$A; open(f,'w').write(s + '\n\ndef _planted_row(state):\n    return (project.active(state) or {}).get(\"id\")\n')"
# PYSTRAY checks what git tracks: a file the GitHub uploader misplaced is
# committed by the time update.sh runs, so the planted one is added to git.
if ! git rev-parse >/dev/null 2>&1; then
  echo "  PYSTRAY   skipped: this tree is not a git checkout, and the gate reads what git tracks"
else
check PYSTRAY  cycle.py         "import shutil, subprocess; shutil.copy('agent/cycle.py', 'cycle.py'); subprocess.run(['git', 'add', 'cycle.py'], check=True)"
fi
check PYENUM   proposal_schema.json "$A; import json; d=json.loads(s); b=[x for x in d['oneOf'] if x['properties']['action'].get('const')=='attestation'][0]; e=b['properties']['payload']['properties']['cls']['enum']; e.remove(e[-1]); open(f,'w').write(json.dumps(d, indent=1))"
check PYOUT    agent/cycle.py   "$A; i=s.index('\ndef apply_ask(state, cid, p, drive, log):\n')+len('\ndef apply_ask(state, cid, p, drive, log):\n'); open(f,'w').write(s[:i] + '    if False:\n        state.end_cycle(cid, \"planted-unlisted-outcome\")\n' + s[i:])"
