#!/usr/bin/env python3
"""CHECK A TREE AGAINST THE REVIEWED EXPECTED OUTPUT, TEST BY TEST.

usage:  python3 tests/check_against_expected.py [TREE]   check (default: the tree tests/ sits in)
        python3 tests/check_against_expected.py --record  re-record the expected
                                                     output (read below first)

Runs tests/run_all.sh on TREE, normalises the output, splits it into tests,
and compares each test with tests/expected_output.txt. Each test is one of:
  ok        identical to the reviewed output;
  SKIPPED   it printed SKIPPED (a tool it needs is missing here: node, the
            registry extract, openssl, pyflakes); not a failure, but not a
            check either: the reason is printed;
  DIFFERS   its output changed: the differing lines are printed. A difference
            is not automatically a bug, but it must be explained;
  NEW       the test has no reviewed output yet.
Exit status 0 when nothing DIFFERS, 1 otherwise.

WHY THIS EXISTS. Comparing two versions of riffle (compare_two_versions.sh)
shows what CHANGED between them, and is blind to a check that is wrong in
both. Two such checks went unnoticed in the sandbox: the TLS test's
certificates expired on 2026-11-01 and its "right certificate" case failed
from then on, and the squeeze test reported a WRONG on every run. The
expected output is a run that was read line by line and judged correct; a
check that starts failing shows up here the day it happens.

RE-RECORDING. --record writes the current run as the new expected output.
Only do it after reading every line of `git diff tests/expected_output.txt`
and being able to say why each change is right. Recording output you have
not read turns this into the blind comparison it exists to replace.

Two tests print their two answers in whichever order the threads finish
(the approval race and cap tests); those lists are sorted before comparing.

CHANGELOG
  2026-11-05  Written when the suite was packaged, after the two unnoticed
              failures above were found.
"""
import ast
import difflib
import os
import re
import subprocess
import sys

TESTS = os.path.dirname(os.path.abspath(__file__))
EXPECTED = os.path.join(TESTS, "expected_output.txt")


def run(tree):
    raw = subprocess.run(["bash", os.path.join(TESTS, "run_all.sh"), tree],
                         capture_output=True, text=True).stdout
    return subprocess.run(["bash", os.path.join(TESTS, "normalise_output.sh")],
                          input=raw, capture_output=True, text=True).stdout


def split(text):
    out, name = {}, None
    for line in text.splitlines():
        if line.startswith("@@@ test: "):
            name = line[len("@@@ test: "):].strip()
            out[name] = []
        elif name is not None:
            out[name].append(line)
    return out


def canonical(line):
    m = re.search(r"answers: (\[.*\])", line)
    if m:
        try:
            line = line[:m.start(1)] + repr(sorted(ast.literal_eval(m.group(1)))) + line[m.end(1):]
        except (ValueError, SyntaxError):
            pass
    return line


def main():
    args = sys.argv[1:]
    record = "--record" in args
    args = [a for a in args if a != "--record"]
    tree = os.path.abspath(args[0]) if args else os.path.dirname(TESTS)
    if not os.path.isfile(os.path.join(tree, "agent", "cycle.py")):
        print(f"{tree} is not a riffle tree. Name the tree to check, e.g.\n"
              f"  python3 {os.path.relpath(__file__)} /opt/riffle", file=sys.stderr)
        return 2
    print(f"running the suite on {tree} ...", file=sys.stderr)
    text = run(tree)
    if record:
        with open(EXPECTED, "w") as f:
            f.write(text)
        print(f"recorded {len(split(text))} tests to {EXPECTED}. Now read "
              f"`git diff tests/expected_output.txt` line by line.")
        return 0
    want = split(open(EXPECTED).read()) if os.path.exists(EXPECTED) else {}
    got = split(text)
    counts = {"ok": 0, "SKIPPED": 0, "DIFFERS": 0, "NEW": 0}
    for name, lines in got.items():
        if any("SKIPPED" in x for x in lines):
            counts["SKIPPED"] += 1
            reason = next(x for x in lines if "SKIPPED" in x).strip()
            print(f"SKIPPED  {name}: {reason}")
        elif name not in want:
            counts["NEW"] += 1
            print(f"NEW      {name}")
        elif [canonical(x) for x in lines] == [canonical(x) for x in want[name]]:
            counts["ok"] += 1
        else:
            counts["DIFFERS"] += 1
            print(f"DIFFERS  {name}")
            for d in difflib.unified_diff([canonical(x) for x in want[name]],
                                          [canonical(x) for x in lines],
                                          "expected", "this run", lineterm="", n=0):
                if not d.startswith(("---", "+++", "@@")):
                    print("         " + d[:170])
    gone = [n for n in want if n not in got]
    for n in gone:
        print(f"GONE     {n} (in the expected output, not run)")
    print(f"\n{counts['ok']} ok, {counts['SKIPPED']} skipped, {counts['DIFFERS']} differ, "
          f"{counts['NEW']} new, {len(gone)} gone, of {len(got)} tests run")
    return 1 if counts["DIFFERS"] or gone else 0


if __name__ == "__main__":
    sys.exit(main())
