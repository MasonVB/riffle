#!/bin/bash
# RUN THE WHOLE SUITE ON TWO VERSIONS OF RIFFLE AND SHOW WHAT CHANGED.
#
# usage:  bash tests/compare_two_versions.sh <before> <after>
#   Each side is a git ref (a commit, a branch, HEAD, origin/master) or the
#   word WORKTREE for the files as they are now, uncommitted changes and all.
#   Example, before deploying what you are about to commit:
#       bash tests/compare_two_versions.sh HEAD WORKTREE
#
# This is how every fix in the audits was checked: the same tests, run on the
# code before and after, with every differing line explained before the
# change was handed over. A difference is not a failure; an UNEXPLAINED
# difference is. The suite used is always this tests/ directory, so an older
# version is checked with today's tests.
#
# CHANGELOG
#   2026-10-23  Started in the sandbox as abcompare.sh (stash, run, unstash,
#               run, diff).
#   2026-11-05  Rewritten for tests/: compares any two refs, each extracted to
#               a temporary directory, without touching your checkout.
set -uo pipefail
TESTS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(cd "$TESTS/.." && pwd)"
[ $# -eq 2 ] || { sed -n '2,8p' "$0"; exit 2; }
W="$(mktemp -d -t riffle-compare.XXXXXX)"; trap 'rm -rf "$W"' EXIT
side() {   # $1 = ref or WORKTREE, $2 = label
  if [ "$1" = WORKTREE ]; then echo "$REPO"; return; fi
  mkdir -p "$W/$2"; git -C "$REPO" archive "$1" | tar -x -C "$W/$2"
  git -C "$REPO" rev-parse --verify -q "$1" >/dev/null || { echo "no such ref: $1" >&2; exit 2; }
  # the git-based tests need a repository: give the extract one, at that ref
  ( cd "$W/$2" && git init -q && git add -A && git -c user.email=t@t -c user.name=t commit -qm "$1" )
  echo "$W/$2"
}
A="$(side "$1" before)"; B="$(side "$2" after)"
echo "running the suite on $1 ..." >&2;  bash "$TESTS/run_all.sh" "$A" | bash "$TESTS/normalise_output.sh" > "$W/before.txt"
echo "running the suite on $2 ..." >&2;  bash "$TESTS/run_all.sh" "$B" | bash "$TESTS/normalise_output.sh" > "$W/after.txt"
echo "$(wc -l < "$W/before.txt") lines before, $(wc -l < "$W/after.txt") after. Differences (none = no behaviour change):"
diff "$W/before.txt" "$W/after.txt" && echo "(none)"
