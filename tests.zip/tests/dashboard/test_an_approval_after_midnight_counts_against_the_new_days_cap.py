# ==========================================================================
# An approval made just after midnight UTC is counted against the new
# day's cap, not the day of the last cycle.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   What decide() answers when yesterday's single comment is spent and
#   nothing has been used today.
#
# WHY IT EXISTS
#   The earlier review: the dashboard used the server day stored by the
#   last cycle, so after midnight it refused approvals against
#   yesterday's spent cap.
#
# HOW IT WORKS
#   Sets the stored server day to yesterday with its cap spent, then
#   approves a queued comment.
#
# READING THE OUTPUT
#   `decide -> {...}`: accepted.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-23  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, datetime as dt; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import dash
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
today = dt.datetime.now(dt.timezone.utc).date()
yday = (today - dt.timedelta(days=1)).isoformat()
st.note("server_day", yday)            # last cycle ran before midnight
st.cap_bump(yday, "comment")           # yesterday's single comment is spent
st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
              " VALUES (1,?,?,?,?,?,?)", (today.isoformat() + "T00:30:00Z", "comment", "answer",
              json.dumps({"post_id": 5, "parent_id": 9, "body": "A reply about the numbers."}), "r", "queued"))
st.db.commit()
dash.Handler.state = st
dash.Handler.cfg = {"caps": {"comment": 1}, "dash": {}, "base": "http://x"}
class NoThread:
    def __init__(self, *a, **k): pass
    def start(self): pass
dash._th.Thread = NoThread
h = object.__new__(dash.Handler)
print("  decide ->", h.decide(1, "approve"))
