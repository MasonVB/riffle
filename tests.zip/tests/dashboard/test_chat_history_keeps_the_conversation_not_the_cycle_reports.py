# ==========================================================================
# The chat's history for the model keeps the operator's and riffle's
# conversation and leaves out the stream of cycle reports.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   How many turns the history has, and whether it holds the user's
#   message, riffle's answer and riffle's question, but no 'witness
#   pass' reports.
#
# WHY IT EXISTS
#   The earlier review: the last ten messages were mostly cycle reports,
#   which pushed the conversation itself out of the model's view.
#
# HOW IT WORKS
#   Writes a short conversation followed by twelve reports and an error,
#   then builds the history.
#
# READING THE OUTPUT
#   `N turns; conversation present: user=True, agent=True,
#   question=True, reports=0`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-23  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import chat
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
st.say("question", "Should I keep the detector post on queue?")
st.say("user", "Yes, keep it queued. Why did the vote fail yesterday?")
st.say("agent", "It was refused: you had already voted on that post.")
for i in range(12):
    st.say("report", f"Cycle {100+i} · witness pass, nothing moved.")
st.say("error", "Cycle 113 failed to produce a proposal")
mid = st.say("agent", "", done=False)
if hasattr(chat, "_history"):
    h = chat._history(st, mid)
else:   # the original inline loop, verbatim
    h = []
    for m in st.tail(10):
        if m["id"] == mid: continue
        if m["role"] == "user": h.append({"role": "user", "content": m["content"][:4000]})
        elif m["role"] in ("agent", "report") and m["content"].strip():
            h.append({"role": "assistant", "content": m["content"][:4000]})
print(f"  {len(h)} turns; conversation present: user={any('keep it queued' in x['content'] for x in h)}, "
      f"agent={any('already voted' in x['content'] for x in h)}, question={any('detector post' in x['content'] for x in h)}, "
      f"reports={sum('witness pass' in x['content'] for x in h)}")
