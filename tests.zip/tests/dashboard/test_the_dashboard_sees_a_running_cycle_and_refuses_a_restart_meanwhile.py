# ==========================================================================
# The dashboard notices a cycle that is really running (a live `python -m
# agent.cycle` process) and refuses to restart the composer meanwhile;
# once it exits, a restart is allowed.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   While a fake cycle process runs: seen True, restart refused True;
#   after it exits: seen False, refused False.
#
# WHY IT EXISTS
#   M11 (audit round 1): the dashboard trusted a flag that could be
#   stale, so it could restart the composer under a running cycle.
#
# HOW IT WORKS
#   Starts a process that looks like a cycle (a fake agent/cycle.py that
#   sleeps) in $RIFFLE_TMP/fakecycle, checks, kills it, checks again.
#
# READING THE OUTPUT
#   One line with both states.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm11.py) for M11, against a fake cycle
#               made by hand in /tmp/fakecycle and never written down.
#   2026-11-05  Moved into tests/dashboard; builds its fake cycle itself, in
#               $RIFFLE_TMP.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, subprocess, time; sys.path.insert(0, sys.argv[1])
from agent import dash
has = hasattr(dash, "cycle_running")
class W:  busy = False; depth = staticmethod(lambda: 0)
class H(dash.Handler):
    worker = W(); _restarting = False
h = H.__new__(H)
def guard():
    r = dash.Handler.restart_model.__wrapped__(h) if hasattr(dash.Handler.restart_model, "__wrapped__") else None
    return r
_fc = __import__("os").environ["RIFFLE_TMP"] + "/fakecycle"
__import__("os").makedirs(_fc + "/agent", exist_ok=True)
open(_fc + "/agent/__init__.py", "w").close()
open(_fc + "/agent/cycle.py", "w").write("import time; time.sleep(30)\n")
p = subprocess.Popen([sys.executable, "-m", "agent.cycle"], cwd=_fc); time.sleep(0.5)
during = dash.cycle_running() if has else "(no check)"
# the restart guard's own condition, as the code evaluates it
cond_during = (getattr(H.worker, "busy", False) or H.worker.depth() > 0 or (dash.cycle_running() if has else H._cycle_running))
p.kill(); p.wait(); time.sleep(0.2)
after = dash.cycle_running() if has else "(no check)"
cond_after = (getattr(H.worker, "busy", False) or H.worker.depth() > 0 or (dash.cycle_running() if has else H._cycle_running))
print(f"  while a cycle runs: seen={during}, restart refused={bool(cond_during)} | after it exits: seen={after}, restart refused={bool(cond_after)}")
