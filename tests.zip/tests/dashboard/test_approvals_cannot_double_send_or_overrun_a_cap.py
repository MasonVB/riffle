# ==========================================================================
# Approving on the dashboard: two devices approving the same action send
# it once; two approvals together cannot overrun a cap; the porch's
# default cap applies.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: `race` (the same comment approved twice
#   at once: one send, the second told 'not queued'), `cap` (two
#   comments under a cap of 1: one sent, one refused), `porch` (a fourth
#   porch line with the default cap of 3: refused).
#
# WHY IT EXISTS
#   L10 (audit round 1): decide() read the status and wrote it later, so
#   two approvals could both pass; the daily cap counted a send only
#   after it finished; and the porch's default cap was not applied on
#   the dashboard's path.
#
# HOW IT WORKS
#   Calls the dashboard's decide() from two threads at once, with delays
#   that force them to overlap, and a send that takes 0.6 s.
#
# READING THE OUTPUT
#   `[case] sends to the registry: N | answers: [...]` (the order of the
#   two answers can vary).
#
# RUNNING IT ON ITS OWN
#   python3 tests/dashboard/test_approvals_cannot_double_send_or_overrun
#   _a_cap.py . race
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl10.py) for L10.
#   2026-11-05  Moved into tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, threading, time, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import dash, cycle as cycle_mod
from agent.state import State, utcnow
sends = []
def fake_execute(writer, kind, p):
    sends.append((kind, p.get("body") or p.get("text")))
    time.sleep(0.6)
    return {"comment_id": 1, "now_utc": utcnow()}
dash.execute = fake_execute
class W:
    def __init__(self, *a, **k): pass
dash.Writer = W
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cfg["caps"].pop("porch", None)
if mode == "cap": cfg["caps"]["comment"] = 1
st = State(os.path.join(d, "s.sqlite"))
class H(dash.Handler):
    pass
H.state, H.cfg = st, cfg
h = H.__new__(H)
h._update_card = lambda *a, **k: None
h._local_time = lambda: "now"
h.run_cycle = lambda *a, **k: None
if mode == "race":            # widen the read-then-write window the bug lives in
    real_nd = cycle_mod.near_duplicate
    def slow_nd(*a, **k):
        time.sleep(0.3); return real_nd(*a, **k)
    cycle_mod.near_duplicate = slow_nd
def queue(kind, payload):
    return st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,?,'answer',?,'r','queued')",
                         (utcnow(), kind, json.dumps(payload))).lastrowid
if mode == "race":
    a1 = queue("comment", {"post_id": 4, "parent_id": 2, "body": "The receipts settle in order only within one batch."}); ids = [a1, a1]
elif mode == "cap":
    ids = [queue("comment", {"post_id": 4, "parent_id": 2, "body": "First answer about the receipts and their ordering."}),
           queue("comment", {"post_id": 5, "parent_id": 3, "body": "A different answer about tags and their meaning."})]
else:
    for _ in range(3): st.cap_bump(utcnow()[:10], "porch")
    ids = [queue("porch", {"text": "Good morning, square."})]
st.db.commit()
res = [None] * len(ids)
def go(i):
    res[i] = h.decide(ids[i], "approve")
ts = [threading.Thread(target=go, args=(i,)) for i in range(len(ids))]
[t.start() for t in ts]; [t.join() for t in ts]
time.sleep(1.2)
print(f"  [{mode:5}] sends to the registry: {len(sends)} | answers: {[r.get('error') or r.get('status') for r in res]}")
