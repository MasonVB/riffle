# ==========================================================================
# In a chat turn, the operator's question is sent to the model once, with
# the earlier turns kept.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   How many times the question appears in what the model received (1),
#   and that earlier turns are present.
#
# WHY IT EXISTS
#   M15 (audit round 1): the question was sent twice per turn, once in
#   the history and once as the new message.
#
# HOW IT WORKS
#   Runs a chat answer with a stub model that records its messages.
#
# READING THE OUTPUT
#   `the question appears 1 time(s); earlier turns kept: True`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm15.py) for M15.
#   2026-11-05  Moved into tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import chat
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = tempfile.mkdtemp()
st = State(os.path.join(cfg["data_dir"], "state.sqlite"))
st.say("user", "What did the registry say about my last post?")
st.say("agent", "It accepted it; post #9901.")
Q = "Why did the vote on #9823 fail yesterday?"
st.say("user", Q)                                    # saved by /api/send before the worker runs
seen = {}
def fake_stream(llm_cfg, messages, on_delta, timeout=2400, meta=None):
    seen["msgs"] = messages; on_delta("It was your own post."); return "It was your own post."
chat.stream_completion = fake_stream
chat.build_record = lambda *a, **k: {}
class R:
    def __init__(self, *a, **k): pass
chat.Reader = R
chat.memory.recall = lambda *a, **k: []
try: chat.answer(st, cfg, Q, "2026-10-29")
except Exception as e: print("  answer raised:", type(e).__name__, e)
m = [x for x in seen.get("msgs", []) if x["role"] != "system"]
print(f"  the question appears {sum(x['content'] == Q for x in m)} time(s); earlier turns kept: "
      f"{any('last post' in x['content'] for x in m)} and {any('#9901' in x['content'] for x in m)}; turns: {[x['role'] for x in m]}")
