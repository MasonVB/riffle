# ==========================================================================
# The dashboard's 'dismiss' and 'answer' buttons check the server's reply:
# a refused dismissal brings the card back, and a failed answer offers to
# try again.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Against a server that refuses with {"error": ...} and HTTP 200: the
#   card is shown again with 'could not dismiss this; try again', and
#   the button is re-enabled as 'not sent — try again'.
#
# WHY IT EXISTS
#   T3 (audit round 1): both buttons fired the request and ignored the
#   answer, so a refusal looked like success, or 'sending…' stayed
#   forever.
#
# HOW IT WORKS
#   Extracts both functions from the page as the dashboard serves it,
#   and runs them in node with a stand-in page element and server.
#
# READING THE OUTPUT
#   Two lines with the card's and the button's state.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-31  Written in the sandbox (tt3.py) for T3.
#   2026-11-05  Moved into tests/dashboard; skips without node.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
# --- skip cleanly when something this test needs is missing ---
if not __import__("shutil").which("node"):
    print("  SKIPPED: needs node (version 22 or later) on PATH"); raise SystemExit(0)
# ---------------------------------------------------------------
import sys, re, json, subprocess; sys.path.insert(0, sys.argv[1])
import agent.pages as pages
js = next(v for v in vars(pages).values() if isinstance(v, str) and "async function dropCard" in v)
def grab(name):
    i = js.index(f"async function {name}("); depth = 0
    for j in range(js.index("{", i), len(js)):
        depth += js[j] == "{"; depth -= js[j] == "}"
        if depth == 0: return js[i:j + 1]
test = r'''
const el = {style: {display: ''}, extra: '', insertAdjacentHTML(_, h){ this.extra += h; }, value: 'my answer', focus(){}};
global.document = {getElementById: () => el};
const btn = {disabled: false, textContent: 'send'};
global.fetch = async () => ({ok: true, json: async () => ({error: 'no such action'})});
''' + grab("dropCard") + "\n" + grab("sendAnswer") + r'''
(async () => {
  await dropCard({stopPropagation(){}}, 1, 99);
  console.log("  refused dismiss: card shown again: " + (el.style.display !== 'none') + ", note: " + JSON.stringify(el.extra));
  await sendAnswer(5, btn);
  console.log("  refused answer: button re-enabled: " + !btn.disabled + ", label: " + JSON.stringify(btn.textContent));
})();
'''
JS = __import__("os").environ["RIFFLE_TMP"] + "/tt3.js"
open(JS, "w").write(test)
print(subprocess.run(["node", JS], capture_output=True, text=True).stdout.rstrip() or subprocess.run(["node", JS], capture_output=True, text=True).stderr[:300])
