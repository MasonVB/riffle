# ==========================================================================
# An approval is refused when today's cap is already spent, and when the
# server's day is ahead and that day's cap is spent.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks `spent` or `ahead`; each prints decide()'s answer.
#
# WHY IT EXISTS
#   The counterpart of the midnight test: the fix must not let approvals
#   through when the cap really is spent.
#
# HOW IT WORKS
#   As the midnight test, with today's (or tomorrow's) cap spent.
#
# READING THE OUTPUT
#   `spent: decide -> {...'used up'...}`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/dashboard/test_an_approval_is_refused_when_todays_cap_
#   is_spent_or_the_server_is_ahead.py . spent
#
# CHANGELOG
#   2026-10-23  Generated in the sandbox as /tmp/h18b.py from h18.py during
#               the earlier review.
#   2026-11-05  Committed as a file in tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, datetime as dt; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import dash
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
today = dt.datetime.now(dt.timezone.utc).date()
yday = (today - dt.timedelta(days=1)).isoformat()
st.note("server_day", yday)            # last cycle ran before midnight
st.cap_bump(yday, "comment")           # yesterday's single comment is spent
st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
              " VALUES (1,?,?,?,?,?,?)", (today.isoformat() + "T00:30:00Z", "comment", "answer",
              json.dumps({"post_id": 5, "parent_id": 9, "body": "A reply about the numbers."}), "r", "queued"))
st.db.commit()
dash.Handler.state = st
dash.Handler.cfg = {"caps": {"comment": 1}, "dash": {}, "base": "http://x"}
class NoThread:
    def __init__(self, *a, **k): pass
    def start(self): pass
dash._th.Thread = NoThread
h = object.__new__(dash.Handler)
import sys as _s
mode=_s.argv[2]
if mode=="spent": st.cap_bump(today.isoformat(), "comment")
if mode=="ahead":
    tmr=(today+dt.timedelta(days=1)).isoformat(); st.note("server_day", tmr); st.cap_bump(tmr, "comment")
print(f"  {mode}: decide ->", h.decide(1, "approve"))
