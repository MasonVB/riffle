# ==========================================================================
# A goal change riffle queues for approval says on its card when it is
# outside riffle's own limits; and the operator's own changes no longer
# use riffle's daily budget.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   An out-of-bounds weight change's card carries 'OUTSIDE RIFFLE'S OWN
#   LIMITS' with each reason; an in-bounds one carries nothing; after
#   the operator moves a weight by the whole daily budget, riffle's own
#   small step is still allowed.
#
# WHY IT EXISTS
#   L10 (an approved change ran as the operator, so riffle's bounds were
#   never shown) and L11 (riffle's budget counted every actor), audit
#   round 1.
#
# HOW IT WORKS
#   Queues two weight changes, then records an operator change and asks
#   for a small agent change.
#
# READING THE OUTPUT
#   Two card lines and the budget line.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl10g.py) for L10 and L11.
#   2026-11-05  Moved into tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml; sys.path.insert(0, sys.argv[1])
from agent import cycle, goals
from agent.state import State, utcnow
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = tempfile.mkdtemp()
cfg["autonomy"]["adjust_drive"] = "queue"
st = State(os.path.join(cfg["data_dir"], "s.sqlite")); goals.seed(st, cfg)
pol = goals.policy(cfg)
name = goals.all_drives(st)[0]["name"]; w0 = goals.all_drives(st)[0]["weight"]
for label, w in (("out of bounds", pol["max_weight"] + 0.2), ("within bounds", round(w0 + min(0.01, pol["max_delta"]), 4))):
    cid = st.begin_cycle("understand")
    cycle.apply_reflexive(st, cfg, cid, "adjust_drive", {"name": name, "weight": w, "reason": "this goal deserves more weight than it has"}, "understand", "rationale here")
    card = st.db.execute("SELECT content FROM messages WHERE role='proposal' ORDER BY id DESC LIMIT 1").fetchone()[0]
    print(f"  {label:13} card warns: {'OUTSIDE' in card} | {card[card.find('OUTSIDE'):][:110] if 'OUTSIDE' in card else ''}")
# L11: you moved the weight today by the whole daily budget; can riffle still move it within its own budget?
st.db.execute("INSERT INTO drive_changes (ts,name,field,old,new,actor,reason) VALUES (?,?,'weight',?,?,'you','operator')", (utcnow(), name, w0, w0 + pol["max_delta_per_day"]))
st.db.commit()
try:
    old, new = goals.set_weight(st, cfg, name, round(w0 + min(0.01, pol["max_delta"]), 4), "agent", "a reason well over twenty characters long")
    print(f"  after YOUR change used the day's budget, riffle's own small step: allowed ({old} -> {new})")
except goals.Rejected as e:
    print(f"  after YOUR change used the day's budget, riffle's own small step: REFUSED ({str(e)[:70]})")
