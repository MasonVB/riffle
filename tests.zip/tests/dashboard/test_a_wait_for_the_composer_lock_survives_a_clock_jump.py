# ==========================================================================
# Waiting for the composer lock lasts its full timeout even when the wall
# clock jumps forward during the wait.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   How long a 2-second wait really waited while time.time() jumped an
#   hour.
#
# WHY IT EXISTS
#   L17 (audit round 1): timers used the wall clock, so a clock
#   correction ended waits early and could fake or hide a stall.
#
# HOW IT WORKS
#   Holds the lock elsewhere, makes time.time() jump, and times the wait
#   with the monotonic clock.
#
# READING THE OUTPUT
#   `waited 2.0s of a 2s timeout while the clock jumped (got lock:
#   False)`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl17.py) for L17.
#   2026-11-05  Moved into tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, time, fcntl, tempfile; sys.path.insert(0, sys.argv[1])
from agent import chat
p = os.path.join(tempfile.mkdtemp(), "composer.lock")
holder = open(p, "a+"); fcntl.flock(holder, fcntl.LOCK_EX)          # someone else holds the lock
real = time.time; calls = [0]
def jumpy():
    calls[0] += 1
    return real() + (3600 if calls[0] > 1 else 0)                    # the clock jumps an hour after the first reading
chat.time.time = jumpy
lock = chat.ComposerLock(p)
t0 = time.monotonic()
got = lock.acquire(blocking=True, timeout=2)
print(f"  waited {time.monotonic() - t0:.1f}s of a 2s timeout while the clock jumped (got lock: {got})")
