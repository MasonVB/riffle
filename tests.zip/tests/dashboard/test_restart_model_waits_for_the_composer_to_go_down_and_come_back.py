# ==========================================================================
# 'Restart model' reports the composer back only after it has really gone
# down and come back, and says so when the restart unit gave up.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: `real` (a real restart: reported back at
#   180 s, after /health failed and recovered) or `gave-up` (the unit
#   waited 15 minutes on a cycle and gave up: reported at 903 s,
#   'Nothing was restarted').
#
# WHY IT EXISTS
#   U10 (audit round 2): it checked /health two seconds after asking, so
#   while the unit still waited on a lock the OLD composer answered and
#   the card said the restart had happened.
#
# HOW IT WORKS
#   Runs restart_model() inline with a fake clock, a fake /health and a
#   fake `systemctl show`. The restart request file, which on the box is
#   the real trigger that restarts the composer, is redirected into
#   $RIFFLE_TMP; the safety net would refuse the real path anyway.
#
# READING THE OUTPUT
#   `[case] at Ns the card said: '...'`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/dashboard/test_restart_model_waits_for_the_composer_to
#   _go_down_and_come_back.py . real
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tu10.py) for U10; it needed an idle
#               chat worker before it could reach the code. It wrote the real
#               request path, /var/lib/riffle/restart-composer.request.
#   2026-11-05  Moved into tests/dashboard. The request file is redirected
#               into $RIFFLE_TMP: on the operator's box, the real path would
#               have restarted the real composer.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile, time, threading, yaml; sys.path.insert(0, sys.argv[1])
from agent import dash
from agent.state import State
mode = sys.argv[2]
clock = [0.0]                                        # a fake clock, advanced by sleeps
time.time = lambda: clock[0]
time.sleep = lambda s: clock.__setitem__(0, clock[0] + s)
REAL_REQ = "/var/lib/riffle/restart-composer.request"   # the real trigger: never written here
REQ = os.environ["RIFFLE_TMP"] + "/restart-composer.request"
import builtins as _bi
_real_open, _real_exists = _bi.open, os.path.exists
def _redirect(p):
    return REQ if os.fspath(p) == REAL_REQ else p
dash.open = lambda p, *a, **k: _real_open(_redirect(p), *a, **k)
os.path.exists = lambda p: _real_exists(_redirect(p))
def health_at(t):
    if mode == "gave-up": return True                # the old composer answers throughout
    return not (60 <= t < 180)                       # real restart: down from 60 s to 180 s
import urllib.request
class R:
    status = 200
    def __enter__(self): return self
    def __exit__(self, *a): pass
def fake_urlopen(url, timeout=None):
    if not health_at(clock[0]): raise OSError("connection refused")
    if mode == "gave-up" and clock[0] > 30 and os.path.exists(REQ): os.remove(REQ)   # the unit took the request
    if mode == "real" and clock[0] > 50 and os.path.exists(REQ): os.remove(REQ)
    return R()
urllib.request.urlopen = fake_urlopen
import subprocess
_real_run = subprocess.run
def fake_run(argv, **k):
    if argv[:2] == ["systemctl", "show"]:
        failed = mode == "gave-up" and clock[0] > 900
        return subprocess.CompletedProcess(argv, 0, "failed\n" if failed else "activating\n", "")
    return _real_run(argv, **k)
subprocess.run = fake_run
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = d
st = State(os.path.join(d, "s.sqlite"))
class H(dash.Handler): pass
H.state, H.cfg = st, cfg
H._restarting = False
h = H.__new__(H)
class _Idle:
    busy = False
    def depth(self): return 0
H.worker = _Idle()
dash.cycle_running = lambda *a, **k: False
real_thread = threading.Thread
class Now:                                           # run the worker inline
    def __init__(self, target=None, daemon=None): self.t = target
    def start(self): self.t()
dash._th.Thread = Now
h.restart_model()
msgs = [r[0] for r in st.db.execute("SELECT content FROM messages ORDER BY id")]
print(f"  [{mode:8}] at {int(clock[0])}s the card said: {msgs[-1][:110]!r}")
if os.path.exists(REQ): os.remove(REQ)
