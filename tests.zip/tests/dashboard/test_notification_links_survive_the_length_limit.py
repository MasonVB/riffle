# ==========================================================================
# A notification about queued proposals keeps all its 'decide' links under
# Pushover's 1,024-character limit; the text gives way instead.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For 1, 5 or 8 proposals (argument 2) with long rationales full of
#   '&': the message's length as sent and how many complete links it
#   carries.
#
# WHY IT EXISTS
#   L15 (audit round 1): the message was cut at 1,024 after the links
#   were added, and escaping made the text longer than it was sliced, so
#   links were cut off.
#
# HOW IT WORKS
#   Calls notify.announce_pending with a fake urlopen that captures the
#   message.
#
# READING THE OUTPUT
#   `N proposal(s): message M chars as sent | complete links L of min(N,
#   5)`.
#
# RUNNING IT ON ITS OWN
#   python3
#   tests/dashboard/test_notification_links_survive_the_length_limit.py
#   . 5
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl15.py) for L15.
#   2026-11-05  Moved into tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile, yaml, urllib.request, urllib.parse, io, json; sys.path.insert(0, sys.argv[1])
from agent import notify
from agent.state import State, utcnow
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = tempfile.mkdtemp()
cfg["notify"].update({"enabled": True, "user_key": "u", "api_token": "t"})
notify.in_window = lambda c, now=None: True
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))
n_rows = int(sys.argv[2])
for i in range(n_rows):
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'comment','answer','{}',?,'queued')",
                  (utcnow(), f"Reply {i}: receipts & ledgers & tags & votes & more & more " * 12))
st.db.commit()
got = {}
class R(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *a): pass
def fake_urlopen(req, timeout=None):
    got["msg"] = dict(urllib.parse.parse_qsl(req.data.decode()))["message"]
    return R(json.dumps({"status": 1}).encode())
notify.urllib.request.urlopen = fake_urlopen
notify.announce_pending(st, cfg, lambda *a, **k: None)
m = got.get("msg", "")
links = m.count("&#8594;</a>")
print(f"  {n_rows} proposal(s): message {len(m)} chars as sent | complete links {links} of {min(n_rows, 5)}")
