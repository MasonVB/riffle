# ==========================================================================
# An error response whose body cannot be read still raises the client's
# HttpError with its status; and a dashboard send that gets no answer is
# recorded as unknown, not failed.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The exception type and status for a 503 whose body times out, and
#   the status recorded for an approved comment whose send got no
#   answer.
#
# WHY IT EXISTS
#   L7 (audit round 1): a failure while reading an error body escaped
#   every `except HttpError` as a raw TimeoutError; and an unanswered
#   send was recorded as failed, which the duplicate checks ignore, so a
#   comment that had landed could be sent again.
#
# HOW IT WORKS
#   Fakes urlopen raising an HTTPError with an unreadable body; approves
#   a comment whose send raises HttpError(0).
#
# READING THE OUTPUT
#   `error body unreadable -> HttpError, status 503` and `dashboard send
#   with no answer -> status 'unknown'`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl7.py) for L7.
#   2026-11-05  Moved into tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, io, json, tempfile, time, socket, urllib.error, urllib.request, yaml; sys.path.insert(0, sys.argv[1])
from agent import client, dash
from agent.state import State, utcnow
# 1. an error whose body cannot be read
class BadBody(io.RawIOBase):
    def read(self, *a): raise socket.timeout("timed out reading the error body")
def raising(*a, **k):
    raise urllib.error.HTTPError("http://x/api/comment", 503, "Service Unavailable", {}, BadBody())
client.urllib.request.urlopen = raising
try:
    client._req("http://x/api/comment")
    print("  error body unreadable: no exception?")
except client.HttpError as e:
    print(f"  error body unreadable -> HttpError, status {e.status}")
except Exception as e:
    print(f"  error body unreadable -> ESCAPED as {type(e).__name__}")
# 2. a dashboard send that gets no answer
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
st = State(os.path.join(d, "s.sqlite"))
def no_answer(*a, **k): raise client.HttpError(0, "TimeoutError: the read timed out")
dash.execute = no_answer
class W:
    def __init__(self, *a, **k): pass
dash.Writer = W
class H(dash.Handler): pass
H.state, H.cfg = st, cfg
h = H.__new__(H); h._update_card = lambda *a, **k: None; h._local_time = lambda: "now"; h.run_cycle = lambda *a, **k: None
aid = st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'comment','answer',?,'r','queued')",
                    (utcnow(), json.dumps({"post_id": 4, "parent_id": 2, "body": "An answer about receipts and their order."}))).lastrowid
st.db.commit()
h.decide(aid, "approve"); time.sleep(0.8)
print(f"  dashboard send with no answer -> status {st.db.execute('SELECT status FROM actions WHERE id=?', (aid,)).fetchone()[0]!r}")
