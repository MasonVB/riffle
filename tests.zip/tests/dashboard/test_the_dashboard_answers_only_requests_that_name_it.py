# ==========================================================================
# The dashboard answers only requests whose Host header names it (its
# hostname, a .local or tailnet name, or an IP address), which stops DNS
# rebinding.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For several Host values, the status of GET / and of POST
#   /api/decide.
#
# WHY IT EXISTS
#   Q1 (audit round 1): a web page in the operator's browser could reach
#   the dashboard through DNS rebinding; it has no login.
#
# HOW IT WORKS
#   Starts the real dashboard on a free loopback port and sends requests
#   with each Host value.
#
# READING THE OUTPUT
#   `Host VALUE GET / -> code POST /api/decide -> code ...`: 421 for
#   foreign names.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-28  Written in the sandbox (thost.py) for Q1.
#   2026-11-05  Moved into tests/dashboard.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, threading, http.client, yaml
sys.path.insert(0, sys.argv[1])
from agent import dash
from agent.state import State
from http.server import ThreadingHTTPServer
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml")))
cfg["data_dir"] = tempfile.mkdtemp()
dash.Handler.cfg = cfg; dash.Handler.state = State(os.path.join(cfg["data_dir"], "s.sqlite"))
srv = ThreadingHTTPServer(("127.0.0.1", 0), dash.Handler); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
import socket; me = socket.gethostname()
def req(method, path, host, body=None):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=20)
    hdr = {"Host": host}
    if body is not None: hdr["Content-Type"] = "application/json"
    c.putrequest(method, path, skip_host=True)
    for k, v in hdr.items(): c.putheader(k, v)
    data = json.dumps(body).encode() if body is not None else b""
    if body is not None: c.putheader("Content-Length", str(len(data)))
    c.endheaders(); c.send(data)
    r = c.getresponse(); return r.status, r.read()[:90]
for host in (me, f"127.0.0.1:{port}", "evil.example", "192.168.1.50.nip.io"):
    g = req("GET", "/", host); p = req("POST", "/api/decide", host, {"id": 1, "verdict": "approve"})
    print(f"  Host {host:24} GET / -> {g[0]}   POST /api/decide -> {p[0]} {p[1][:60]!r}")
srv.shutdown()
