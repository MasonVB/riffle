# ==========================================================================
# The witness pass pages forward from its saved marks, saves new marks,
# and raises an alarm (saving nothing) when an earlier segment no longer
# hashes the same.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 `ok` or `tamper`: the queries made on each of two runs,
#   the marks saved, and the alarms.
#
# WHY IT EXISTS
#   The witness pass is how riffle notices the registry rewriting
#   history.
#
# HOW IT WORKS
#   A fake registry with an identity log of 26,728 entries and a ledger
#   of 500, paged 20,000 at a time; `tamper` changes entries from 100
#   on.
#
# READING THE OUTPUT
#   `run 1 queries: ...`, `saved: ...`, `run 2 ...`, alarms.
#
# RUNNING IT ON ITS OWN
#   python3 tests/witness/test_the_witness_pass_pages_forward_and_alarms
#   _on_tampering.py . ok
#
# CHANGELOG
#   2026-10-23  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/witness.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import cycle, notify
TOTAL = {"identity": 26728, "ledger": 500}; PAGE = 20000
mode = sys.argv[2]; TAMPER = [False]
def h(c, n): return f"{c}-h{n}" + ("-X" if TAMPER[0] and n >= 100 else "")
qs = []
class FakeReader:
    def attest(self, **q):
        qs.append(dict(q)); out = {}
        for c, key in (("identity", "identity_log"), ("ledger", "treasury")):
            frm = int(q.get(f"{c}_from", 0)); exp = q.get(f"{c}_expect"); tot = TOTAL[c]
            if exp is not None and exp != h(c, frm):
                out[key] = {"status": "mismatch", "expect_matches": False, "verified_through_id": frm, "head": h(c, tot)}; continue
            end = min(frm + PAGE, tot)
            out[key] = {"status": "verified" if end == tot else "incomplete", "verified_through_id": end,
                        "verified_head": h(c, end), "head": h(c, tot), "expect_matches": True if exp else None}
        return out
notify.alarm = lambda *a, **k: None
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
logs = []; log = lambda t, level="info", **k: logs.append((level, t))
cycle.do_witness(st, FakeReader(), log)
print("  run 1 queries:", qs); print("  saved:", st.last_head("identity") and dict(st.last_head("identity")))
qs.clear(); TOTAL["identity"] = 27000
if mode == "tamper": TAMPER[0] = True
cycle.do_witness(st, FakeReader(), log)
print("  run 2 queries:", qs)
print("  run 2 saved identity through:", dict(st.last_head("identity"))["through_id"], "| alarms:", [t[:60] for l, t in logs if l == "alarm"])
