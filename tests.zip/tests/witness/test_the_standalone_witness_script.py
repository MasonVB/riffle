# ==========================================================================
# The standalone witness.py (run outside riffle) saves its marks, walks
# forward on a second run, and catches tampering.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks `first`, `second` or `tamper`: what the script
#   printed, its exit code, the mark lines in its file and the attest
#   calls.
#
# WHY IT EXISTS
#   witness.py lets anyone check the registry's logs independently of
#   riffle.
#
# HOW IT WORKS
#   Loads witness.py (argument 1) and answers its requests from a fake
#   registry.
#
# READING THE OUTPUT
#   The script's own lines, then `rc=... marks lines in file=... attest
#   calls=...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/witness/test_the_standalone_witness_script.py
#   witness.py first
#
# CHANGELOG
#   2026-10-23  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/witness.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, urllib.parse, importlib.util, io
path, mode = sys.argv[1], sys.argv[2]
spec = importlib.util.spec_from_file_location("witness", path); w = importlib.util.module_from_spec(spec); spec.loader.exec_module(w)
TOTAL = {"identity": 26728, "ledger": 500}; PAGE = 20000
TAMPER = mode == "tamper"
def h(chain, n, tampered=False): return f"{chain}-h{n}" + ("-X" if tampered and n >= 100 else "")
calls = []
def fake_get(url, token=None, timeout=30):
    calls.append(url.replace(w.BASE, ""))
    u = urllib.parse.urlparse(url); q = dict(urllib.parse.parse_qsl(u.query))
    if u.path == "/api/me":
        return 200, json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
    if u.path == "/api/pulse": return 200, {}
    out = {"now_utc": "2026-10-24T00:00:00Z"}
    for chain, key in (("identity", "identity_log"), ("ledger", "treasury")):
        frm = int(q.get(f"{chain}_from", 0)); exp = q.get(f"{chain}_expect")
        tot = TOTAL[chain]
        if exp is not None and exp != h(chain, frm, TAMPER):
            out[key] = {"status": "mismatch", "expect_matches": False, "verified_through_id": frm, "head": h(chain, tot, TAMPER)}
            continue
        end = min(frm + PAGE, tot)
        st = "verified" if end == tot else "incomplete"
        out[key] = {"status": st, "verified_through_id": end, "verified_head": h(chain, end, TAMPER),
                    "head": h(chain, tot, TAMPER), "expect_matches": (True if exp else None)}
    return 200, out
w.get = fake_get
import urllib.request
def no_net(*a, **k): raise OSError("offline test")
urllib.request.urlopen = no_net
d = tempfile.mkdtemp()
if mode in ("second", "tamper"):
    open(os.path.join(d, "witness.jsonl"), "w").write(json.dumps({"kind": "heads", "at": "2026-10-23T00:00:00Z",
        "identity": {"head": h("identity", 26000), "id": 26000}, "treasury": {"head": h("ledger", 400), "id": 400}}) + "\n")
open(os.path.join(d, "riffle.secret"), "w").write("x")
sys.argv = ["witness.py", "--handle", "riffle", "--dir", d, "--full"]
buf = io.StringIO(); real = sys.stdout; sys.stdout = buf
try: w.main()
except SystemExit as e: rc = e.code
sys.stdout = real
out = buf.getvalue()
keep = [l for l in out.splitlines() if any(k in l for k in ("identity", "treasury", "SAVING", "saved marks", "inbox", "comments_on", "totals", "nothing waiting"))]
print("\n".join("   " + l.strip() for l in keep))
p = os.path.join(d, "witness.jsonl"); lines = open(p).read().splitlines() if os.path.exists(p) else []
print(f"   rc={rc}  marks lines in file={sum(1 for l in lines if 'heads' in l)}  attest calls={sum(1 for c in calls if c.startswith('/api/attest'))}")
