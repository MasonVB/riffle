# ==========================================================================
# The witness pass makes one attest call where it used to make two, still
# alarms on tampering, and reads an 'incomplete' answer as the mark
# matching.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks `ok`, `tamper` or `incomplete`: attest calls made,
#   alarms, the marks afterwards, and how many 'carries no information'
#   lines were logged (0).
#
# WHY IT EXISTS
#   L1 (audit round 1): a separate re-check sent exactly the request the
#   walk's first page sends; and its log claimed an 'incomplete' answer
#   proved nothing, when the registry reports a mismatch ahead of
#   incomplete.
#
# HOW IT WORKS
#   A fake registry answering each case.
#
# READING THE OUTPUT
#   `[case] attest calls N | alarms ... | marks now ... | 'no
#   information' lines 0`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/witness/test_the_witness_pass_asks_once_and_reads_inco
#   mplete_correctly.py . ok
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl1.py) for L1; its first run queried
#               a column that does not exist.
#   2026-11-05  Moved into tests/witness.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent import cycle, notify
from agent.state import State
mode = sys.argv[2]
notify.alarm = lambda *a, **k: None
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
st.save_head("identity", 100, "aaa") if hasattr(st, "save_head") else None
st.db.execute("INSERT INTO heads (ts, chain, through_id, head) VALUES ('2026-10-28T00:00:00Z','identity',100,'aaa')") if not hasattr(st, "save_head") else None
st.db.execute("INSERT INTO heads (ts, chain, through_id, head) VALUES ('2026-10-28T00:00:00Z','treasury',50,'ttt')") if not hasattr(st, "save_head") else st.save_head("treasury", 50, "ttt")
st.db.commit()
calls = []
class R:
    def attest(self, **kw):
        calls.append(kw)
        if mode == "tamper" and len(calls) == 1:
            ident = {"status": "mismatch", "expect_matches": False, "verified_through_id": 100}
        elif mode == "incomplete" and len(calls) == 1:
            ident = {"status": "incomplete", "expect_matches": True, "verified_through_id": 150, "verified_head": "mid"}
        else:
            ident = {"status": "verified", "expect_matches": True, "verified_through_id": 200, "head": "bbb"}
        return {"identity_log": ident, "treasury": {"status": "verified", "expect_matches": True, "verified_through_id": 60, "head": "uuu"}}
logs = []
cycle.do_witness(st, R(), lambda t, level="info", **k: logs.append((level, t)))
saved = st.db.execute("SELECT chain, through_id FROM heads ORDER BY rowid").fetchall()
alarm = [t[:60] for l, t in logs if l == "alarm"]
wrong = [t[:50] for l, t in logs if "carries no information" in t]
print(f"  [{mode:10}] attest calls {len(calls)} | alarms {alarm or 'none'} | marks now {[tuple(r) for r in saved][-2:]} | 'no information' lines {len(wrong)}")
