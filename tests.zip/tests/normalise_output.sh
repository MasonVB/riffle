#!/bin/bash
# NORMALISE A RUN'S OUTPUT so two runs can be compared line by line: replaces
# what differs on every run (temporary paths, timestamps, ports, timings,
# memory peaks, process ids) with fixed tokens. Reads stdin, writes stdout.
#
# CHANGELOG
#   2026-10-23  Started in the sandbox as norm.sh.
#   2026-11-05  Moved here; also normalises the runner's own temporary paths.
sed -E \
  -e 's#/tmp/riffle-tests\.[A-Za-z0-9]+#RUN#g' \
  -e 's#/tmp/tmp\.?[A-Za-z0-9_]+#TMP#g' \
  -e 's#20[0-9]{2}-[0-9]{2}-[0-9]{2}[T ][0-9]{2}:[0-9]{2}(:[0-9]{2}(\.[0-9]+)?)?Z?#TS#g' \
  -e 's#up to [0-9]{13}#up to MS#g' \
  -e 's#age_days.: [0-9.]+#age_days#g' \
  -e 's#is [0-9]+\.[0-9]h old#is Nh old#g' \
  -e 's#127\.0\.0\.[12]:[0-9]+#127.0.0.x:PORT#g' \
  -e 's#peak +[0-9.]+ MiB#peak N MiB#g' \
  -e 's#MiB, +[0-9.]+s#MiB, Ns#g' \
  -e 's#riffle-build-c42-[0-9]+#riffle-build-c42-PID#g' \
  -e 's#[0-9]+ cores measured#N cores measured#g'
