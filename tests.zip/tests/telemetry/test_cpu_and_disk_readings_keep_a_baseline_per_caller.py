# ==========================================================================
# Telemetry's CPU and disk readings keep a separate baseline for each
# caller, so an error dump does not measure from the last tick.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That a cycle's end reading measures its cycle, and that an error
#   dump's CPU reading is not shared with the regular tick.
#
# WHY IT EXISTS
#   The earlier review: one shared baseline made every reading measure
#   from whoever read last. T5 (audit round 1) later did the same for
#   the network reading.
#
# HOW IT WORKS
#   Takes readings for different callers with CPU work in between.
#
# READING THE OUTPUT
#   Three lines; `SHARED — wrong` is the failure.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-23  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/telemetry.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, time; sys.path.insert(0, sys.argv[1])
from agent import telemetry as t
t.cores("cycle-start"); t.diskio("cycle-start")
x = sum(i*i for i in range(3_000_000))           # some CPU between the two
c = t.cores("cycle-end"); d = t.diskio("cycle-end")
u = c["usage"]
print("  cycle-end cores:", u if isinstance(u, str) else f"{len(u)} cores measured")
print("  cycle-end diskio:", d if "note" in d else "measured")
t.cores("tick"); e = t.cores("error")
print("  error dump vs tick (must stay separate):", e["usage"] if isinstance(e["usage"], str) else "SHARED — wrong")
