# ==========================================================================
# Pruning keeps recent samples, and dumps for 21 days but never more than
# 500.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The samples and dumps left after pruning a store with 604 dumps.
#
# WHY IT EXISTS
#   M6 (audit round 1): dumps were never pruned.
#
# HOW IT WORKS
#   Fills a store, prunes, counts.
#
# READING THE OUTPUT
#   `after prune: samples N of 3, dumps M of 604`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm6p.py) for M6.
#   2026-11-05  Moved into tests/telemetry.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, datetime as dt; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import telemetry as T
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite")); T.ensure(st)
now = dt.datetime.now(dt.timezone.utc)
iso = lambda d: d.isoformat(timespec="seconds").replace("+00:00", "Z")
ins = lambda ts, kind: st.db.execute("INSERT INTO telemetry (ts,kind,label,payload) VALUES (?,?,'x','{}')", (iso(ts), kind))
for h in (2, 30, 30 * 24): ins(now - dt.timedelta(hours=h), "sample")
for h in (2, 30, 10 * 24, 25 * 24): ins(now - dt.timedelta(hours=h), "dump")
for i in range(600): ins(now - dt.timedelta(hours=48, minutes=i), "dump")         # a run of errors two days ago
if hasattr(T, "boot_id"):
    st.db.execute("INSERT INTO telemetry_kept (boot,ts,kind,label,payload) VALUES ('A',?,'sample','x','{}')", (iso(now - dt.timedelta(days=30)),))
st.db.commit()
T.prune(st)
c = lambda q: st.db.execute(q).fetchone()[0]
samples = c("SELECT COUNT(*) FROM telemetry WHERE kind='sample'")
dumps = c("SELECT COUNT(*) FROM telemetry WHERE kind='dump'")
extra = f", kept-boot rows {c('SELECT COUNT(*) FROM telemetry_kept')} of 1" if hasattr(T, "boot_id") else ""
print(f"  after prune: samples {samples} of 3, dumps {dumps} of 604{extra}")
