# ==========================================================================
# After a reboot, telemetry keeps the previous boot's last hour of samples
# and its dump; with a wrong clock during that boot, still its last hour.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The rows kept for the previous boot and their time span, the current
#   boot's rows, and the case of a boot with its clock in the year 2000.
#
# WHY IT EXISTS
#   M6 (audit round 1): the hour before an unexplained reset is the
#   evidence, and the next boot's pruning deleted it.
#
# HOW IT WORKS
#   Writes three hours of a previous boot's samples, then runs
#   keep_last_boot as a new boot would.
#
# READING THE OUTPUT
#   `new boot: kept N rows (D dump), spanning T-T | ...` and the wrong-
#   clock line.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm6.py) for M6.
#   2026-11-05  Moved into tests/telemetry.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, datetime as dt; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import telemetry as T
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite")); T.ensure(st)
now = dt.datetime.now(dt.timezone.utc)
iso = lambda d: d.isoformat(timespec="seconds").replace("+00:00", "Z")
def add(ts, kind, boot, label="tick"):
    st.db.execute("INSERT INTO telemetry (ts,kind,label,payload) VALUES (?,?,?,?)", (iso(ts), kind, label, json.dumps({"boot": boot})))
# previous boot "AAA": three hours of minute samples ending 10 minutes ago, plus a dump at the end
for m in range(180): add(now - dt.timedelta(minutes=190 - m), "sample", "AAA")
add(now - dt.timedelta(minutes=11), "dump", "AAA", "error")
for m in range(5): add(now - dt.timedelta(minutes=5 - m), "sample", "BBB")       # this boot
st.db.commit()
if not hasattr(T, "keep_last_boot"):
    print("  (no keep_last_boot in this version)"); sys.exit()
st.note("telemetry_boot", "AAA"); T.boot_id = lambda: "BBB"
logs = []
n1 = T.keep_last_boot(st, lambda t, **k: logs.append(t))
kept = st.db.execute("SELECT MIN(ts), MAX(ts), COUNT(*), SUM(kind='dump') FROM telemetry_kept").fetchone()
n2 = T.keep_last_boot(st)                                   # dashboard restarted, same boot
print(f"  new boot: kept {n1} rows ({kept[3]} dump), spanning {kept[0][11:16]}-{kept[1][11:16]} | current boot rows kept: {st.db.execute('SELECT COUNT(*) FROM telemetry_kept WHERE payload LIKE ?', ('%BBB%',)).fetchone()[0]} | restart without reboot kept {n2}")
# a wrong clock during the previous boot: rows dated in the year 2000
st2 = State(os.path.join(tempfile.mkdtemp(), "s.sqlite")); T.ensure(st2)
for m in range(120):
    st2.db.execute("INSERT INTO telemetry (ts,kind,label,payload) VALUES (?,?,?,?)", (iso(dt.datetime(2000, 1, 1, 0, 0, tzinfo=dt.timezone.utc) + dt.timedelta(minutes=m)), "sample", "tick", json.dumps({"boot": "OLDCLOCK"})))
st2.db.commit(); st2.note("telemetry_boot", "OLDCLOCK")
print(f"  previous boot with a wrong clock (year 2000): kept {T.keep_last_boot(st2)} rows (its last hour)")
