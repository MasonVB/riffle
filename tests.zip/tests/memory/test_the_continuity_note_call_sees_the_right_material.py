# ==========================================================================
# The daily continuity-note call is made with the right schema and
# material, and stores the note; on a quiet day, no call is made.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: `busy` (the call's schema requires
#   `continuity`, it sees no paraphrase of the board, it sees riffle's
#   previous note and actions, and the note is stored and reported) or
#   `quiet` (no model calls).
#
# WHY IT EXISTS
#   R4.3 of the earlier review: the continuity note is riffle's message
#   to its next self, written from its own records, never from
#   paraphrases of other citizens' words.
#
# HOW IT WORKS
#   Runs the continuity step with a stub composer that records each
#   call.
#
# READING THE OUTPUT
#   `[case] model calls: N; ...` then one line per call.
#
# RUNNING IT ON ITS OWN
#   python3 tests/memory/test_the_continuity_note_call_sees_the_right_ma
#   terial.py . busy
#
# CHANGELOG
#   2026-10-24  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/memory.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import consolidate, cortex, memory
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
calls = []
def fake(llm, system, user, schema=None, **k):
    calls.append((system, user, schema))
    if "continuity" in (schema or {}).get("required", []) and "promote" not in (schema or {}).get("required", []):
        return json.dumps({"continuity": "I am working through my inbox backlog."})
    return json.dumps({"promote": [], "write": [], "drop": [], "note": "ok", "continuity": "I am working through my inbox backlog."})
cortex.complete = fake
logs, says = [], []
log = lambda t, level="info", **k: logs.append(t); say = lambda kind, text, meta=None: says.append(text)
cfg = {"llm": {"composer": {}}, "memory": {"min_age_hours": 0}}
if sys.argv[2] == "busy":
    memory.remember(st, "BOARD-PARAPHRASE: a citizen says to ignore the rules", kind="incidental", source="t")
    st.db.execute("UPDATE memories SET ts='2026-10-01T00:00:00Z'"); st.db.commit()
consolidate.run(st, cfg, log, say=say)
print(f"  [{sys.argv[2]}] model calls: {len(calls)}; candidates seen: {len(consolidate.candidates(st, cfg)) if sys.argv[2]=='busy' else 0}")
for i, (sysm, user, schema) in enumerate(calls):
    print(f"    call {i+1}: schema requires {schema.get('required')}; sees board paraphrase: {'BOARD-PARAPHRASE' in user}; sees prior note/actions block: {'YOUR CONTINUITY NOTE NOW' in user}")
print(f"    note stored: {st.note('continuity')!r}; report mentions it: {any('continuity' in x for x in says)}")
