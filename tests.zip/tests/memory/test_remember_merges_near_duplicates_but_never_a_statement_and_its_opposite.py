# ==========================================================================
# memory.remember merges near-duplicates of the same kind, but never a
# statement with its negation, never across kinds, and never with an
# expired memory.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For pairs of memories, whether they were kept separate or merged,
#   against what is right for each pair.
#
# WHY IT EXISTS
#   H7 (audit round 1): 'riffle may not sign payouts' was merged into
#   'riffle may sign payouts' as a duplicate, since the duplicate key
#   ignored short words like 'not'; a lapsed fact could not be learned
#   again; and the same words from the operator and a citizen were
#   treated as one memory.
#
# HOW IT WORKS
#   Writes each pair into a fresh store and checks whether the second
#   returned the first's id.
#
# READING THE OUTPUT
#   One line per pair, `separate|MERGED ok`; WRONG is the failure.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tmem.py) for H7.
#   2026-11-05  Moved into tests/memory.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import memory
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
def pair(label, a, b, ka="self", kb="self", expire_first=False, want_separate=True):
    m1 = memory.remember(st, a, kind=ka)
    if expire_first: st.db.execute("UPDATE memories SET expired=1 WHERE id=?", (m1,)); st.db.commit()
    m2 = memory.remember(st, b, kind=kb)
    sep = m1 != m2
    print(f"  {label:44} {'separate' if sep else 'MERGED  '} {'ok' if sep == want_separate else 'WRONG'}")
pair("a correction (may / may not)", "Riffle may sign payout bindings for listings it has completed", "Riffle may not sign payout bindings for listings it has completed")
pair("should / shouldn't", "Riffle should reply before reading the whole thread on the board", "Riffle shouldn't reply before reading the whole thread on the board")
pair("curly apostrophe (don\u2019t)", "Citizens accept replies that quote the original claim exactly", "Citizens don\u2019t accept replies that quote the original claim exactly")
pair("an expired fact, restated", "The registry caps attestation claims at five hundred characters", "The registry caps attestation claims at five hundred characters", expire_first=True)
pair("same words, operator vs riffle", "Seals must use lowercase labels with no colons anywhere", "Seals must use lowercase labels with no colons anywhere", ka="operator", kb="self")
pair("reworded repeat (code comment's example)", "Refused to post a full argument on #4454 because there was no live thread to anchor the argument.",
     "I was refused to post a full argument on #4454 because there was no live thread to anchor the empirical finding.", want_separate=False)
pair("exact repeat, same kind, live", "Witness marks are saved only when both chains verify together", "Witness marks are saved only when both chains verify together", want_separate=False)
