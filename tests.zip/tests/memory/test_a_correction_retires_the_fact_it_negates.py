# ==========================================================================
# A correction retires the older fact it negates, when they differ only by
# the negation; different facts that share words, and pinned facts, stay.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   'may sign' then 'may never sign' (and the same with 'not'): the
#   older is retired. Two different facts that share words: both stay. A
#   pinned fact then its correction: both stay. A plain near-duplicate:
#   merged, as before.
#
# WHY IT EXISTS
#   U14 (audit round 2): after H7 stopped merging a correction into the
#   fact it negates, the old fact stayed live beside it, so riffle
#   remembered both X and not X.
#
# HOW IT WORKS
#   Writes each pair into a fresh store and inspects superseded_by.
#
# READING THE OUTPUT
#   One line per case: `older retired`, `both live` or `merged into
#   one`, with the count of live memories.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tu14.py) for U14.
#   2026-11-05  Moved into tests/memory.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent import memory
from agent.state import State
def case(label, first, second, pin=False):
    st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
    a = memory.remember(st, first, kind="self", pinned=1 if pin else 0)
    b = memory.remember(st, second, kind="self")
    r = st.db.execute("SELECT superseded_by FROM memories WHERE id=?", (a,)).fetchone()[0]
    live = st.db.execute("SELECT COUNT(*) FROM memories WHERE superseded_by IS NULL").fetchone()[0]
    state = "merged into one" if a == b else ("older retired" if r == b else "both live")
    print(f"  {label:34} -> {state} ({live} live)")
case("correction with 'never'", "riffle may sign payouts for any open listing row", "riffle may never sign payouts for any open listing row")
case("correction with 'not'", "riffle may sign payouts for any open listing row", "riffle may not sign payouts for any open listing row")
case("different facts sharing words", "the receipts batch settled out of order on tuesday morning", "the receipts batch did not settle in order on monday after the outage")
case("pinned fact, then its correction", "riffle may sign payouts for any open listing row", "riffle may never sign payouts for any open listing row", pin=True)
case("plain near-duplicate", "refused to post on #4454 because no live thread anchors the argument", "was refused to post on #4454 because no live thread anchors the argument")
