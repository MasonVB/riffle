# ==========================================================================
# Pinning an expired memory, through the real dashboard route, makes it
# live and permanent; purging an expired memory also removes its words
# from the search index.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   L12: pinned, expired and expiry after the pin (1, 0, none). L13: the
#   purged row is gone and its words are no longer searchable.
#
# WHY IT EXISTS
#   L12 (audit round 1): pinning left the memory expired, hidden and
#   still due to be purged. L13: the purge deleted rows directly, so the
#   contentless search index kept their words.
#
# HOW IT WORKS
#   Starts the real dashboard on a free port, POSTs /api/memory/pin,
#   then runs the consolidation sweep.
#
# READING THE OUTPUT
#   Two lines, one per finding.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl1213.py) for L12 and L13.
#   2026-11-05  Moved into tests/memory.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, threading, http.client, yaml, datetime as dt; sys.path.insert(0, sys.argv[1])
from agent import dash, memory, consolidate
from agent.state import State
from http.server import ThreadingHTTPServer
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = tempfile.mkdtemp()
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))
old = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=60)).isoformat()
m1 = memory.remember(st, "The witness walk pages from the saved mark forward", kind="self")
m2 = memory.remember(st, "Zebrafish quokka marmalade is a phrase nobody else would write", kind="self")
st.db.execute("UPDATE memories SET expired=1, expires_at=? WHERE id IN (?,?)", (old, m1, m2)); st.db.commit()
# L12: pin m1 through the real dashboard route
dash.Handler.cfg = cfg; dash.Handler.state = st
srv = ThreadingHTTPServer(("127.0.0.1", 0), dash.Handler); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
c = http.client.HTTPConnection("127.0.0.1", port, timeout=20)
c.request("POST", "/api/memory/pin", json.dumps({"id": m1, "pinned": True}), {"Content-Type": "application/json"})
c.getresponse().read(); srv.shutdown()
r = st.db.execute("SELECT pinned, expired, expires_at FROM memories WHERE id=?", (m1,)).fetchone()
print(f"  L12 pinned an expired memory: pinned={r[0]} expired={r[1]} expires_at={r[2] and 'set'}")
# L13: the sweep purges m2; are its words still in the search index?
consolidate.sweep(st, cfg)
gone = st.db.execute("SELECT COUNT(*) FROM memories WHERE id=?", (m2,)).fetchone()[0] == 0
hits = st.db.execute("SELECT COUNT(*) FROM memories_fts WHERE memories_fts MATCH 'quokka'").fetchone()[0]
print(f"  L13 purged memory row gone: {gone} | its words still in the search index: {hits > 0}")
