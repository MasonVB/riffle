# ==========================================================================
# Daily consolidation keeps an existing long-term memory long-term (no
# demotion) and promotes no more than its cap.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: `c` (an existing long-term memory keeps
#   its tier and has no expiry afterwards) or `d` (with a cap of 3, at
#   most three new long-term memories).
#
# WHY IT EXISTS
#   H7 (audit round 1): consolidation could demote long-term memories,
#   and its writes did not obey the cap.
#
# HOW IT WORKS
#   Runs consolidate.run with a stub composer answering a chosen set of
#   promotions and writes.
#
# READING THE OUTPUT
#   `[c] existing long-term memory now: tier='long' expires=never ...`
#   or `[d] cap 3: new long-term memories N ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/memory/test_consolidation_keeps_long_term_memories_and
#   _obeys_its_cap.py . c
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tcons.py) for H7.
#   2026-11-05  Moved into tests/memory.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import memory, consolidate, cortex
mode = sys.argv[2]; _m = mode; mode = 'd' if mode == 'd2' else mode
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = tempfile.mkdtemp()
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))
L = "The registry refuses attestation claims longer than five hundred characters"
lid = memory.remember(st, L, kind="self"); st.db.execute("UPDATE memories SET tier='long', expires_at=NULL WHERE id=?", (lid,))
shorts = [memory.remember(st, t, kind="self") for t in (
    "Comment ids are dense so a one digit typo names a real comment",
    "Citizens answer faster when the question names the exact figure",
    "Threads go quiet within six hours of the last reply on most days",
    "Witness marks only count when both hash chains verified together")]
st.db.commit()
if _m == "d2":
    print("  [d] the two long writes now:", [(r[0], r[1][:40]) for r in st.db.execute("SELECT tier, text FROM memories WHERE source='consolidation' ORDER BY id")]); print("  [d] report lines:", [l[:90] for l in (res or "").split("\n") if "short term" in l][:3]); sys.exit(0)
if mode == "c":
    plan = {"promote": [], "write": [{"text": L, "tier": "short"}], "drop": [], "note": "n"}
else:
    plan = {"promote": [{"id": i, "why": "useful"} for i in shorts[:3]],
            "write": [{"text": "Long replies get fewer answers than short pointed questions do", "tier": "long"},
                      {"text": "I proposed reading #9823 to check the timestamps against the comments", "tier": "long"}],
            "drop": [], "note": "n"}
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps({"continuity": "I keep a short note."}) \
    if "continuity" in (schema or {}).get("required", []) else json.dumps(plan)
logs = []
res = consolidate.run(st, cfg, lambda t, level="info", **k: logs.append(t), say=lambda *a, **k: None)
row = st.db.execute("SELECT tier, expires_at FROM memories WHERE id=?", (lid,)).fetchone()
longs = st.db.execute("SELECT COUNT(*) FROM memories WHERE tier='long' AND id!=?", (lid,)).fetchone()[0]
long_texts = [r[0][:45] for r in st.db.execute("SELECT text FROM memories WHERE tier='long' AND id!=? ORDER BY id", (lid,))]
if mode == "d2":
    print("  [d] the two long writes now:", [(r[0], r[1][:40]) for r in st.db.execute("SELECT tier, text FROM memories WHERE source='consolidation' ORDER BY id")]); print("  [d] report lines:", [l[:90] for l in (res or "").split("\n") if "short term" in l][:3]); sys.exit(0)
if mode == "c":
    print(f"  [c] existing long-term memory now: tier={row['tier']!r} expires={'never' if row['expires_at'] is None else 'in 7 days'} | summary: {(res or '')[:90]!r}")
else:
    print(f"  [d] cap 3: new long-term memories {longs} | {long_texts}")
