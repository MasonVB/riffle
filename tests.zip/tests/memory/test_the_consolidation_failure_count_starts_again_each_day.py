# ==========================================================================
# Consolidation's count of failed attempts starts again each day: three
# failures one day do not block the first attempt the next.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   What the log says on the first failure of the next day.
#
# WHY IT EXISTS
#   The earlier review: three failures stopped consolidation for good,
#   not for the day.
#
# HOW IT WORKS
#   Makes the composer fail three times on one day, then once on the
#   next.
#
# READING THE OUTPUT
#   `next day, first failure: [...]`: a single failure, with no 'three
#   failures' message.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-23  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/memory.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import consolidate, cortex
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
from agent import memory
for i in range(3):
    st.db.execute("INSERT INTO memories (ts,text) VALUES ('2026-10-20T00:00:00Z', ?)", (f"m{i}",))
st.db.commit()
cortex.complete = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("bad output"))
day = ["2026-10-21T10:00:00Z"]
consolidate.utcnow = lambda: day[0]
import agent.state as S; S.utcnow = lambda: day[0]
logs = []
log = lambda t, level="info", **k: logs.append(t)
cfg = {"llm": {"composer": {}}, "memory": {}}
for _ in range(3): consolidate.run(st, cfg, log)
day[0] = "2026-10-22T10:00:00Z"
logs.clear(); consolidate.run(st, cfg, log)
print("  next day, first failure:", [l for l in logs if "failed" in l or "three" in l])
