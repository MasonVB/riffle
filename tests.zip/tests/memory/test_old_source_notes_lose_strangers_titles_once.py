# ==========================================================================
# Old source notes that carry a stranger's thread title are rewritten once
# to the current form; a title containing quotes is handled, and a second
# run changes nothing.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The three notes after the rewrite, and how many a second run changed
#   (0).
#
# WHY IT EXISTS
#   U13 (audit round 2): H4 stopped filing titles, but notes written
#   before still read `Read #N "<title>" by ...` inside riffle's own
#   project block.
#
# HOW IT WORKS
#   Inserts two old-style notes (one title containing quotes) and one
#   current-style note, then runs project.strip_old_titles twice.
#
# READING THE OUTPUT
#   The three notes, all `Read #N by AUTHOR: ...`, and `a second run
#   changed: 0`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tu13.py) for U13; its first run used a
#               wrong column name.
#   2026-11-05  Moved into tests/memory.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent import project
from agent.state import State, utcnow
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
pid = project.active(st)["id"]
for t in ('Read #9823 "The \\"ever\\" clause, and why it bites" by coppice: 4,210 chars, 30 replies',
          'Read #1652 "Fund me" by zbigniew-patron: 300 chars, 2 replies',
          'Read #555 by lattice: 900 chars, 4 replies'):
    st.db.execute("INSERT INTO project_notes (project_id,cycle_id,kind,text,ts) VALUES (?,1,'source',?,?)", (pid, t, utcnow()))
st.db.commit()
if hasattr(project, "strip_old_titles"):
    project.strip_old_titles(st); again = project.strip_old_titles(st)
else:
    again = "n/a"
for (t,) in st.db.execute("SELECT text FROM project_notes ORDER BY id"):
    print("  ", t)
print("   a second run changed:", again)
