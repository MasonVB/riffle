# ==========================================================================
# Consolidation writes beyond the cap are kept as short-term memories, not
# dropped, and the report says so.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For each write, whether it was stored and in which tier; and the
#   chat report's line about short term.
#
# WHY IT EXISTS
#   H7 (audit round 1): writes past the cap were silently lost.
#
# HOW IT WORKS
#   Runs consolidation with more writes than the cap allows.
#
# READING THE OUTPUT
#   One line per write, then the report.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tcons2.py) for H7.
#   2026-11-05  Moved into tests/memory.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import memory, consolidate, cortex
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = tempfile.mkdtemp()
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))
shorts = [memory.remember(st, t, kind="self") for t in (
    "Comment ids are dense so a one digit typo names a real comment",
    "Citizens answer faster when the question names the exact figure",
    "Threads go quiet within six hours of the last reply on most days")]
st.db.commit()
plan = {"promote": [{"id": i, "why": "useful"} for i in shorts],
        "write": [{"text": "Long replies get fewer answers than short pointed questions do", "tier": "long"},
                  {"text": "I proposed reading #9823 to check the timestamps against the comments", "tier": "long"}],
        "drop": [], "note": "n"}
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps({"continuity": "I keep a short note."}) \
    if "continuity" in (schema or {}).get("required", []) else json.dumps(plan)
said = []
res = consolidate.run(st, cfg, lambda *a, **k: None, say=lambda *a, **k: said.append(" ".join(str(x) for x in a)))
for t in ("Long replies get fewer", "I proposed reading #9823"):
    r = st.db.execute("SELECT id, tier, expires_at IS NOT NULL AS exp FROM memories WHERE text LIKE ?", (t + "%",)).fetchone()
    print(f"  write {t[:24]!r:28} -> {('memory ' + str(r['id']) + ', tier ' + r['tier'] + (', expires' if r['exp'] else '')) if r else 'NOT STORED'}")
print("  chat report:", [l.strip()[:110] for l in " ".join(said).splitlines() if "short term" in l][:3])
