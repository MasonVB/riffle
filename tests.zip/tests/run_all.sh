#!/bin/bash
# RUN EVERY TEST, SAFELY, AGAINST A COPY OF A RIFFLE TREE.
#
# usage:  bash tests/run_all.sh [TREE]        (default: the tree tests/ is in)
#         bash tests/run_all.sh [TREE] > results.txt
#
# What it does, in order:
#   1. Copies TREE (with its .git, without config.yaml) to a temporary
#      directory, and puts config.example.yaml there as config.yaml. The tree
#      you point it at is never modified: several tests edit files to make a
#      check fail on purpose, and the deploy gates read config.yaml. On the
#      box, /opt/riffle/config.yaml (with your keys) is never read or touched.
#   2. Makes a scratch directory for the run ($RIFFLE_TMP), and a signer
#      sandbox ($RIFFLE_SIGNER_SANDBOX) holding a THROWAWAY signing key, the
#      same every run so results can be compared, never riffle's real key.
#   3. Runs each test in tests/list_of_tests.txt from the copy's root, with
#      PYTHONPATH=tests/lib, which loads tests/lib/riffle_test_safety_net.py
#      (each test also loads it itself): a fixed random seed, and a safety
#      net that refuses to run as riffle's own accounts, and refuses writes under /opt/riffle,
#      /var/lib/riffle*, /etc and /usr/local, any network connection but
#      loopback, riffle's own ports, and real systemctl changes.
#   4. Prints "@@@ test: name" and the test's output for each (a prefix no
#      test prints itself, so a run can be split back into tests), then deletes the
#      temporary copy, scratch directory and key.
#
# Optional: RIFFLE_REGISTRY_MESSAGES=<file> enables the signing tests that
# check signatures against the registry's own code (see
# tests/lib/extract_registry_message_builders.sh); without it they print
# SKIPPED. ONLY=<pattern> runs only the tests whose names match.
#
# Nothing here needs root, and nothing should be run as root.
#
# CHANGELOG
#   2026-10-23  Started in the sandbox as regress.sh, run against the working
#               tree directly.
#   2026-11-05  Rewritten for tests/: works on a temporary copy, sets up the
#               scratch directory, throwaway key and safety net, and reads the
#               list of tests from list_of_tests.txt. Copies the suite itself
#               and sets the executable bits there, since GitHub's web
#               uploader drops them.
set -uo pipefail
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
TESTS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$(cd "${1:-$TESTS/..}" && pwd)"
[ -f "$SRC/agent/cycle.py" ] || { echo "not a riffle tree: $SRC" >&2; exit 2; }
if [ "$(id -u)" = 0 ]; then
  echo "!! running the tests as root is not needed and not advised; continuing" >&2
fi
RUN="$(mktemp -d -t riffle-tests.XXXXXX)"
trap 'rm -rf "$RUN"' EXIT
mkdir -p "$RUN/tree" "$RUN/tmp" "$RUN/signer/lib"
tar -C "$SRC" --exclude=./config.yaml --exclude='*/__pycache__' -cf - . | tar -C "$RUN/tree" -xf -
# The example config names riffle's real directories (data_dir /var/lib/riffle,
# library.root /var/lib/riffle-library). Every test reads the COPY's file, so
# they are pointed into the run's scratch directory here: a test that forgets
# to override one cannot reach the real library. (The safety net found this:
# library_put tests had always written to /var/lib/riffle-library.)
mkdir -p "$RUN/tmp/data" "$RUN/tmp/library"
sed -i -e "s#^data_dir: /var/lib/riffle\$#data_dir: $RUN/tmp/data#" \
       -e "s#^  root: /var/lib/riffle-library\$#  root: $RUN/tmp/library#" "$RUN/tree/config.example.yaml"
grep -q "^data_dir: $RUN/tmp/data" "$RUN/tree/config.example.yaml" && grep -q "^  root: $RUN/tmp/library" "$RUN/tree/config.example.yaml" \
  || echo "!! could not point config.example.yaml's directories into the run; the safety net will refuse any test that uses them" >&2
# NO DAILY MEMORY STEP IN CYCLE TESTS. The cycle runs it at its first wake
# after consolidate_after_hour_utc (09:00), so before 2026-11-05 every cycle
# test's output depended on the hour it ran: after 09:00 the step added model
# calls and changed riffle's memories and prompt. 24 means "never" (no hour
# is 24 or later). The memory tests call consolidate.run() directly and do
# not go through this check.
sed -i "s#^  consolidate_after_hour_utc: [0-9]*#  consolidate_after_hour_utc: 24#" "$RUN/tree/config.example.yaml"
grep -q "^  consolidate_after_hour_utc: 24" "$RUN/tree/config.example.yaml" \
  || echo "!! could not turn off the daily memory step for the run; cycle tests will differ after 09:00 UTC" >&2
cp "$RUN/tree/config.example.yaml" "$RUN/tree/config.yaml"
python3 -c 'import hashlib,sys; open(sys.argv[1],"wb").write(hashlib.sha256(b"riffle tests: a throwaway key, never riffle\x27s").digest())' "$RUN/signer/seed"
for f in keyutil.py ed25519_pure.py; do [ -f "$RUN/tree/$f" ] && cp "$RUN/tree/$f" "$RUN/signer/lib/"; done
chmod 755 "$RUN/signer/lib"; chmod 644 "$RUN/signer/lib/"* 2>/dev/null
# THE SUITE IS COPIED TOO, and its scripts made executable in the copy.
# GitHub's web uploader does not keep the executable bit, so on the box the
# stand-ins for sudo and systemd-run would arrive as plain files, which a PATH
# search passes over: the deploy tests would have reached the REAL sudo.
mkdir -p "$RUN/tests"
tar -C "$TESTS" --exclude='__pycache__' -cf - . | tar -C "$RUN/tests" -xf -
find "$RUN/tests" \( -name '*.sh' -o -name '*.py' -o -path '*/stand_in_*/*' \) -type f -exec chmod +x {} +
TESTS="$RUN/tests"
export RIFFLE_TREE="$RUN/tree" RIFFLE_TESTS="$TESTS" RIFFLE_TMP="$RUN/tmp" \
       RIFFLE_ME_JSON="$TESTS/fixtures/registry_me_response.json" \
       RIFFLE_SIGNER_SANDBOX="$RUN/signer" PYTHONPATH="$TESTS/lib" \
       RIFFLE_REGISTRY_MESSAGES="${RIFFLE_REGISTRY_MESSAGES:-}"
cd "$RIFFLE_TREE"
while IFS= read -r line; do
  case "$line" in ''|'#'*) continue;; esac
  name="${line%% | *}"; cmd="${line#* | }"
  name="$(echo "$name" | sed 's/[[:space:]]*$//')"
  if [ -n "${ONLY:-}" ] && ! echo "$name" | grep -qE -- "$ONLY"; then continue; fi
  echo "@@@ test: $name"
  ( cd "$RIFFLE_TREE" && timeout 900 bash -c "$cmd" ) 2>&1 \
    | grep -vE "DeprecationWarning|warnings.warn|^\s*$" | head -40
done < "$TESTS/list_of_tests.txt"
