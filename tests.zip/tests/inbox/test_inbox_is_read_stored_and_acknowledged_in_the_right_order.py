# ==========================================================================
# A cycle reads the inbox, stores it, shows it to the composer and only
# then acknowledges it; if the composer fails, nothing is acknowledged and
# nothing is lost.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The order of registry and composer calls in a real cycle (me before
#   COMPOSER before ack on success; no ack when the composer fails),
#   that the inbox guidance sits outside the board while the messages
#   sit inside it, and that no message text leaks outside the board.
#
# WHY IT EXISTS
#   An acknowledgement moves the registry's cursor past the messages.
#   Acknowledging before they were safely stored and shown would lose
#   them for good if the cycle then died.
#
# HOW IT WORKS
#   Runs a real cycle against the stub registry twice (argument `ok` or
#   `fail`, the composer raising), saving the prompt to
#   $RIFFLE_TMP/u.txt.
#
# READING THE OUTPUT
#   `[mode] ... order=[...]`, then for the first run whether the
#   guidance is outside the board, the messages inside it, and message
#   text outside it (False).
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-30  Last changed in the sandbox (hin_main.py), when the H6/M5
#               prompt layout put blocks after </board>: 'outside the board'
#               became before OR after it. Written earlier, for the inbox
#               work.
#   2026-11-05  Moved into tests/inbox.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo = sys.argv[1]; mode = sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"]))
calls = []
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        def f(*a, **k):
            calls.append(n if n != "me" else f"me(since={k.get('since')})")
            if n == "me": return copy.deepcopy(me)
            if n == "ack": return {"mode": "legacy"}
            return {}
        return f
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
def complete(llm, system, user, **k):
    if "deciding once a day" in system:                       # the memory pass
        return json.dumps({"promote": [], "write": [], "drop": [], "note": "", "continuity": "c"})
    calls.append("COMPOSER"); open(__import__("os").environ["RIFFLE_TMP"] + "/u.txt", "w").write(user)
    if mode == "fail": raise RuntimeError("composer died")
    return json.dumps({"action": "noop", "payload": {}, "rationale": "x"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
for run in (1, 2):
    calls.clear()
    sys.argv = ["cycle", "--config", cp] + (["--force"] if run == 2 else [])
    try: cycle.main()
    except SystemExit: pass
    if cycle._CYCLE_LOCK: cycle._CYCLE_LOCK.close(); cycle._CYCLE_LOCK = None
    db = sqlite3.connect(os.path.join(d, "state.sqlite"))
    print(f"  run {run} [{mode}]: {calls}")
    print(f"    items: {db.execute('SELECT source, status, shown_count FROM inbox_items').fetchall()}")
    for (t,) in db.execute("SELECT text FROM journal WHERE text LIKE 'inbox%' OR text LIKE 'backlog%' ORDER BY id DESC LIMIT 2"):
        print("    J:", t[:110])
    if run == 1 and os.path.exists(__import__("os").environ["RIFFLE_TMP"] + "/u.txt"):
        u = open(__import__("os").environ["RIFFLE_TMP"] + "/u.txt").read(); own, rest = u.split("<board>", 1); rest, _tl = (rest.split("</board>", 1) + [""])[:2]; own = own + _tl
        print(f"    guidance outside board: {'YOUR INBOX, AND HOW' in own}; messages inside board: {'INBOX \u2014 NEW' in rest or 'INBOX \u2014 OLDER' in rest}; message text outside board: {'example-neighbor' in own}")
