# ==========================================================================
# A burst of 100 messages in one bucket, more than the drain's page cap,
# is read on over the following cycles until all 100 are stored, without
# duplicates.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   How many items are stored after the burst's cycle and after each of
#   four later cycles.
#
# WHY IT EXISTS
#   L18 (audit round 1): items past the cap were acknowledged past and
#   lost.
#
# HOW IT WORKS
#   A fake registry serves 20 pages of 5 replies inside a window that
#   starts at a known time (interval.since), as the real registry does.
#
# READING THE OUTPUT
#   `stored after the cycle 35; after each later cycle [65, 95, 100,
#   100] | duplicates 0`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tl18.py) for L18.
#   2026-11-04  Given a realistic window (interval.since and real timestamps)
#               after U1: the read-on now needs the window's start, and the
#               old fixture's items were dated 1970.
#   2026-11-05  Moved into tests/inbox.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent import inbox
from agent.state import State
PAGES, PER = 20, 5                              # a burst: 20 pages of 5 replies in one bucket
def page(i):
    items = [{"id": 100000 - (i * PER + j), "comment_id": 100000 - (i * PER + j), "post_id": 4, "body": f"burst reply {i}.{j}", "created_at": 1793000000000 + (PAGES * PER - (i * PER + j)) * 1000}
             for j in range(PER)]
    return {"now": 1793000000000 + 10 ** 7, "since_last_visit": {"truncated": True, "replies": items, "interval": {"since": 1793000000000},
            "replies_next_before": (f"tok{i + 1}" if i + 1 < PAGES else None)}}
class W:
    def me(self, since=None, before=None):
        return page(int(before[3:]) if before else 0)
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite")); inbox.ensure(st)
logs = []
log = lambda t, **k: logs.append(t)
rows, stats = inbox.rows_from_me(W().me())
try:
    rows += inbox.drain(W(), stats, log, state=st)
except TypeError:
    rows += inbox.drain(W(), stats, log)                # the original takes no state
inbox.store(st, rows, "live")
count = lambda: st.db.execute("SELECT COUNT(*) FROM inbox_items").fetchone()[0]
seen = [count()]
for _ in range(4):                                      # the next four cycles
    if hasattr(inbox, "resume"):
        inbox.resume(st, W(), log)
    seen.append(count())
print(f"  burst of {PAGES * PER} items: stored after the cycle {seen[0]}; after each later cycle {seen[1:]} | duplicates {count() - len(set(r[0] for r in st.db.execute('SELECT key FROM inbox_items')))}")
