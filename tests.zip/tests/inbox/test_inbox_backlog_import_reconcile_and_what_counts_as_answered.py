# ==========================================================================
# The inbox module end to end: the one-off backlog import, merging an item
# seen in two buckets, reconciling answered, queued and ignored items, and
# post mentions.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That the backlog import pages through every direct bucket and stores
#   each distinct item once (an item in two buckets is merged), leaves
#   in_threads_you_joined out, counts correctly; that reconcile marks a
#   replied item answered, hides an item whose reply is queued, and
#   passes over one shown three times; that being picked but never
#   answered does not count as shown; and that a post mention is
#   answered by a top-level comment.
#
# WHY IT EXISTS
#   The inbox was rebuilt during the earlier review after two months of
#   replies and mentions never reached riffle. This is the module's own
#   regression test.
#
# HOW IT WORKS
#   A fake registry serves 125 replies, 93 comments on riffle's posts,
#   144 mentions (every tenth from a post, with no comment id) and 300
#   thread comments, paged 50 at a time.
#
# READING THE OUTPUT
#   The import result and request count, the counts, expected against
#   stored, the merged buckets, then one line per reconcile case.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-24  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/inbox.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile; sys.path.insert(0, ".")
from agent.state import State
from agent import inbox
NOW = 1792800000000; DAY = 86400000
SIZES = {"replies": 125, "comments_on_your_posts": 93, "mentions_of_you": 144, "in_threads_you_joined": 300}
data = {}
cid = 1000
for b, n in SIZES.items():
    rows = []
    for i in range(n):
        cid += 1
        r = {"id": cid, "comment_id": cid, "post_id": 4000 + (cid % 50), "parent_id": None,
             "author": "someone", "post_title": "t", "body": f"{b} #{i}", "created_at": NOW - (i + 1) * DAY // 3}
        if b == "mentions_of_you" and i % 10 == 0:          # a mention from a post: no comment id
            r.update(id=None, comment_id=None, mention_id=90000 + i)
        rows.append(r)
    data[b] = rows                                            # newest first
data["replies"][0:5] = [dict(x) for x in data["comments_on_your_posts"][0:5]]   # overlap: same comment, two buckets
calls = []
class W:
    def me(self, since=None, before=None):
        calls.append((since, before))
        slv = {"truncated": False}
        for b, rows in data.items():
            pool = rows
            if before:
                t = int(before.split(":")[0]); pool = [r for r in rows if r["created_at"] < t]
            page = pool[:50]
            slv[b] = page
            if len(pool) > 50:
                slv["truncated"] = True; slv[f"{b}_next_before"] = f"{page[-1]['created_at']}:{page[-1]['id'] or 0}"
        return {"now": NOW, "since_last_visit": slv}
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
log = lambda t, level="info", **k: print("   log:", t[:100])
got = inbox.import_backlog(st, W(), log)
print("  backlog imported:", got, "| requests:", len(calls))
c = inbox.counts(st); print("  counts:", c)
exp = len({(r['id'] or ('m', r.get('mention_id'))) for b in inbox.DIRECT for r in data[b]})
print(f"  distinct direct items expected {exp}, stored {c['backlog']}")
print("  in_threads imported:", st.db.execute("SELECT COUNT(*) FROM inbox_items WHERE buckets LIKE '%in_threads%'").fetchone()[0])
print("  merged buckets on an overlapping item:", st.db.execute("SELECT buckets FROM inbox_items WHERE key=?", (f"c{data['comments_on_your_posts'][0]['id']}",)).fetchone()[0])
# reconcile: answer one, queue one, ignore one shown 3 times
items = [d for d in inbox.pending(st, "backlog") if d["comment_id"] is not None]; print("  picked for the test:", [(d["key"], d["comment_id"]) for d in items[:3]])
a1, a2, a3 = items[0], items[1], items[2]
def act(par, status, post=None):
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,?,?,?,?,?)",
                  ("2099-01-01T00:00:00Z", "comment", "answer", json.dumps({"post_id": post or 1, "parent_id": par, "body": "b"}), "r", status))
act(a1["comment_id"], "sent"); act(a2["comment_id"], "queued")
for _ in range(3):
    inbox.mark_shown(st, inbox.pick(st, n_live=0, n_backlog=3)[1])
inbox.reconcile(st)
row = lambda k: dict(st.db.execute("SELECT status, shown_count FROM inbox_items WHERE key=?", (k,)).fetchone())
print("  answered one:", row(a1["key"]), "| queued one:", row(a2["key"]), "| ignored one:", row(a3["key"]))
print("  queued one hidden from the prompt:", a2["key"] not in [d["key"] for d in inbox.pending(st, "backlog")])
before = row(items[5]["key"])["shown_count"]
inbox.pick(st, n_live=0, n_backlog=10)  # picked, composer never returned: not marked
print("  shown count unchanged when the cycle cannot answer:", row(items[5]["key"])["shown_count"] == before)
pm = [d for d in inbox.pending(st, "backlog") if d["comment_id"] is None][0]
st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,?,?,?,?,?)",
              ("2099-01-01T00:00:00Z", "comment", "answer", json.dumps({"post_id": pm["post_id"], "parent_id": None, "body": "b"}), "r", "sent"))
inbox.reconcile(st); print("  post mention answered by a top-level comment:", row(pm["key"])["status"])
print("  for_prompt sample:", {k: v for k, v in inbox.for_prompt([pm])[0].items() if k in ("mention_id", "at", "age_days", "bucket")})
