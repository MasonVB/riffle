# ==========================================================================
# Three round-1 low findings: a reply being sent counts as sent (L3), a
# recent top-level comment answers a post mention (L5), and the changes
# walk keeps one row per id (L8).
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   L3: with a reply in flight (status `sending`), riffle sees the
#   comment as already replied to. L5: a mention on a post riffle
#   commented on 2 hours earlier is answered; 3 days earlier, still
#   pending. L8: a row served twice is collapsed to its latest copy, in
#   first-seen order, and a row without an id is kept.
#
# WHY IT EXISTS
#   L3: every duplicate check ignored `sending`, so a cycle overlapping
#   a dashboard send could propose the same reply. L5: such a mention
#   forced up to three wasted answer cycles. L8: re-served rows inflated
#   the counts riffle was shown.
#
# HOW IT WORKS
#   Argument 2 picks the case (L3, L5 or L8); each builds a small state
#   and calls the function under test.
#
# READING THE OUTPUT
#   One line per case, stating the result.
#
# RUNNING IT ON ITS OWN
#   python3 tests/inbox/test_inflight_sends_mention_window_and_duplicate
#   _rows_L3_L5_L8.py . L5
#
# CHANGELOG
#   2026-10-30  Written in the sandbox (tlow1.py) for L3, L5 and L8; its first
#               L5 run guessed a column name, fixed the same day.
#   2026-11-05  Moved into tests/inbox.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, time
repo, which = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent.state import State, utcnow
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
if which == "L3":
    from agent import cycle
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'comment','answer',?,'r','sending')", (utcnow(), json.dumps({"post_id": 4, "parent_id": 2, "body": "b"})))
    st.db.commit()
    print(f"  reply to comment 2 while one is 'sending': seen as already replied = {bool(cycle.replied_to(st, 2))}")
elif which == "L5":
    from agent import inbox
    inbox.ensure(st)
    now_ms = int(time.time() * 1000)
    for k, (post, created) in {"p1": (4100, now_ms), "p2": (4200, now_ms)}.items():
        st.db.execute("INSERT INTO inbox_items (key,source,buckets,comment_id,post_id,body,created_ms,first_seen,status,shown_count) VALUES (?,?,?,?,?,?,?,?,?,?)",
                      (k, "live", "mentions_of_you", None, post, "@riffle look", created, utcnow(), "pending", 0))
    two_h = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 2 * 3600))
    three_d = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 3 * 86400))
    for post, at in ((4100, two_h), (4200, three_d)):
        st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'comment','answer',?,'r','executed')", (at, json.dumps({"post_id": post, "body": "b"})))
    st.db.commit()
    inbox.reconcile(st)
    s = dict(st.db.execute("SELECT key, status FROM inbox_items").fetchall())
    print(f"  mention on a post riffle commented on 2h before: {s['p1']}; 3 days before: {s['p2']}")
elif which == "L8":
    from agent import cycle
    if hasattr(cycle, "_one_per_id"):
        rows = [{"id": 1, "v": "a"}, {"id": 2, "v": "b"}, {"id": 1, "v": "a2"}, {"x": "no id"}]
        print(f"  4 rows, id 1 served twice -> {cycle._one_per_id(rows)}")
    else:
        print("  (no de-duplication in this version)")
