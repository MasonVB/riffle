# ==========================================================================
# A mention riffle answered in September, imported into the inbox in
# October, is recognised as answered; a comment made before the mention
# existed is not.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   That reconcile compares answers with the time the mention was made,
#   not the time it was imported.
#
# WHY IT EXISTS
#   R4.5 of the earlier review: the backlog import stamped old mentions
#   with the import date, so earlier answers did not count and riffle
#   was asked to answer them again.
#
# HOW IT WORKS
#   Stores a September mention as if imported in October, adds a
#   September reply, reconciles; then the same with a reply dated before
#   the mention.
#
# READING THE OUTPUT
#   `answered` for the first case, `pending` for the second.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-24  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/inbox.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import inbox
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
sept_ms = 1789000000000           # 2026-09-09
inbox.store(st, [{"id": None, "mention_id": 77, "post_id": 4100, "body": "@riffle what do you think?",
                  "created_at": sept_ms, "bucket": "mentions_of_you"}], "backlog")    # first_seen = now (Oct)
def act(created, status="sent"):
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,?,?,?,?,?)",
                  (created, "comment", "answer", json.dumps({"post_id": 4100, "parent_id": None, "body": "b"}), "r", status))
    st.db.commit()
act("2026-09-10T08:00:00Z")      # answered in September, the day after the mention
inbox.reconcile(st)
print("  answered in September, imported in October ->", st.db.execute("SELECT status FROM inbox_items").fetchone()[0])
st.db.execute("DELETE FROM actions"); st.db.execute("UPDATE inbox_items SET status='pending'"); st.db.commit()
act("2026-09-01T08:00:00Z")      # a top-level comment BEFORE the mention existed: not an answer
inbox.reconcile(st)
print("  comment before the mention existed            ->", st.db.execute("SELECT status FROM inbox_items").fetchone()[0])
