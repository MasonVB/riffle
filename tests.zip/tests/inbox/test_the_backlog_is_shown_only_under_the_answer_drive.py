# ==========================================================================
# Old (backlog) inbox items are shown only when the cycle draws the
# `answer` drive, and showing them is counted.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For the drive given as argument 2: whether the backlog was shown,
#   and its shown count afterwards.
#
# WHY IT EXISTS
#   The earlier review: the two-month backlog would otherwise crowd
#   every cycle's prompt.
#
# HOW IT WORKS
#   Runs a real cycle with the drive forced, against a stub registry
#   whose inbox is the backlog only.
#
# READING THE OUTPUT
#   `drive NAME: backlog shown True|False, its shown count N`: True and
#   1 only for `answer`.
#
# RUNNING IT ON ITS OWN
#   python3
#   tests/inbox/test_the_backlog_is_shown_only_under_the_answer_drive.py
#   . answer
#
# CHANGELOG
#   2026-10-26  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/inbox.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, drv = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, inbox
from agent.state import State
me = json.load(open(__import__("os").environ["RIFFLE_ME_JSON"])); me["since_last_visit"]["comments_on_your_posts"] = []
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: drv
seen = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    seen["older_shown"] = "INBOX \u2014 OLDER" in user
    return json.dumps({"action": "noop", "payload": {"why": "nothing to do this cycle at all"}, "rationale": "nothing to do this cycle"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); inbox.ensure(st)
inbox.store(st, [{"id": 9001, "post_id": 4100, "body": "@riffle what about the receipts?", "created_at": 1789000000000, "bucket": "replies"}], "backlog")
st.note("backlog_imported", "x")
sys.argv = ["cycle", "--config", cp]
try: cycle.main()
except SystemExit: pass
n = sqlite3.connect(os.path.join(d, "state.sqlite")).execute("SELECT shown_count FROM inbox_items WHERE key='c9001'").fetchone()[0]
print(f"  drive {drv:10}: backlog shown {seen.get('older_shown')}, its shown count {n}")
