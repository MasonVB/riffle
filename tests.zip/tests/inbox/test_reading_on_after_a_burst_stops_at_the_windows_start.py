# ==========================================================================
# Reading on after a burst stops where the burst's window began: it never
# walks into the bucket's older history.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   With a 100-item burst and 200 older items behind it, only the 100
#   are stored, and none from before the window.
#
# WHY IT EXISTS
#   U1 (audit round 2): L18's read-on paged back with since=0, without a
#   lower bound, and would have stored a bucket's whole history
#   (in_threads_you_joined was never backlog-imported) as new messages.
#
# HOW IT WORKS
#   A fake registry that filters by the `since` it is sent, as the real
#   one does, and returns everything for since=0.
#
# READING THE OUTPUT
#   `stored 100, of them from before the window 0`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tu1.py) for U1; on the previous
#               version it stored 300, 200 of them old.
#   2026-11-05  Moved into tests/inbox.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile, json; sys.path.insert(0, sys.argv[1])
from agent import inbox
from agent.state import State
S = 1793000000000                                   # the window's start
PER = 5
items = [{"id": 900000 - i, "comment_id": 900000 - i, "post_id": 4, "body": f"item {i}",
          "created_at": S + 10 ** 6 - i * 1000} for i in range(100)]          # the burst, inside the window
items += [{"id": 800000 - i, "comment_id": 800000 - i, "post_id": 4, "body": f"old {i}",
           "created_at": S - 1000 - i * 1000} for i in range(200)]            # history, before it
class W:
    def me(self, since=None, before=None):
        lo = S if since is None else since                                   # no since = the last visit
        pool = [x for x in items if x["created_at"] >= lo]
        start = int(before[3:]) if before else 0
        page = pool[start:start + PER]
        nxt = f"tok{start + PER}" if start + PER < len(pool) else None
        return {"now": S + 2 * 10 ** 6, "since_last_visit": {"truncated": bool(nxt), "interval": {"since": lo},
                "in_threads_you_joined": page, "in_threads_you_joined_next_before": nxt}}
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite")); inbox.ensure(st)
log = lambda t, **k: None
rows, stats = inbox.rows_from_me(W().me())
rows += inbox.drain(W(), stats, log, buckets=("in_threads_you_joined",), state=st)
inbox.store(st, rows, "live")
for _ in range(12):
    inbox.resume(st, W(), log, buckets=("in_threads_you_joined",))
n = st.db.execute("SELECT COUNT(*) FROM inbox_items").fetchone()[0]
old = st.db.execute("SELECT COUNT(*) FROM inbox_items WHERE body LIKE 'old %'").fetchone()[0]
print(f"  100-item burst, 200 older items behind it: stored {n}, of them from before the window {old}")
