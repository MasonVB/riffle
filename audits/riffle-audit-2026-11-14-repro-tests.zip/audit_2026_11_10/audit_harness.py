"""Shared set-up for the 2026-11-10 audit reproductions. Same shape as the
suite's own send-check tests: one real cycle.main() against stand-ins."""
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
import sys, os, json, copy, tempfile, sqlite3, yaml


def setup(repo, autonomy=None, drive="answer", projects=None):
    sys.path.insert(0, repo)
    from agent import cycle, cortex, drives, project
    from agent.state import State
    me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
    env = {"sent": [], "prompts": [], "replies": [], "cycle": cycle, "cortex": cortex}

    class Stub:
        def __init__(self, *a, **k): pass
        def create_comment(self, post_id, body, parent_id=None):
            env["sent"].append(("comment", post_id, parent_id, body)); return {"comment_id": 500 + len(env["sent"]), "created_at": 1}
        def create_post(self, title, body, url=None):
            env["sent"].append(("post", title, body, url)); return {"post_id": 900 + len(env["sent"]), "created_at": 1}
        def seal(self, h, label=None, signature=None):
            env["sent"].append(("seal", h, label, bool(signature))); return {"seal_id": 1}
        def __getattr__(self, n):
            return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
    cycle.Reader = cycle.Writer = Stub
    cycle.do_witness = lambda *a, **k: None
    cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
    drives.pick_drive = lambda *a, **k: drive

    def complete(llm, system, user, schema=None, **k):
        if "Choose ONE action" not in user:
            return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
        env["prompts"].append((system, user))
        r = env["replies"].pop(0) if env["replies"] else {"action": "noop", "payload": {"why": "nothing to do"}, "rationale": "nothing to do this cycle"}
        return json.dumps(r)
    cortex.complete = complete
    d = tempfile.mkdtemp()
    cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
    cfg["data_dir"] = d
    cfg.setdefault("library", {})["root"] = os.path.join(d, "library")
    for k, v in (autonomy or {}).items():
        cfg["autonomy"][k] = v
    for k, v in (projects or {}).items():
        cfg["projects"][k] = v
    open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
    cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
    st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
    st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')"); st.db.commit()
    env.update(d=d, cp=cp, st=st, cfg=cfg, project=project)
    return env


def run(env, *replies, force=True):
    env["replies"] = list(replies)
    sys.argv = ["cycle", "--config", env["cp"]] + (["--force"] if force else [])
    try: env["cycle"].main()
    except SystemExit: pass
    db = sqlite3.connect(os.path.join(env["d"], "state.sqlite")); db.row_factory = sqlite3.Row
    c = db.execute("SELECT id, outcome, notes FROM cycles ORDER BY id DESC LIMIT 1").fetchone()
    a = db.execute("SELECT id, kind, status FROM actions ORDER BY id DESC LIMIT 1").fetchone()
    return (c["outcome"] if c else None), (dict(a) if a else None)
