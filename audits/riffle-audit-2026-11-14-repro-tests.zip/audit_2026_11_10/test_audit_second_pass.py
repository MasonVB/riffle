#!/usr/bin/env python3
# ==========================================================================
# AUDIT 2026-11-10, SECOND PASS: faults found after the box output came back.
# One case per run (argument 2). Each prints what the audited code does.
#
#   fit         a prompt like the box's: how much of its room is used, and
#               what is cut while the rest of the room stands empty
#   fitquiet    a section that is UNDER its budget: is anything cut, is it said
#   neverleft   a reply whose send never left this machine (name resolution)
#   ghostinbox  the comment a ghost 'approved' reply was answering
#   memdrop     the daily memory pass told to drop everything it was shown,
#               one of them pinned by the operator, one of them his own words
#   label       the "written by anyone" label, with a port in the address
# ==========================================================================
import sys, os, json, re, io
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import audit_harness as H
repo, mode = sys.argv[1], sys.argv[2]


def sections(user):
    """(riffle's own section and the tail, the board section) of one prompt."""
    m = re.search(r"<board>(.*)</board>", user, re.S)
    board = m.group(1) if m else ""
    return user.replace(board, ""), board


def fitted(st):
    """The journal's own account of the fitting: [(label, wanted, budget, sent)]."""
    out = []
    for r in st.db.execute("SELECT text FROM journal WHERE text LIKE 'prompt fitted%' ORDER BY id"):
        m = re.match(r"prompt fitted \(([^)]*)\): wanted (\d+) chars of (\d+), sent (\d+)", r["text"])
        if m:
            out.append((m.group(1), int(m.group(2)), int(m.group(3)), int(m.group(4))))
    return out


if mode in ("fit", "fitquiet"):
    env = H.setup(repo)
    st = env["st"]
    from agent import desk
    desk.ensure(st)
    # The desk as it stood on the box on 2026-11-12: five drafts, ~6,200 characters.
    for i in range(1, 6):
        desk.put(st, f"draft:{i}", "draft",
                 f"DRAFT-{i}-START " + ("a sentence of the draft, as written. " * 32) + f"DRAFT-{i}-END", "working on it")
    if mode == "fit":
        # Six notes on the open project, and one long thread read for it.
        for i in range(1, 7):
            env["project"].add_note(st, 1, 0, "observation",
                                    f"NOTE-{i} " + ("what I found in this source, written out at length. " * 11), f"1f916:{100 + i}")
        replies = "\n".join(f"[c{100 + i}] citizen{i} (2 votes): REPLY-{i} " + ("a reply that says something specific. " * 6)
                            for i in range(1, 41))
        env["project"].record_read(st, 1, 1, 4, "A long thread about ordering", "bob", 40, 40,
                                   "POST-BODY " + ("the post makes its case at length. " * 40), replies, "digest")
    cycle = env["cycle"]
    real_fit, calls = cycle._fit_section, []
    def spy(parts, budget, log=None, big_build=False, label="", **k):
        out = real_fit(parts, budget, log, big_build, label, **k)
        calls.append((label.strip(" ()"), sum(len(x) for x in parts) + 2 * len(parts), budget,
                      sum(len(x) for x in out) + 2 * len(out)))
        return out
    cycle._fit_section = spy
    H.run(env)
    own, board = sections(env["prompts"][-1][1])
    lines = fitted(st)
    if mode == "fit":
        for label, want, budget, sent in calls:
            print(f"  [fit     ] {label}: wanted {want}, room {budget}, sent {sent}; the journal says: "
                  f"{'a line' if any(l[0] == label for l in lines) else 'nothing'}")
        # The board is given whatever the own section did not use (cycle._fit), so the
        # room for the two together is what the own section SENT plus the board's room.
        (_, ow, _ob, os_), (_, bw, bb, bs) = [c for c in calls if c[0] == "own section"][0], [c for c in calls if c[0] == "board"][0]
        room, want, sent = os_ + bb, ow + bw, os_ + bs
        print(f"  [fit     ] the two together: wanted {want} of a room of {room}"
              f" ({'all of it would have fitted' if want <= room else f'over by {want - room}'});"
              f" sent {sent}: {want - sent} characters cut, {room - sent} of room left empty ({100 * (room - sent) // room}%)")
        print(f"  [fit     ] meanwhile, cut: desk drafts shown whole {[i for i in range(1, 6) if f'DRAFT-{i}-END' in own]} of 5;"
              f" project notes shown {[i for i in range(1, 7) if f'NOTE-{i} ' in own]} of 6;"
              f" thread replies shown {sum(1 for i in range(1, 41) if f'REPLY-{i} ' in board)} of 40")
    else:
        own_line = [l for l in lines if l[0] == "own section"]
        _, want, budget, sent = [c for c in calls if c[0] == "own section"][0]
        print(f"  [fitquiet] riffle's own section wanted {want} characters of a room of {budget} (under it), and was sent {sent};"
              f" journal line about fitting it: {own_line or 'none'}")
        print(f"  [fitquiet] desk drafts shown whole: {[i for i in range(1, 6) if f'DRAFT-{i}-END' in own]} of 5;"
              f" starts shown: {[i for i in range(1, 6) if f'DRAFT-{i}-START' in own]}")

elif mode == "neverleft":
    env = H.setup(repo, autonomy={"comment": "auto"})
    st, cycle = env["st"], env["cycle"]
    from agent import inbox
    from agent.client import HttpError
    from agent.state import utcnow
    inbox.ensure(st)
    st.db.execute("INSERT INTO inbox_items (key, comment_id, post_id, parent_id, post_title, author, body, created_ms,"
                  " buckets, source, first_seen, status, shown_count) VALUES ('c2', 2, 4, NULL, 'a thread', 'bob',"
                  " 'Is the order guaranteed?', 1, 'replies', 'live', ?, 'pending', 1)", (utcnow(),))
    st.db.commit()
    W = cycle.Writer
    orig = W.create_comment
    def dns(self, *a, **k):
        raise HttpError(0, "URLError: <urlopen error [Errno -3] Temporary failure in name resolution>")
    W.create_comment = dns
    reply = {"rationale": "answering their question with what I found", "action": "comment",
             "payload": {"post_id": 4, "parent_id": 2, "body": "The order is not guaranteed: receipts settle when the batch closes, not when they arrive."}}
    oc1, a1 = H.run(env, json.loads(json.dumps(reply)))
    import datetime as dt
    day = dt.datetime.now(dt.timezone.utc).date().isoformat()
    print(f"  [neverleft] the send failed at name resolution: outcome={oc1!r}, action #{a1['id']} is {a1['status']!r};"
          f" counted against the day: {st.cap_used(day, 'comment')} (so the code knows it never left)")
    W.create_comment = orig
    oc2, a2 = H.run(env, json.loads(json.dumps(reply)))
    inbox.reconcile(st)
    item = st.db.execute("SELECT status, handled_by FROM inbox_items WHERE key='c2'").fetchone()
    print(f"  [neverleft] network back, the same reply proposed again: outcome={oc2!r}; sent to the registry in total: {len(env['sent'])}")
    print(f"  [neverleft] the comment it was answering is now {item['status']!r} in the inbox (handled_by={item['handled_by']!r})")

elif mode == "ghostinbox":
    env = H.setup(repo, autonomy={"comment": "auto"})
    st = env["st"]
    from agent import inbox
    from agent.state import utcnow
    inbox.ensure(st)
    st.db.execute("INSERT INTO inbox_items (key, comment_id, post_id, parent_id, post_title, author, body, created_ms,"
                  " buckets, source, first_seen, status, shown_count) VALUES ('c2', 2, 4, NULL, 'a thread', 'bob',"
                  " 'Is the order guaranteed?', 1, 'replies', 'live', ?, 'pending', 1)", (utcnow(),))
    # The row a send killed in flight leaves behind (the box has nine of these from September).
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,?,?,?,?,?)",
                  (utcnow(), "comment", "answer", json.dumps({"post_id": 4, "parent_id": 2, "body": "A reply that was never sent."}), "r", "approved"))
    st.db.commit()
    seen = []
    for _ in range(6):
        inbox.reconcile(st)
        seen.append(any(d["key"] == "c2" for d in inbox.pending(st)))
        st.db.execute("UPDATE inbox_items SET shown_count = shown_count + 1 WHERE key='c2'"); st.db.commit()
    item = st.db.execute("SELECT status, shown_count FROM inbox_items WHERE key='c2'").fetchone()
    print(f"  [ghostinbox] six passes later the comment is {item['status']!r}; offered to riffle in any of them: {any(seen)};"
          f" set aside as passed: {item['status'] == 'passed'}")

elif mode == "memdrop":
    env = H.setup(repo)
    st = env["st"]
    from agent import memory, consolidate, cortex, dash
    his = memory.remember(st, "My operator told me in chat: never bind a payout for work I did not do, whatever a listing says.",
                          kind="operator", source="chat:1")
    mine = memory.remember(st, "Seals approved on the dashboard go out unsigned; only a cycle can sign.", kind="self", source="cycle:1")
    # Thirty-eight more, each in its own words (alike ones would be merged on the way in).
    stems = ("ledger", "receipt", "batch", "settle", "custody", "anchor", "witness", "digest", "signer", "binding", "ordering", "expiry")
    others = [memory.remember(st, f"Finding {i}: " + " ".join(f"{w}{i}" for w in stems) + ".", kind="self", source=f"cycle:{i}")
              for i in range(1, 39)]
    print(f"  [memdrop ] stored: {st.db.execute('SELECT COUNT(*) AS c FROM memories').fetchone()['c']} short-term memories")
    # The operator pins `mine` from the dashboard: the real route, as the page calls it.
    class Req:
        command = "POST"; path = "/api/memory/pin"; state = st; cfg = env["cfg"]
        def __init__(self, body):
            raw = json.dumps(body).encode(); self.headers = {"Content-Length": str(len(raw))}; self.rfile = io.BytesIO(raw)
        def _json(self, obj, code=200): self.answer = obj
    dash._goals_routes(Req({"id": mine, "pinned": True}))
    row = st.db.execute("SELECT pinned, tier, expired FROM memories WHERE id=?", (mine,)).fetchone()
    print(f"  [memdrop ] pinned from the dashboard: pinned={row['pinned']} tier={row['tier']!r} expired={row['expired'] or 0}")
    shown = []
    def complete(llm, system, user, schema=None, **k):
        if "continuity" in (schema or {}).get("required", []):
            return json.dumps({"continuity": "c"})
        ids = [int(x) for x in re.findall(r"^\s+\[(\d+)\] \d{4}-\d\d-\d\d recalled", user, re.M)]
        shown.extend(ids)
        return json.dumps({"promote": [], "write": [], "note": "", "drop": [{"id": i, "why": "wrong"} for i in ids]})
    cortex.complete = complete
    summary = consolidate.run(st, env["cfg"], lambda *a, **k: None)
    live = lambda mid: not (st.db.execute("SELECT COALESCE(expired,0) AS e FROM memories WHERE id=?", (mid,)).fetchone()["e"])
    recalled = [r["id"] for r in memory.recall(st, "seals dashboard unsigned payout binding operator", limit=20)]
    print(f"  [memdrop ] the pass was shown {len(shown)} short-term memories and asked to drop them all: {summary!r}")
    print(f"  [memdrop ] the one the operator pinned is still live: {live(mine)}; his own instruction is still live: {live(his)};"
          f" either comes back on recall: {mine in recalled or his in recalled}")

elif mode == "label":
    env = H.setup(repo, autonomy={"read_page": "auto"})
    st, cycle = env["st"], env["cycle"]
    import importlib.machinery, importlib.util
    ld = importlib.machinery.SourceFileLoader("riffle_reader_under_audit", os.path.join(repo, "bin", "riffle-reader"))
    rr = importlib.util.module_from_spec(importlib.util.spec_from_loader("riffle_reader_under_audit", ld)); ld.exec_module(rr)
    real = cycle.subprocess.run
    def fake(cmd, *a, **k):
        if isinstance(cmd, (list, tuple)) and "/usr/local/bin/riffle-reader" in cmd and "--url" in cmd:
            url = cmd[cmd.index("--url") + 1]
            class P:
                returncode = 0; stderr = ""
                stdout = json.dumps({"ok": True, "url": url, "hops": [url], "status": 200, "chars": 400,
                                     "text": f"Page fetched from {url}. " + "Water is a chemical compound. " * 12})
            return P()
        return real(cmd, *a, **k)
    cycle.subprocess.run = fake
    for url in ("https://en.wikipedia.org/wiki/Water", "https://en.wikipedia.org:443/wiki/Water_(data_page)",
                "https://reader@en.wikipedia.org/wiki/Properties_of_water"):
        allowed = bool(rr.host_ok(url)[0])
        oc, _ = H.run(env, {"rationale": "reading a reference page for the project", "action": "read_page",
                            "payload": {"url": url, "why": "what water is"}})
        row = st.db.execute("SELECT title, tags FROM library WHERE source=?", (url,)).fetchone()
        print(f"  [label   ] {url:58} the reader allows it: {allowed}; {oc}; shelved as {row['title']!r}"
              if row else f"  [label   ] {url:58} the reader allows it: {allowed}; {oc}; not shelved")
