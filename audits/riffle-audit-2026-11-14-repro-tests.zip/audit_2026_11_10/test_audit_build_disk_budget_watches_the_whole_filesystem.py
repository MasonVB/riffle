#!/usr/bin/env python3
# ==========================================================================
# AUDIT 2026-11-10, SECOND PASS: what riffle-build's disk budget measures.
#
# riffle-build stops a build that "wrote too much to disk". It decides that
# from the FREE SPACE OF THE WHOLE FILESYSTEM (shutil.disk_usage(BUILD_ROOT)
# before the build, and again while it runs and after), not from the size of
# the build's own directory. Anything else on that disk moves the reading.
#
#   masked      the suite's own 120 MB flood against a 50 MB budget, while
#               something else on the disk frees 300 MB: is the flood seen?
#   falsealarm  a build that writes nothing, while something else on the
#               disk writes 120 MB: what is riffle told about its build?
#
# Built like the suite's own test of the same helper
# (build/test_a_disk_flood_that_finishes_between_checks_is_still_caught.py):
# a test copy of bin/riffle-build with its paths pointed into $RIFFLE_TMP, run
# under the stand-in systemd-run. The running once-a-second check is left ON.
# Run with:  PATH="$RIFFLE_TESTS/lib/stand_in_systemd:$PATH" python3 <this> bin/riffle-build masked
# ==========================================================================
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
import importlib.machinery, importlib.util, io, json, os, sys, contextlib, threading, pwd
src, mode = sys.argv[1], sys.argv[2]
tmp = os.environ["RIFFLE_TMP"]
root = os.path.join(tmp, f"riffle-build-audit-{mode}")
os.makedirs(root, exist_ok=True)
code = open(src).read()
code = code.replace('BUILD_ROOT = "/var/lib/riffle-build"', f'BUILD_ROOT = {root!r}', 1)
code = code.replace("DISK_BUDGET = 2 * 1024 ** 3", "DISK_BUDGET = 50 * 1024 ** 2", 1)
code = code.replace('RUN_USER = "riffle-build"', f'RUN_USER = {pwd.getpwuid(os.getuid()).pw_name!r}', 1)
code = code.replace("    if os.geteuid() != 0:", "    if False:  # test copy: runs as whoever runs the tests", 1)
copy = os.path.join(tmp, f"riffle_build_audit_{mode}.py")
open(copy, "w").write(code)
ld = importlib.machinery.SourceFileLoader("rb_audit", copy)
rb = importlib.util.module_from_spec(importlib.util.spec_from_loader("rb_audit", ld))
ld.exec_module(rb)

MB = 1048576
elsewhere = os.path.join(tmp, f"someone-elses-file-{mode}.bin")     # same filesystem, NOT the build's directory


def write_mb(path, n):
    with open(path, "wb") as f:
        for _ in range(n):
            f.write(os.urandom(MB))
        f.flush(); os.fsync(f.fileno())


if mode == "masked":
    write_mb(elsewhere, 300)                                         # on the disk before the build starts
    build = ("import os, time\ntime.sleep(2.5)\nwith open('big.bin','wb') as f:\n    for _ in range(120):\n"
             "        f.write(os.urandom(1048576)); f.flush(); os.fsync(f.fileno())\nprint('wrote 120 MB')\n")
    other = threading.Timer(0.8, lambda: os.remove(elsewhere))      # e.g. a log rotated, a download deleted
else:
    build = "import time\ntime.sleep(6)\nprint('wrote nothing at all')\n"
    other = threading.Timer(0.8, lambda: write_mb(elsewhere, 120))  # e.g. a model download, the journal, a backup

sys.stdin = io.StringIO(json.dumps({"run_id": "c301", "entry": "main.py", "files": {"main.py": build}}))
sys.argv = ["riffle-build"]
out = io.StringIO()
other.start()
with contextlib.redirect_stdout(out):
    try:
        rb.main()
    except SystemExit:
        pass
other.join()
d = json.loads(out.getvalue().strip().splitlines()[-1])
left = os.path.join(root, "c301")
if mode == "masked":
    print(f"  [masked    ] a 120 MB flood against a 50 MB budget, while 300 MB was freed elsewhere on the disk:"
          f" ok={d['ok']} stopped_for_disk={d['stopped_for_disk']} | the build's own output: {str(d.get('stdout') or '').strip()[-40:]!r}")
else:
    said = " ".join(str(d.get("stderr") or "").split())[-150:]
    print(f"  [falsealarm] a build that wrote nothing, while 120 MB was written elsewhere on the disk:"
          f" ok={d['ok']} stopped_for_disk={d['stopped_for_disk']} | directory kept: {os.path.isdir(left)}")
    print(f"  [falsealarm] what riffle is told: {said!r}")
if os.path.exists(elsewhere):
    os.remove(elsewhere)
