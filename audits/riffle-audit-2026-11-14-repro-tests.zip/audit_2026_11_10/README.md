# Audit 2026-11-10: reproductions

29 cases, written in the suite's own style. Each runs the real code (most run one
real `cycle.main()` against stand-ins) and prints what it does. On commit
39a3a5e every line shows a fault; `output_on_39a3a5e.txt` is that output.

The first 21 came with the first report (`AUDIT-2026-11-10.md`). The last 8 were
added with the second (`AUDIT-2026-11-14-second-pass.md`):

    test_audit_second_pass.py                                        fit, fitquiet, neverleft, ghostinbox, memdrop, label
    test_audit_build_disk_budget_watches_the_whole_filesystem.py     masked, falsealarm

To run them:

1. Unzip `tests.zip` outside the checkout, as the suite's README says.
2. Copy this folder into it as `tests/audit_2026_11_10/`.
3. Append `list_of_tests_additions.txt` to `tests/list_of_tests.txt`.
4. `ONLY='^audit' bash tests/run_all.sh /path/to/riffle`

They are not in `expected_output.txt`: that file records correct behaviour, and
these record faults. As each is fixed, its line should change (for the first
eight, from `SENT to the square` to `not sent`); record the new output then.

`audit_harness.py` is shared set-up. It loads the suite's safety net first, so
these cannot touch the real riffle either.

Two things to know before running them on the box:

- The two `audit build disk` cases write and delete up to 300 MB under the
  run's own scratch directory. They measure exactly the thing they are about
  (free space on the disk), so run them when nothing else is writing heavily.
- Like the suite itself, the cases leave their temporary directories in `/tmp`
  (the suite's runner deletes only its own scratch directory; see the report).
