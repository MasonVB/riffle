#!/usr/bin/env python3
# ==========================================================================
# AUDIT 2026-11-10: the daily memory pass keeps a sqlite write open while it
# waits for the composer to write the continuity note. Until that call
# returns, nothing else can write: a chat message, an approval, a telemetry
# sample. Prints whether a second writer gets through during the call.
# ==========================================================================
import sys, os, json, time, threading, sqlite3
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import audit_harness as H
repo = sys.argv[1]
env = H.setup(repo)
from agent import memory, consolidate, cortex
st = env["st"]
mid = memory.remember(st, "The witness walk needs the saved mark and its index together, or a grown chain reads as a rewrite.", kind="self", source="cycle:1")
in_call = threading.Event(); result = {}
def complete(llm, system, user, schema=None, **k):
    if "continuity" in (schema or {}).get("required", []):
        in_call.set(); time.sleep(4)            # the composer, writing the note (minutes on the box)
        return json.dumps({"continuity": "still working on the witness tooling"})
    return json.dumps({"promote": [{"id": mid, "why": "worth keeping"}], "write": [], "drop": [], "note": ""})
cortex.complete = complete
t = threading.Thread(target=lambda: consolidate.run(st, env["cfg"], lambda *a, **k: None)); t.start()
in_call.wait(20)
other = sqlite3.connect(os.path.join(env["d"], "state.sqlite"), timeout=1.5)     # the dashboard, say
try:
    other.execute("INSERT INTO journal (ts, level, text) VALUES ('2026-11-10T09:00:00Z', 'info', 'a chat message arrives')")
    other.commit(); result["second writer"] = "wrote"
except sqlite3.OperationalError as e:
    result["second writer"] = f"REFUSED: {e}"
t.join()
print(f"  while the continuity note was being written, a second writer: {result['second writer']}")
