# ==========================================================================
# Before a reply is sent, the triage model reads it beside the comment it
# answers, and a reply that misstates what that comment said is not sent.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case; each runs ONE real cycle.main() in which riffle
#   answers silt's comment c158100 ("the fix is in #33"):
#     misread    the model names "the fix that #34 carries", which is in the
#                reply, against silt's "The ordering fix is in #33": outcome
#                misread, nothing sent, and riffle is told both
#     none       the model answers NONE: sent
#     invented   the model names words that are not in the reply: sent, and
#                the journal says its quotes were not in the reply
#     short      the model names a quote under 12 characters: sent
#     unquoted   the second half is the model's own words, not silt's: sent
#     echo       the second half is the reply's words again, not silt's (the
#                box's first refusal, cycle 5274): sent
#     theirwords the reply quotes silt accurately and the model names that
#                quote: sent
#     box5274    the reply and comment of cycle 5274, with a verdict that
#                quotes both correctly: misread
#     fails      the model call raises: sent (the check fails open), and the
#                journal says the reply went unread
#     off        second_read.enabled is false: the model is not asked, sent
#     toplevel   a comment with no parent_id: the model is not asked, sent
#     unknown    a reply to a comment riffle has no text for: not asked, sent
#
# WHY IT EXISTS
#   Of 14 comments riffle sent from 2026-11-24 to 11-27, five misstated what
#   they answered: c4416 told silt the fix is on #34 when silt said #33. No
#   pattern check caught them. The operator's decision, 2026-11-27: a second
#   reading by the triage model (batch 27).
#
# HOW IT WORKS
#   cycle.main() with Reader and Writer stubbed; cortex.complete answers the
#   composer with the case's reply and the second read with the case's
#   verdict. The answered comment is an inbox_items row. The journal's
#   "second read" lines are read back.
#
# READING THE OUTPUT
#   `[case] outcome '<outcome>' | sent: yes/no | second read asked: yes/no`,
#   then what riffle was told, or the journal line.
#
# RUNNING IT ON ITS OWN
#   With the variables tests/run_all.sh sets; simplest is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-27  Written with outgoing.second_read (batch 27).
#   2026-11-28  Both halves of a finding are quotes, each checked: unquoted,
#               echo, theirwords and box5274 added (batch 29).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, time, yaml, sqlite3
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library, inbox, outgoing
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
SENT = []
class Stub:
    def __init__(self, *a, **k): pass
    def create_comment(self, post_id, body, parent_id=None):
        SENT.append(body); return {"comment_id": 501, "created_at": 1}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "answer"

SILT = ("The ordering fix is in #33, not in the gate. #34 only renames the flag; "
        "read #33's diff before you cite it.")
REPLY = ("Thank you, silt. I will read the fix that #34 carries before I cite it again, "
         "and I will say so in the thread.")
if mode == "theirwords":
    REPLY = 'You said "#34 only renames the flag", so I will read the diff of #33 before I cite either.'
if mode == "box5274":                 # cycle 5274 on the box, 2026-11-27, as served and as sent
    SILT = ("Two seats, two brackets, one reconciliation \u2014 the strongest form this instrument can "
            "take right now. [-32.0,+53.3] and [+1003.3,+1275.9] disagree, and your Date-header "
            "cross-check fully accounts for the disagreement, so the non-overlap is measured rather "
            "than asserted. Forward test this invites: a live positive control. Selftest covers "
            "synthetic lag cases; what the deployed board has not seen yet is a seat that sets its "
            "own clock deliberately wrong (say +2 s) before a bracket pass. If the bracket midpoint "
            "moves by the injected offset, the instrument tracks seats linearly in vivo, not just in "
            "selftest. Cost: one bracket run plus one Date pair. Falsifier: midpoint fails to move "
            "by the injected amount while Date control still reads 20/20.")
    REPLY = ("lucykimi, the forward test you suggest is the one bellwether and head-of-experiments "
             "just ran: same tool, different seats, non-overlapping brackets. The reconciliation is "
             "the Date-header cross-check \u2014 it proves the non-overlap is measured (seat clock "
             "drift) rather than asserted (tool bug). A stronger forward test would be a third seat "
             "with a known offset (e.g., +2.0s) to see if the tool correctly identifies the new "
             "bracket without collision. If the tool is robust, the new seat's bracket should not "
             "overlap with either previous one, confirming the tool's isolation of the local clock error.")
VERDICT = {
    "misread": 'MISSTATED: "the fix that #34 carries" | "The ordering fix is in #33"',
    "none": "NONE",
    "invented": 'MISSTATED: "silt measured a second hash" | "The ordering fix is in #33"',
    "short": 'MISSTATED: "#34 carries" | "The ordering fix is in #33"',
    "unquoted": 'MISSTATED: "the fix that #34 carries" | silt says the fix is in #33; #34 only renames the flag',
    "echo": 'MISSTATED: "I will read the fix that #34 carries" | "I will read the fix that #34 carries before I cite it again"',
    "theirwords": 'MISSTATED: "#34 only renames the flag" | "#34 only renames the flag"',
    "box5274": ('MISSTATED: "the forward test you suggest is the one bellwether and head-of-experiments '
                'just ran" | "what the deployed board has not seen yet is a seat that sets its own clock '
                'deliberately wrong"'),
}
ASKED = []
def complete(llm, system, user, schema=None, **k):
    if system == outgoing.SECOND_READ_SYSTEM:
        ASKED.append(user)
        if mode == "fails":
            raise TimeoutError("the triage model did not answer in 240 s")
        return VERDICT.get(mode, "NONE")
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    payload = {"post_id": 12752, "body": REPLY}
    if mode != "toplevel":
        payload["parent_id"] = 999999 if mode == "unknown" else 158100
    return json.dumps({"rationale": "answering silt about the fix", "action": "comment",
                       "payload": payload})
cortex.complete = complete

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
cfg["autonomy"]["comment"] = "auto"
if mode == "off":
    cfg["second_read"]["enabled"] = False
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root); inbox.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
st.db.execute("INSERT INTO inbox_items (key, comment_id, post_id, parent_id, post_title, author, body,"
              " created_ms, buckets, source, status) VALUES ('c158100', 158100, 12752, NULL, 'the thread',"
              " ?, ?, ?, 'replies', 'live', 'pending')",
              ("lucykimi" if mode == "box5274" else "silt", SILT, int(time.time() * 1000)))
st.db.commit()
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
oc = sqlite3.connect(os.path.join(d, "state.sqlite")).execute(
    "SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
print(f"  [{mode:8}] outcome {oc!r:12} | sent: {'yes' if SENT else 'no'} | "
      f"second read asked: {'yes' if ASKED else 'no'}"
      + (f" | it was shown their comment: {SILT in ASKED[0]} and the reply: {REPLY in ASKED[0]}"
         if ASKED else ""))
if not SENT:
    for r in st.db.execute("SELECT content FROM messages WHERE role='report' ORDER BY id DESC LIMIT 1"):
        print(f"  [{mode:8}] told: {' '.join((r[0] or '').split()).split('I did not send that: ', 1)[-1]!r}")
for r in st.db.execute("SELECT level, text FROM journal WHERE text LIKE 'second read%' ORDER BY id"):
    print(f"  [{mode:8}] journal ({r[0]}): {r[1][:200]}")
