# ==========================================================================
# Before a reply is sent, the triage model reads it beside the comment it
# answers, and a reply that misstates what that comment said is not sent.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case; each runs ONE real cycle.main() in which riffle
#   answers silt's comment c158100 ("the fix is in #33"):
#     misread    the model names "the fix that #34 carries", which is in the
#                reply: outcome misread, nothing sent, and riffle is told the
#                words and what silt said
#     none       the model answers NONE: sent
#     invented   the model names words that are not in the reply: sent, and
#                the journal says its quotes were not in the reply
#     short      the model names a quote under 12 characters: sent
#     fails      the model call raises: sent (the check fails open), and the
#                journal says the reply went unread
#     off        second_read.enabled is false: the model is not asked, sent
#     toplevel   a comment with no parent_id: the model is not asked, sent
#     unknown    a reply to a comment riffle has no text for: not asked, sent
#
# WHY IT EXISTS
#   Of 14 comments riffle sent from 2026-11-24 to 11-27, five misstated what
#   they answered: c4416 told silt the fix is on #34 when silt said #33. No
#   pattern check caught them. The operator's decision, 2026-11-27: a second
#   reading by the triage model (batch 27).
#
# HOW IT WORKS
#   cycle.main() with Reader and Writer stubbed; cortex.complete answers the
#   composer with the case's reply and the second read with the case's
#   verdict. The answered comment is an inbox_items row. The journal's
#   "second read" lines are read back.
#
# READING THE OUTPUT
#   `[case] outcome '<outcome>' | sent: yes/no | second read asked: yes/no`,
#   then what riffle was told, or the journal line.
#
# RUNNING IT ON ITS OWN
#   With the variables tests/run_all.sh sets; simplest is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-27  Written with outgoing.second_read (batch 27).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, time, yaml, sqlite3
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library, inbox, outgoing
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
SENT = []
class Stub:
    def __init__(self, *a, **k): pass
    def create_comment(self, post_id, body, parent_id=None):
        SENT.append(body); return {"comment_id": 501, "created_at": 1}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "answer"

SILT = ("The ordering fix is in #33, not in the gate. #34 only renames the flag; "
        "read #33's diff before you cite it.")
REPLY = ("Thank you, silt. I will read the fix that #34 carries before I cite it again, "
         "and I will say so in the thread.")
VERDICT = {
    "misread": 'MISSTATED: "the fix that #34 carries" | silt says the fix is in #33; #34 only renames the flag',
    "none": "NONE",
    "invented": 'MISSTATED: "silt measured a second hash" | silt measured nothing',
    "short": 'MISSTATED: "#34 carries" | the fix is in #33',
}
ASKED = []
def complete(llm, system, user, schema=None, **k):
    if system == outgoing.SECOND_READ_SYSTEM:
        ASKED.append(user)
        if mode == "fails":
            raise TimeoutError("the triage model did not answer in 240 s")
        return VERDICT.get(mode, "NONE")
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    payload = {"post_id": 12752, "body": REPLY}
    if mode != "toplevel":
        payload["parent_id"] = 999999 if mode == "unknown" else 158100
    return json.dumps({"rationale": "answering silt about the fix", "action": "comment",
                       "payload": payload})
cortex.complete = complete

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
cfg["autonomy"]["comment"] = "auto"
if mode == "off":
    cfg["second_read"]["enabled"] = False
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root); inbox.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
st.db.execute("INSERT INTO inbox_items (key, comment_id, post_id, parent_id, post_title, author, body,"
              " created_ms, buckets, source, status) VALUES ('c158100', 158100, 12752, NULL, 'the thread',"
              " 'silt', ?, ?, 'replies', 'live', 'pending')", (SILT, int(time.time() * 1000)))
st.db.commit()
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
oc = sqlite3.connect(os.path.join(d, "state.sqlite")).execute(
    "SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
print(f"  [{mode:8}] outcome {oc!r:12} | sent: {'yes' if SENT else 'no'} | "
      f"second read asked: {'yes' if ASKED else 'no'}"
      + (f" | it was shown silt's comment: {SILT in ASKED[0]} and the reply: {REPLY in ASKED[0]}"
         if ASKED else ""))
if not SENT:
    for r in st.db.execute("SELECT content FROM messages WHERE role='report' ORDER BY id DESC LIMIT 1"):
        print(f"  [{mode:8}] told: {' '.join((r[0] or '').split()).split('I did not send that: ', 1)[-1]!r}")
for r in st.db.execute("SELECT level, text FROM journal WHERE text LIKE 'second read%' ORDER BY id"):
    print(f"  [{mode:8}] journal ({r[0]}): {r[1][:200]}")
