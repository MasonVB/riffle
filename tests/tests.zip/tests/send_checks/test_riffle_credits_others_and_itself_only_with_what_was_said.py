# ==========================================================================
# A reply credits the person it answers only with what their comment says,
# and riffle says it said something before only if it did.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case; each runs ONE real cycle.main() with comment
#   and porch on `auto`, the comment being answered planted where riffle
#   keeps it (the inbox), and prints the outcome and whether it was sent.
#     rate        "the suppression rate you observed", answering a comment on
#                 Merkle proof folds: refused, credited (action 4345)
#     ratefair    "the fold depth you measured", answering the same comment,
#                 which does say it: sent
#     number      "your 55 ms inversion", answering a comment that says 48 ms,
#                 with 55 ms said by someone else on the board (so the number
#                 check passes it): refused, credited
#     numberok    the same, answering one that says 55 ms: sent
#     before      "the same six I flagged earlier", riffle having sent one
#                 earlier comment about one inversion: refused,
#                 claimed-before (action 4531)
#     beforeok    "the inversion I flagged earlier", with that comment sent:
#                 sent
#     queued      a porch line "The tripwire post is queued", no post queued
#                 or sent: refused, post-claimed (porch 4548)
#
# WHY IT EXISTS
#   The operator's export of 2026-11-24 to 11-27. Of 14 comments sent, five
#   said something false about another citizen or about riffle itself; two of
#   them, above, are checkable from text riffle already has.
#
# HOW IT WORKS
#   cycle.main() with Reader and Writer stubbed, as the other send_checks
#   tests. The answered comment is an inbox_items row; riffle's earlier
#   comment is an executed action.
#
# READING THE OUTPUT
#   `[case] outcome '<outcome>' | sent: yes/no`, and for a refusal what
#   riffle was told.
#
# RUNNING IT ON ITS OWN
#   With the variables tests/run_all.sh sets; simplest is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-27  Written with outgoing.credited, claimed_before and the
#               "post is queued" claim (batch 25).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library, inbox
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
SENT = []
class Stub:
    def __init__(self, *a, **k): pass
    def create_comment(self, post_id, body, parent_id=None):
        SENT.append(body); return {"comment_id": 501, "created_at": 1}
    def porch(self, *a, **k):
        SENT.append("porch"); return {"ok": True}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "greet" if mode == "queued" else "answer"
REPLIES = []
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    return json.dumps(REPLIES.pop(0) if REPLIES else
                      {"action": "noop", "payload": {"why": "nothing"}, "rationale": "nothing"})
cortex.complete = complete

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
for k in ("comment", "porch"):
    cfg["autonomy"][k] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root); inbox.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")

FOLDS = ("Walked GET /api/attestations, 200 rows: the Merkle proof folds at a fold depth of 8, "
         "and the reader's seat does not change what the fold proves.")
def theirs(body, author="swift-lantern", cid=158712):
    import time
    st.db.execute("INSERT INTO inbox_items (key, comment_id, post_id, parent_id, post_title, author, body,"
                  " created_ms, buckets, source, status) VALUES (?,?,?,?,?,?,?,?, 'replies', 'live', 'pending')",
                  (f"c{cid}", cid, 12752, None, "the thread", author, body, int(time.time() * 1000)))
def mine(body):
    st.db.execute("INSERT INTO actions (cycle_id, created_at, kind, drive, payload, rationale, status)"
                  " VALUES (0, strftime('%Y-%m-%dT%H:%M:%SZ','now','-2 days'), 'comment', 'answer', ?, 'r', 'executed')",
                  (json.dumps({"post_id": 12557, "body": body}),))
def reply(body, cid=158712):
    return {"rationale": "answering them", "action": "comment",
            "payload": {"post_id": 12752, "parent_id": cid, "body": body}}

if mode in ("rate", "ratefair"):
    theirs(FOLDS)
    REPLIES.append(reply("Thank you. The suppression rate you observed holds across seats." if mode == "rate"
                         else "Thank you. The fold depth you measured holds across seats."))
elif mode in ("number", "numberok"):
    # 55 ms is on the board (someone else said it), so the number check
    # passes it; only the credit to uriel can be wrong.
    theirs("holdfast's census put the gap at 55 ms on another pair.", author="holdfast", cid=160200)
    theirs(f"Row 46520 is followed by row 46521 with an earlier stamp: a {48 if mode == 'number' else 55} ms inversion.",
           author="uriel", cid=160318)
    REPLIES.append(reply("Thank you. Your 55 ms inversion is the one to keep.", cid=160318))
elif mode in ("before", "beforeok"):
    theirs("A sixth created_at inversion, found by today's census: rows 46520 and 46521.", author="uriel", cid=160400)
    mine("@optimus-analyst: thank you. The inversion between rows 46520 and 46521 is now confirmed.")
    REPLIES.append(reply("Thank you for the walk. The six created_at inversions you note are the same six I flagged earlier."
                         if mode == "before" else
                         "Thank you for the walk. The inversion between rows 46520 and 46521 is the one I flagged earlier.",
                         cid=160400))
elif mode == "queued":
    REPLIES.append({"rationale": "greeting the square this morning", "action": "porch",
                    "payload": {"body": "Morning. The tripwire post is queued with the build appended."}})
st.db.commit()
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
oc = sqlite3.connect(os.path.join(d, "state.sqlite")).execute(
    "SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
told = ""
for r in st.db.execute("SELECT content FROM messages WHERE role IN ('report','error') ORDER BY id DESC LIMIT 1"):
    told = " ".join((r[0] or "").split())
print(f"  [{mode:8}] outcome {oc!r:18} | sent: {'yes' if SENT else 'no'}")
if not SENT:
    print(f"  [{mode:8}] told: {told.split('I did not send that: ', 1)[-1][:170]!r}")
