# ==========================================================================
# The action gate refuses a disabled action, an unknown field, a missing
# rationale and a spent daily cap; and riffle may move a goal's weight only
# a step at a time, within a daily budget.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     gate    drives.gate on: a post when `post: never`; a comment with a
#             field the schema does not know; a porch line with a nine-
#             character rationale; and the same three made right, passing.
#             drives.caps_ok with today's comment cap reached, and one short.
#     weight  goals.set_weight as riffle (actor `agent`): a step over the
#             one-step limit; three small steps, the third over the daily
#             budget; and the same move by the operator (`you`), allowed.
#
# WHY IT EXISTS
#   Audit 2026-11-14, section 7.1: each of these could be switched off and
#   all 210 tests still passed. The gate's `never`, its unknown-field check,
#   its rationale rule and its daily cap; and the limit on how far riffle
#   may move a goal.
#
# HOW IT WORKS
#   The real functions on config.example.yaml and a fresh store.
#
# READING THE OUTPUT
#   One line per call: what it was, and `passed` or `refused: <reason>`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_the_gate_refuses_what_it_must_and_riffle_moves_a_goal_only_so_far.py . gate
#
# CHANGELOG
#   2026-11-18  Written for the audit's section 7.1 (batch 11).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, copy, tempfile, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import drives, goals
from agent.state import State, utcnow

cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = tempfile.mkdtemp()
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))


def say(what, fn):
    try:
        r = fn()
        out = "passed" if r is None or (isinstance(r, tuple) and r[0] is not False) else f"refused: {r[1]}"
    except Exception as e:
        out = f"refused: {str(e)[:90]}"
    out = __import__("re").sub(r"20\d\d-\d\d-\d\d", "<today>", out)   # the cap names the day
    print(f"  [{mode:6}] {what:44} {out}")


if mode == "gate":
    off = copy.deepcopy(cfg); off["autonomy"]["post"] = "never"
    on = copy.deepcopy(cfg); on["autonomy"]["post"] = "queue"
    POST = {"action": "post", "rationale": "the project is ready and this is what it found",
            "payload": {"title": "What a seal promises", "body": "A seal says a hash existed at a time, nothing more."}}
    say("a post, with post: never", lambda: drives.gate(POST, "contribute", off) and None)
    say("the same post, with post: queue", lambda: drives.gate(POST, "contribute", on) and None)
    say("a comment with a field the schema lacks", lambda: drives.gate(
        {"action": "comment", "rationale": "answering the thread I read",
         "payload": {"post_id": 4, "body": "The receipts settle per batch.", "as_operator": True}}, "answer", on) and None)
    say("the same comment without it", lambda: drives.gate(
        {"action": "comment", "rationale": "answering the thread I read",
         "payload": {"post_id": 4, "body": "The receipts settle per batch."}}, "answer", on) and None)
    say("a porch line with a nine-character rationale", lambda: drives.gate(
        {"action": "porch", "rationale": "just once",
         "payload": {"body": "Reading the docket this morning."}}, "greet", on) and None)
    say("the same with a real rationale", lambda: drives.gate(
        {"action": "porch", "rationale": "saying where I am today",
         "payload": {"body": "Reading the docket this morning."}}, "greet", on) and None)
    day = utcnow()[:10]
    lim = cfg["caps"].get("comment")
    for _ in range(lim - 1):
        st.cap_bump(day, "comment")
    say(f"caps_ok with {lim - 1} of {lim} comments used", lambda: drives.caps_ok(st, day, "comment", cfg))
    st.cap_bump(day, "comment")
    say(f"caps_ok with {lim} of {lim} comments used", lambda: drives.caps_ok(st, day, "comment", cfg))
else:
    goals.add(st, cfg, "probe", 0.20, "a goal to move", "you", "testing the limits")
    pol = goals.policy(cfg)
    why = "the board has moved toward replication and this goal should follow it"
    big = round(pol["max_delta"] + 0.01, 4)
    say(f"riffle moves it by {big} in one step", lambda: goals.set_weight(st, cfg, "probe", 0.20 + big, "agent", why) and None)
    step = round(pol["max_delta"] - 0.005, 4)
    w = 0.20
    for i in range(3):
        w = round(w + step, 4)
        say(f"riffle's step {i + 1} of {step}, to {w}", lambda w=w: goals.set_weight(st, cfg, "probe", w, "agent", why) and None)
    say("the operator moves it to 0.45 at once", lambda: goals.set_weight(st, cfg, "probe", 0.45, "you", "") and None)
