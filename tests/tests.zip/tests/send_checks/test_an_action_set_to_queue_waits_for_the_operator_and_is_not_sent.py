# ==========================================================================
# Every action that reaches the square, set to `queue`, waits for the
# operator: the cycle ends `queued`, the action is `queued`, and nothing
# reaches the registry.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For each of post, comment, porch, vote, tag, flag, seal and attestation,
#   with every one of them set to `queue`: one real cycle.main() proposing
#   it, and what came of it. One line per kind.
#
# WHY IT EXISTS
#   Audit second pass (2026-11-14), section 7.1, the first row of what no
#   test would notice: the auditor changed the one line that queues an action
#   set to `queue` (cycle.py, `"queued" if mode == "queue" else "approved"`)
#   so that every such action went out unattended, and all 210 recorded tests
#   still passed, because every test that proposes one first sets it to auto.
#   It is the setting everything else leans on: the operator's approval of
#   posts, submissions and payouts.
#
# HOW IT WORKS
#   A stub registry that records any call that would send something; the
#   composer replaced by a function returning one proposal per cycle; the
#   witness pass and the changes walk skipped. All eight kinds set to queue
#   in the config. A library document exists so the seal has one to name.
#
# READING THE OUTPUT
#   `[kind] outcome 'queued' status 'queued' | reached the registry: nothing`
#   for every kind. Anything else is the fault this exists to catch.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON, and
#   PYTHONPATH=tests/lib for the safety net). The simplest way is
#   tests/run_all.sh, which runs everything on a temporary copy of the tree.
#
# CHANGELOG
#   2026-11-14  Written for the audit's section 7.1.
#   2026-11-20  Post 4 is a thread riffle has read: a vote on a post it has
#               not read is now refused before it can queue (batch 17,
#               voted-unread), which would leave this test proving nothing
#               about the queue for votes.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
SENT = []
_SENDS = ("create_post", "create_comment", "porch", "vote", "tag", "flag", "seal", "attest",
          "attestation", "create_attestation")
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        if n in _SENDS:
            return lambda *a, **k: SENT.append(n) or {"id": 1}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
NOW = []
drives.pick_drive = lambda *a, **k: "contribute"
PROPOSALS = {
    "post": {"title": "What a seal does and does not promise",
             "body": "A seal says a hash existed at a time. It does not say where the thing behind it is."},
    "comment": {"post_id": 4, "parent_id": 2, "body": "The order is not guaranteed: receipts settle when the batch closes."},
    "porch": {"body": "Thank you for the careful write-up on receipts."},
    "vote": {"target_type": "post", "target_id": 4},
    "tag": {"post_id": 4, "tag": "receipts"},
    "flag": {"target_type": "post", "target_id": 4, "reason": "It misstates what a seal promises."},
    "seal": {"library_id": 1, "label": "solve-py"},
    "attestation": {"subject": "bob", "cls": "code-merged", "claim": "bob's change to the receipt order was merged.",
                    "evidence": ["the merged change, as bob described it"]},
}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    k_ = NOW[0]
    return json.dumps({"rationale": f"proposing a {k_} this cycle, for the operator", "action": k_,
                       "payload": PROPOSALS[k_]})
cortex.complete = complete
d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
for k in PROPOSALS:
    cfg["autonomy"][k] = "queue"
for k in ("min_notes", "min_sources", "min_drafts", "min_objections"):
    cfg["projects"][k] = 0
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
st.db.executescript(project.READS_SCHEMA)
st.db.execute("INSERT INTO thread_reads (project_id, post_id, title, author, digest) VALUES (1, 4, 'Receipts', 'bob', 'd')")
st.db.commit()
library.put(st, "solve.py", "print(6 * 7)\n", kind="code", source="build:c1", root=root)
for k in PROPOSALS:
    NOW[:] = [k]
    before = len(SENT)
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    db = sqlite3.connect(os.path.join(d, "state.sqlite"))
    oc = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
    a = db.execute("SELECT status FROM actions WHERE kind=? ORDER BY id DESC LIMIT 1", (k,)).fetchone()
    print(f"  [{k:11}] outcome {oc!r:10} status {(a[0] if a else None)!r:10} | reached the registry: "
          f"{', '.join(SENT[before:]) or 'nothing'}")
