# ==========================================================================
# A payout binding for a verifier row (listing-N-verifier) is refused unless
# riffle could be that listing's verifier and has posted a verification.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case; each runs ONE real cycle.main() in which riffle
#   proposes `sign` {"kind": "payout", "row": "listing-N-verifier"}. riffle
#   also has a bindable submission to listing 80, so `sign` is offered, and
#   these are the verifier checks themselves:
#     ignored      listing 13, which the operator set aside
#     worker       riffle submitted work to listing 70
#     inrecord     the registry's record of 70 has a submission by riffle
#                  that riffle's own table does not
#     notopen      listing 71 is not on the registry's listings
#     unknown      the listings could not be read this cycle
#     funder       riffle is listing 70's funder
#     noprice      listing 66 names no verifier price (as every open listing
#                  did on 2026-11-28)
#     unread       listing 70's record cannot be read
#     unverified   riffle has posted nothing citing a submission to 70
#     othercite    riffle cited a submission of another listing
#     verified     riffle posted "submission 2001: PASS": passes, and the
#                  binding is queued for the operator
#   and, with no other submission of riffle's, whether `sign` is offered:
#     offer-verified     a verification posted: offered
#     offer-unverified   none: not offered
#
# WHY IT EXISTS
#   The no-work check (2026-11-03) covered listing-N rows and left verifier
#   rows "to the registry's own rules". Read on 2026-11-28, those say a
#   verifier re-runs the condition on a submission, posts the result
#   publicly citing the submission id, and is neither funder nor worker, and
#   that the registry checks none of it. A verifier row went past the no-work
#   check and the operator's ignore list alike.
#
# HOW IT WORKS
#   cycle.main() with Reader and Writer stubbed: listings() answers the index
#   (field names as the registry served them on 2026-11-28), get() a
#   listing's record, with submission ids and handles. The composer answers
#   with the sign proposal and the grammar it was offered is kept.
#
# READING THE OUTPUT
#   `[case] outcome '<outcome>' | sign offered: True/False | told: <the refusal>`
#
# RUNNING IT ON ITS OWN
#   With the variables tests/run_all.sh sets; simplest is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-28  Written with cycle.verifier_unbindable (batch 28).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, time, yaml, sqlite3
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library
from agent.client import HttpError
from agent.state import State, utcnow
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
LID = {"ignored": 13, "notopen": 71, "noprice": 66}.get(mode, 70)
FAR = int(time.time()) + 20 * 86400
def row(i, price="5000000", max_v=2, funder="silt"):
    return {"id": i, "funder": funder, "title": f"listing {i}", "amount_atomic": "100000000",
            "verifier_price_atomic": price, "max_verifiers": max_v, "chain_id": 8453,
            "expiry": FAR, "submission_deadline": FAR, "withdrawn_at": None, "post_id": 10000 + i,
            "submissions": 2, "row": f"listing-{i}", "record": f"/api/listings/{i}", "lifecycle": "open"}
INDEX = [row(13), row(66, price=None, max_v=0), row(70, funder="riffle" if mode == "funder" else "silt"),
         row(80, price=None, max_v=0)]
RECORD = {"id": 70, "listing_id": 70, "post_id": 10070, "thread": 10070, "verifier_price_atomic": "5000000",
          "max_verifiers": 2, "verifiers": None, "verdicts": [], "submissions_has_more": False,
          "submissions_total": 2,
          "submissions": [{"id": 2001, "handle": "Moneypenny", "artifact": "https://x.org/a"},
                          {"id": 2002, "handle": "riffle" if mode == "inrecord" else "coppice",
                           "artifact": "https://x.org/b"}]}
SENT = []
class Stub:
    def __init__(self, *a, **k): pass
    def listings(self):
        if mode == "unknown":
            raise HttpError(503, "busy")
        return {"listings": copy.deepcopy(INDEX)}
    def get(self, path, **k):
        if path.startswith("/api/listings/"):
            if mode == "unread":
                raise HttpError(0, "TimeoutError: The read operation timed out")
            return copy.deepcopy(RECORD) if path.endswith("/70") else {"submissions": []}
        return {}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        if n.startswith(("create_", "payout", "submit", "vote")):
            return lambda *a, **k: (SENT.append(n) or {"ok": True})
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "earn"
OFFERED = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    OFFERED["sign"] = any(((b.get("properties") or {}).get("action") or {}).get("const") == "sign"
                          for b in (schema or {}).get("oneOf", []))
    return json.dumps({"action": "sign", "payload": {"kind": "payout", "row": f"listing-{LID}-verifier"},
                       "rationale": "binding the verifier payout for the check I posted"})
cortex.complete = complete

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
cfg["autonomy"]["sign"] = "queue"
cfg["listings"] = {"ignore": [13]}
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
def act(kind, payload):
    st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
                  " VALUES (0,?,?,'x',?,'r','executed')", (utcnow(), kind, json.dumps(payload)))
if not mode.startswith("offer"):
    act("listing_submission", {"listing_id": 80, "artifact": "https://x.org/mine", "note": "n"})
if mode == "worker":
    act("listing_submission", {"listing_id": 70, "artifact": "https://x.org/mine2", "note": "n"})
if mode in ("verified", "offer-verified", "inrecord", "unread", "funder", "noprice", "notopen", "unknown", "ignored"):
    act("comment", {"post_id": 10070, "body": "I re-ran the condition on submission 2001: PASS, all four checks."})
if mode == "othercite":
    act("comment", {"post_id": 10066, "body": "I re-ran the condition on submission 1075 of listing 65: FAIL."})
st.db.commit()
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
oc = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
told = ""
for r in st.db.execute("SELECT content FROM messages WHERE role='report' ORDER BY id DESC LIMIT 1"):
    told = " ".join((r[0] or "").split()).split("I did not propose that: ", 1)[-1]
q = db.execute("SELECT status FROM actions WHERE kind='sign' ORDER BY id DESC LIMIT 1").fetchone()
print(f"  [{mode:16}] outcome {oc!r:22} | sign offered: {OFFERED.get('sign')} | "
      f"binding: {q[0] if q else 'none'} | sent: {'yes' if SENT else 'no'}"
      + (f" | told: {told[:400]!r}" if oc == "verifier-refused" else ""))
