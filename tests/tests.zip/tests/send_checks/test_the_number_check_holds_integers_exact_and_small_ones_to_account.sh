#!/bin/bash
# ==========================================================================
# numcheck holds an integer to an exact match (a rounded quotient does not
# back it), and in agent mode a small integer is a claim, not prose.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   numcheck.py on four one-line drafts against a source holding 894:
#     "came to 9"      (894/100 = 8.94, which must not back 9)
#     "came to 8.94"   (written to two places, it is 894/100)
#     "in 7 of 11 runs", agent mode and not: claims in agent mode, prose
#                       in the ordinary mode
#   Each prints its status lines.
#
# WHY IT EXISTS
#   Audit 2026-11-14, section 7.1: the exact-integer rule (the docstring's
#   own example: 894/100 rounding to 9) and agent mode's treatment of
#   small integers could each be switched off with every test passing.
#
# HOW IT WORKS
#   Runs the tree's numcheck.py on files in $RIFFLE_TMP.
#
# READING THE OUTPUT
#   `  [case] STATUS token note`, one line per figure.
#
# RUNNING IT ON ITS OWN
#   Through tests/run_all.sh.
#
# CHANGELOG
#   2026-11-18  Written for the audit's section 7.1 (batch 11).
# ==========================================================================
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
D=$(mktemp -d "$RIFFLE_TMP/numx.XXXX")
echo "The ledger recorded 894 receipts in the batch." > "$D/source.txt"
check() {  # $1 = case label, $2 = the draft's one line, $3.. = extra flags
  printf '%s\n' "$2" > "$D/draft.txt"
  python3 "$RIFFLE_TREE/numcheck.py" "$D/draft.txt" "$D/source.txt" "${@:3}" 2>&1 \
    | grep -E '^  (OK|UNBACKED|DERIVED|LOW|AMBIGUOUS|MALFORMED|COINCID|EXEMPT|PROSE)' \
    | sed -E "s/^ +/  [$1] /" | cut -c1-130
}
check "rounded int" "The receipts per run came to 9 on average." --agent
check "two places  " "The receipts per run came to 8.94 on average." --agent
check "small, agent" "It held in 7 of 11 runs." --agent
check "small, prose" "It held in 7 of 11 runs."
rm -rf "$D"
