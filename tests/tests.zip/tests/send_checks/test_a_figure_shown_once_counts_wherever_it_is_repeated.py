# ==========================================================================
# A figure whose derivation the text shows (767/1000 = 76.7%) counts, and a
# figure declared or derived once counts wherever the draft repeats it,
# title included. A bare figure, and a shown pair that does not give it,
# still do not.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   numcheck.py --agent, run on five drafts against one source (a build's
#   output carrying 767 and 1000, and other small values that make 76.7
#   derivable more than one way):
#     written    "767/1000 = 76.7%", "76.7% (767/1000)", "767 out of 1000
#                (76.7%)": each passes, and the 76.7% in the title and a
#                later line passes as the same claim
#     declared   "76.7% [[767/1000*100]]" once, and 76.7% again in the
#                title: passes (the title used to fail AMBIGUOUS)
#     bare       76.7% twice, no derivation anywhere: fails AMBIGUOUS
#     wrongpair  "81.2% (767/1000)": the pair gives 76.7, not 81.2: fails
#     absent     "76.7% (767/1200)": 1200 is in no source: fails
#
# WHY IT EXISTS
#   The operator's export of 2026-11-24 to 11-27: 134 posts refused by the
#   number check, nearly all on 76.7%, a figure riffle's appended build
#   printed as "0.7670 (767/1000)". riffle wrote the derivation out in
#   prose and it came back AMBIGUOUS. Action 4477 used the [[...]] form on
#   line 3 and passed there, and failed on the same figure in its title and
#   on four other lines.
#
# HOW IT WORKS
#   numcheck.py is run as the cycle runs it (--agent), on drafts and a source
#   file written to a temporary directory; the verdict line and the status
#   of every 76.7/81.2 are printed.
#
# READING THE OUTPUT
#   `[case] exit <0 pass | 1 fail> | <token>@L<line> <STATUS> ...`
#
# RUNNING IT ON ITS OWN
#   python3 <this file> <repo> <case>
#
# CHANGELOG
#   2026-11-27  Written with numcheck.written_out and the same-figure pass
#               (batch 24).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, subprocess, tempfile
repo, mode = sys.argv[1], sys.argv[2]
d = tempfile.mkdtemp()
src = os.path.join(d, "build_output.txt")
open(src, "w").write("Suppression rate: 0.7670 (767/1000)\n"
                     "gates 10, p_failure 0.46, trials 1000, seed 0\n"
                     "other rows: 46 60 3 4 2 8 12 15 23 30 115 150\n")
DRAFTS = {
    "written": "Tripwire suppression is order-dependent: 76.7% in simulation\n"
               "Suppression rate: 767/1000 = 76.7%.\n"
               "It was suppressed in 76.7% of trials (767/1000).\n"
               "The tripwire was skipped in 767 out of 1000 runs (76.7%).\n"
               "So in 76.7% of cases the check never ran.\n",
    "declared": "Tripwire suppression: 76.7% in simulation\n"
                "Suppressed in 76.7% [[767/1000*100]] of trials.\n",
    "bare": "Tripwire is suppressed in 76.7% of trials.\nThat is most of the time: 76.7%.\n",
    "wrongpair": "Suppressed in 81.2% of cases (767/1000).\n",
    "absent": "Suppressed in 76.7% of cases (767/1200).\n",
}
dr = os.path.join(d, "draft.md")
open(dr, "w").write(DRAFTS[mode])
r = subprocess.run([sys.executable, os.path.join(repo, "numcheck.py"), "--agent", "--json", dr, src],
                   capture_output=True, text=True)
try:
    out = json.loads(r.stdout)
    shown = [f"{f['token']}@L{f['line']} {f['status']}" for f in out["findings"]
             if f.get("kind") == "num" and f["token"] in ("76.7", "81.2")]
except ValueError:
    shown = [r.stdout[-200:], r.stderr[-200:]]
print(f"  [{mode:9}] exit {r.returncode} | " + "; ".join(shown))
