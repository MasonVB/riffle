# ==========================================================================
# An attestation about someone else's work is never addressed to riffle, a
# correction is never addressed to anyone else, and a replication names a
# document riffle's build produced, whose sha256 the cycle adds.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     self-merged    code-merged addressed to riffle itself: refused
#                    (wrong-class), told to name the citizen
#     corr-other     a correction addressed to another citizen: refused, and
#                    the advice is a comment, not cls=dispute
#     repl-none      replicated-total whose evidence is a script's file name
#                    (what the box sent on 2026-11-12): refused
#                    (replication-unbuilt), told its builds' newest
#     repl-note      evidence names a library document riffle wrote itself,
#                    not a build's: refused
#     repl-build     evidence names a build's output: queued, with
#                    "library #N sha256 <the document's hash>" added
#
# WHY IT EXISTS
#   Audit F15 (2026-11-10, corrected 2026-11-14): the four classes about
#   another's work were not checked against riffle's own handle, and the
#   refusal for a misdirected correction said "send it as cls=dispute", which
#   riffle cannot send. Audit F43: a replication was backed by nothing; the
#   evidence was free strings.
#
# HOW IT WORKS
#   One real cycle.main() against a stub registry and composer. A build's
#   output is a library document with source build:<run>, as do_build
#   shelves it.
#
# READING THE OUTPUT
#   `[case] outcome ... | ...` and, where it was queued, its evidence.
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_attestations_go_to_the_right_subject_and_
#   a_replication_names_its_build.py . repl-build
#
# CHANGELOG
#   2026-11-16  Written for audit F15 and F43 (batch 6).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, copy, json, tempfile, sqlite3, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library
from agent.state import State

me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "witness"
REPLY = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    return json.dumps(REPLY)
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
root = os.path.join(d, "library"); cfg.setdefault("library", {})["root"] = root
cfg["autonomy"]["attestation"] = "queue"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
note_id, _ = library.put(st, "my notes on marrow covariance", "I think their drift figure holds up when rerun.",
                         kind="note", root=root)
code_id, _ = library.put(st, "replicate.py — rerun of coppice's drift", "import statistics\nprint('drift ok')\n",
                         kind="code", source="build:41", root=root)
out_id, _ = library.put(st, "output of replicate.py — rerun of coppice's drift", "drift ok\n",
                        kind="data", source="build:41:stdout", root=root)
st.db.commit()
CLAIM = "Their published drift script reproduces the population covariance they reported on a fresh run."
def att(cls, subject, evidence):
    return {"action": "attestation", "rationale": "recording what I checked",
            "payload": {"cls": cls, "subject": subject, "claim": CLAIM, "evidence": evidence}}
CASES = {
    "self-merged": att("code-merged", cfg["handle"], ["the merge of my branch"]),
    "corr-other": att("correction", "coppice", ["their post overstated the sample"]),
    "repl-none": att("replicated-total", "coppice", ["marrow_covariance_drift.py"]),
    "repl-note": att("replicated-total", "coppice", [f"library #{note_id}"]),
    "repl-build": att("replicated-population", "coppice", [f"rerun, library #{out_id}"]),
}
REPLY.update(CASES[mode])
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite")); db.row_factory = sqlite3.Row
c = db.execute("SELECT outcome, notes FROM cycles ORDER BY id DESC LIMIT 1").fetchone()
a = db.execute("SELECT status, payload FROM actions ORDER BY id DESC LIMIT 1").fetchone()
said = db.execute("SELECT content AS text FROM messages WHERE content LIKE '%did not send that%' ORDER BY id DESC LIMIT 1").fetchone()
said = said["text"].split("did not send that: ", 1)[1] if said else ""
print(f"  [{mode:11}] outcome {c['outcome']!r:22} | action {a['status'] if a else None!r}")
if said:
    print(f"  [{mode:11}] told: {said[:330]!r}")
    print(f"  [{mode:11}] advises cls=dispute: {'cls=dispute' in said}")
if a and a["status"] == "queued":
    ev = json.loads(a["payload"])["evidence"]
    sha = db.execute("SELECT sha256 FROM library WHERE id=?", (out_id,)).fetchone()["sha256"]
    print(f"  [{mode:11}] evidence: {[e.replace(sha, '<sha of #' + str(out_id) + '>') for e in ev]}")
