# ==========================================================================
# An action refused for the same reason ten times in 24 hours is taken out of
# riffle's choices for six hours after the last of them, and the prompt says
# so; a porch line refused as said-already takes the porch out for the day.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case; each runs ONE real cycle.main() with the
#   composer replaced by a stub that records the prompt and the grammar it
#   was given, and prints what the prompt says is not among the choices and
#   whether the grammar still offers the action.
#     nine      nine numcheck refusals of posts in the day: post still offered
#     ten       ten: post out of the grammar, and the prompt says why and until
#     mixed     ten refusals of posts, but for four different reasons: offered
#     expired   ten, the last of them seven hours ago: offered again
#     off       ten, with cycle.refusal_lockout_after 0: offered
#     porch     a porch line refused as said-already today: porch out, and
#               the prompt says why
#     porchold  the same refusal yesterday: porch offered
#
# WHY IT EXISTS
#   The operator's decision, 2026-11-27. On 11-26 riffle proposed 60 posts,
#   57 refused by the number check for the same reason, with "YOU HAVE BEEN
#   DOING ONE THING" in every prompt; and proposed one porch line five more
#   times after sending it. Telling it was not enough.
#
# HOW IT WORKS
#   cycle.main() with Reader and Writer stubbed. Refusals are planted as the
#   cycle writes them: a cycle with its outcome, and a `blocked` action.
#   The project is ready and posting open, so only the lockout can take
#   post away.
#
# READING THE OUTPUT
#   `[case] post offered: yes/no | not among: <what the prompt says>`
#
# RUNNING IT ON ITS OWN
#   With the variables tests/run_all.sh sets; simplest is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-27  Written with cycle.refusal_lockouts and the porch hold
#               (batch 25).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, datetime, re
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "understand"
SEEN = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" in user:
        SEEN["user"] = user
        SEEN["kinds"] = sorted({b["properties"]["action"]["const"] for b in (schema or {}).get("oneOf", [])
                                if "const" in b.get("properties", {}).get("action", {})})
        return json.dumps({"action": "noop", "payload": {"why": "test"}, "rationale": "test"})
    return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                      else {"promote": [], "write": [], "drop": [], "note": ""})
cortex.complete = complete
project.ready = lambda *a, **k: (True, "")
project.in_cooldown = lambda *a, **k: (False, None, 0)

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
if mode == "off":
    cfg["cycle"]["refusal_lockout_after"] = 0
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-11-24T03:15:37Z','T','Q?','active')")
now = datetime.datetime.now(datetime.timezone.utc)

def refusal(kind, outcome, ago_h):
    t = (now - datetime.timedelta(hours=ago_h)).strftime("%Y-%m-%dT%H:%M:%SZ")
    st.db.execute("INSERT INTO cycles (started_at, ended_at, drive, outcome) VALUES (?,?,?,?)",
                  (t, t, "make", outcome))
    cid = st.db.execute("SELECT last_insert_rowid()").fetchone()[0]
    st.db.execute("INSERT INTO actions (cycle_id, created_at, kind, drive, payload, rationale, status)"
                  " VALUES (?,?,?,?,?,?,?)", (cid, t, kind, "make", "{}", "r", "blocked"))

if mode in ("nine", "ten", "off"):
    for i in range(9 if mode == "nine" else 10):
        refusal("post", "numcheck-blocked", 5 - i * 0.4)
elif mode == "mixed":
    for i, oc in enumerate(["numcheck-blocked", "library-private", "project-repeat", "said-already"] * 3):
        if i < 10:
            refusal("post", oc, 5 - i * 0.4)
elif mode == "expired":
    for i in range(10):
        refusal("post", "numcheck-blocked", 17 - i)
elif mode == "porch":
    refusal("porch", "said-already", 0.2)
elif mode == "porchold":
    refusal("porch", "said-already", 30)
st.db.commit()
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
u = SEEN.get("user", "")
m = re.search(r"NOT AMONG YOUR CHOICES THIS CYCLE: (.*?)\. Reason towards", u, re.S)
said = " ".join(m.group(1).split()) if m else "(none)"
said = re.sub(r"until \d\d:\d\d UTC", "until HH:MM UTC", said)
k = "porch" if mode.startswith("porch") else "post"
print(f"  [{mode:8}] {k} offered: {'yes' if k in SEEN.get('kinds', []) else 'no '} | not among: "
      + (said[said.find(k + " ("):][:250] if k + " (" in said else ""))
