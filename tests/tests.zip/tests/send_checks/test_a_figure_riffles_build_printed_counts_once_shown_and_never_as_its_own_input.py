# ==========================================================================
# A figure one of riffle's builds printed counts once a reader can see that
# build, whichever build it was; a refusal names the build and the ways to
# show it, not a web search; and a rate a simulation was given is refused
# as a finding.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case; each runs ONE real cycle.main() with comment
#   on `auto` against a stub registry, and prints the outcome, whether
#   anything was sent, and what riffle was told.
#     private      a figure solve.py printed, the build shown nowhere:
#                  refused, and told to append solve.py (not to search the web)
#     appended     the same, with "append": [solve.py]: sent
#     linked       the same, citing riffle's own post that carries solve.py: sent
#     older        a figure from an OLDER build than the last, appended: sent
#                  (an older build's output used to count only while it was
#                  among the sixty newest library documents, and on the box
#                  it no longer was)
#     assumed      "71.7% suppression", from a script drawing each trial with
#                  random() < 0.718, appended: refused, figure-assumed
#     assumedroute the same figure, the script not shown: refused by the
#                  number check, and told it is an assumption, not told to
#                  append the script or search the web
#
# WHY IT EXISTS
#   The operator's export of 2026-11-21 to 11-24: 48 posts proposed after
#   batch 21, none sent, 34 refused by the number check on one figure, 71.7%,
#   which riffle's own simulation printed. Only the last build's output
#   counted, a newer build had replaced it, "library #414" is refused as
#   private, and the refusal said "search_web a reference site": riffle read
#   Wikipedia's page on the hypergeometric distribution twice looking for its
#   own result. (Build outputs also counted while among the sixty newest
#   library documents, whether a reader could see the build or not; the
#   probe's had dropped out.) And the result was its input: verify_suppression.py and
#   verify_final.py drew each trial with `random.random() < 0.718`.
#
# HOW IT WORKS
#   As test_a_figure_or_hash_counts_only_if_riffle_read_it.py: cycle.main()
#   with Reader and Writer stubbed, the composer replaced by the case's
#   proposal, builds shelved in the library as apply_build shelves them
#   (each file as "build:cN", its output as "build:cN:stdout").
#
# READING THE OUTPUT
#   `[case] outcome '<outcome>' | sent: <yes/no>`, then for a refusal what
#   riffle was told, cut to the part that matters.
#
# RUNNING IT ON ITS OWN
#   With the variables tests/run_all.sh sets; simplest is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-24  Written with outgoing.public_build_outputs, build_route and
#               figure_assumed (batch 22).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, re
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
SENT = []
class Stub:
    def __init__(self, *a, **k): pass
    def create_comment(self, post_id, body, parent_id=None):
        SENT.append(body); return {"comment_id": 501, "created_at": 1}
    def create_post(self, title, body, url=None):
        SENT.append(title); return {"post_id": 901, "created_at": 1}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "answer"
REPLIES = []

def comment(body, append=None):
    p = {"rationale": "answering their question with what my script found", "action": "comment",
         "payload": {"post_id": 4, "parent_id": 2, "body": body}}
    if append:
        p["payload"]["append"] = append
    return p

def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    if "YOUR DRAFT WAS NOT SENT" in user:
        return json.dumps({"action": "noop", "payload": {"why": "x"}, "rationale": "x"})
    return json.dumps(REPLIES.pop(0) if REPLIES else
                      {"action": "noop", "payload": {"why": "nothing to do"}, "rationale": "nothing to do"})
cortex.complete = complete

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
cfg["autonomy"]["comment"] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
st.db.commit()

SOLVE = "rows = open('receipts.csv').read().splitlines()\nlate = sum(1 for r in rows if r.endswith(',late'))\nprint(f'late={late} total={len(rows)}')\n"
PROBE = ("import random\nrandom.seed(0)\nviolations = suppressed = 0\nfor _ in range(2000):\n"
         "    if random.random() > 0.5:\n        violations += 1\n"
         "        if random.random() < 0.718:\n            suppressed += 1\n"
         "print(f'Suppression rate with seed 0: {suppressed / violations:.3f}')\n")
NEWER = "print('hypergeometric P(X<=1) = 0.025012')\n"

def shelve(run, name, code, out):
    cid, _ = library.put(st, f"{name} — a build", code, kind="code", source=f"build:{run}", root=root)
    library.put(st, f"output of {name} — a build", out, kind="data", source=f"build:{run}:stdout", root=root)
    st.note("last_build", json.dumps({"entry": name, "stdout": out, "ok": True, "files": [name],
                                      "at": "2026-11-23T00:00:00Z", "library_id": cid}))
    return cid

def sent_post(pid, body):
    st.db.execute("INSERT INTO actions (cycle_id, created_at, kind, drive, payload, rationale, status, response)"
                  " VALUES (0, '2026-11-20T00:00:00Z', 'post', 'make', ?, 'r', 'executed', ?)",
                  (json.dumps({"title": "the probe", "body": body}), json.dumps({"post_id": pid})))
    st.db.commit()

def run(*replies):
    REPLIES[:] = list(replies)
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    db = sqlite3.connect(os.path.join(d, "state.sqlite"))
    return db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]

solve = shelve("c11", "solve.py", SOLVE, "late=4210 total=7391\n")
if mode == "private":
    oc = run(comment("My solve.py printed late=4210 out of 7391 receipts."))
elif mode == "appended":
    oc = run(comment("My solve.py printed late=4210 out of 7391 receipts; the script is below.", [solve]))
elif mode == "linked":
    sent_post(13122, "The script.\n\n---\nAppendix A: solve.py, sha256 x\n```\n" + SOLVE + "```")
    oc = run(comment("My solve.py, in full in post 13122, printed late=4210 out of 7391 receipts."))
elif mode == "older":
    shelve("c12", "verify_hypergeom.py", NEWER, "hypergeometric P(X<=1) = 0.025012\n")
    oc = run(comment("My solve.py printed late=4210 out of 7391 receipts; the script is below.", [solve]))
elif mode in ("assumed", "assumedroute"):
    probe = shelve("c13", "verify_final.py", PROBE, "Suppression rate with seed 0: 0.717\n")
    shelve("c14", "verify_hypergeom.py", NEWER, "hypergeometric P(X<=1) = 0.025012\n")
    oc = run(comment("My verify_final.py confirms it: the tripwire is suppressed in 71.7% of trials.",
                     [probe] if mode == "assumed" else None))
told = ""
for r in st.db.execute("SELECT content FROM messages WHERE role IN ('report','error') ORDER BY id DESC LIMIT 1"):
    told = " ".join((r[0] or "").split())
print(f"  [{mode:12}] outcome {oc!r:18} | sent: {'yes' if SENT else 'no'}")
if not SENT:
    key = re.search(r"(?:It counts once|was given it|you give).{0,190}", told)
    print(f"  [{mode:12}] told: {key.group(0) if key else told[-200:]!r}")
    print(f"  [{mode:12}] told to search the web: {'search_web' in told}; "
          f"told to append: {'append' in told}")
