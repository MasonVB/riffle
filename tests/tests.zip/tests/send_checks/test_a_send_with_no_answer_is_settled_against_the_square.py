# ==========================================================================
# A send that got no answer is settled against the square at the start of
# the next cycle: found, it is sent; not there, it is not sent; a vote or
# tag is treated as not sent; anything the cycle cannot look up waits for
# the operator, who settles it with a button. A send the cycle left
# `approved` when it died is treated the same way.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Six rows put where the box has them, then one real cycle.main(), then
#   each row's status:
#     ghost-landed   `approved` comment from September (a cycle died mid-send)
#                    that IS in riffle's history on the registry -> executed
#     unknown-gone   `unknown` comment from an hour ago, not in the history
#                    -> failed
#     too-recent     `unknown` comment from a minute ago, not in the history
#                    -> still unknown (it may be in flight)
#     porch-landed   `unknown` porch line that IS on that day's porch
#                    -> executed
#     vote           `unknown` vote -> failed (a second vote is refused)
#     seal           `unknown` seal -> still unknown, for the operator
#   Then the seal settled through the dashboard's POST /api/resolve as
#   "it is on the square" -> executed.
#
# WHY IT EXISTS
#   Audit 2026-11-10, F10, and second pass F38. A send with no answer was
#   `unknown` for good, and one the cycle died sending stayed `approved` for
#   good (twelve on the box from September). Both count as sent in every
#   duplicate check and file the comment they answer as answered; the
#   dashboard refused to dismiss one and could not approve it again; nothing
#   ever changed one.
#
# HOW IT WORKS
#   A stub registry: my_history returns the September comment; the porch
#   read returns riffle's line. The dashboard is served on a free local port
#   for the /api/resolve call.
#
# READING THE OUTPUT
#   One `[row] status` line per row, as listed above, then the resolve line.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON, and
#   PYTHONPATH=tests/lib for the safety net). The simplest way is
#   tests/run_all.sh, which runs everything on a temporary copy of the tree.
#
# CHANGELOG
#   2026-11-15  Written for the fixes to F10 and F38.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, datetime, threading, http.client
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, dash
from agent.state import State
from http.server import ThreadingHTTPServer
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d
HANDLE = cfg["handle"]
def ago(**kw):
    return (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(**kw)).strftime("%Y-%m-%dT%H:%M:%SZ")
SEPT = "2026-09-10T12:00:00Z"
SEPT_MS = int(datetime.datetime(2026, 9, 10, 12, 0, 30, tzinfo=datetime.timezone.utc).timestamp() * 1000)
CALLS = []
class Stub:
    def __init__(self, *a, **k): pass
    def my_history(self, **p):
        CALLS.append("history")
        return {"comments": [{"id": 900, "post_id": 5, "body": "Thanks, that settles the ordering question.",
                              "created_at": SEPT_MS}],
                "posts": [], "comments_has_more": False, "posts_has_more": False}
    def get(self, path, **p):
        if path == "/api/porch":
            CALLS.append("porch")
            return {"lines": [{"id": 77, "author": HANDLE, "body": "Good morning, porch."}], "truncated": False}
        return {}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "understand"
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    return json.dumps({"action": "noop", "payload": {"why": "nothing to do"}, "rationale": "nothing to do"})
cortex.complete = complete
open(os.path.join(d, f"{HANDLE}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
ROWS = [("ghost-landed", SEPT, "comment", {"post_id": 5, "parent_id": 2, "body": "Thanks, that settles the ordering question."}, "approved", None),
        ("unknown-gone", ago(hours=1), "comment", {"post_id": 6, "parent_id": 3, "body": "A reply the registry never got."}, "unknown",
         {"error": "HTTP 0: TimeoutError: The read operation timed out"}),
        ("too-recent", ago(minutes=1), "comment", {"post_id": 7, "parent_id": 4, "body": "A reply still in flight."}, "unknown",
         {"error": "HTTP 0: TimeoutError: The read operation timed out"}),
        ("porch-landed", ago(hours=1), "porch", {"body": "Good morning, porch."}, "unknown",
         {"error": "HTTP 0: TimeoutError: The read operation timed out"}),
        ("vote", ago(hours=1), "vote", {"target_type": "post", "target_id": 5}, "unknown", {"error": "HTTP 0: timed out"}),
        ("seal", ago(hours=1), "seal", {"library_id": 1, "hash": "ab" * 32, "label": "x"}, "unknown", {"error": "HTTP 0: timed out"})]
IDS = {}
for name, at, kind, p, status, resp in ROWS:
    IDS[name] = st.db.execute(
        "INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status,response)"
        " VALUES (1,?,?,'understand',?,'r',?,?)",
        (at, kind, json.dumps(p), status, json.dumps(resp) if resp else None)).lastrowid
st.db.commit()
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
for name, *_ in ROWS:
    print(f"  [{name:12}] {st.db.execute('SELECT status FROM actions WHERE id=?', (IDS[name],)).fetchone()[0]!r}")
class H(dash.Handler): pass
H.state, H.cfg = st, cfg
srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
c = http.client.HTTPConnection("127.0.0.1", srv.server_address[1], timeout=10)
c.request("POST", "/api/resolve", json.dumps({"id": IDS["seal"], "landed": True}),
          {"Content-Type": "application/json", "Host": f"127.0.0.1:{srv.server_address[1]}"})
r = c.getresponse(); body = r.read()
print(f"  resolve the seal as on the square: HTTP {r.status} {json.loads(body or b'{}')} -> "
      f"{st.db.execute('SELECT status FROM actions WHERE id=?', (IDS['seal'],)).fetchone()[0]!r}")
srv.shutdown()
