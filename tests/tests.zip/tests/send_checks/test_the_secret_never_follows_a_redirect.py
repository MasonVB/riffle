# ==========================================================================
# A request carrying riffle's secret is never redirected, so the secret
# cannot be handed to another host; a plain read still follows a redirect.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Two stand-in servers on loopback, under two host names (127.0.0.1 and
#   127.0.0.2). The first answers every request with a 302 to the second;
#   the second records what Authorization header reached it.
#     write  Writer.create_post: what riffle sees, and whether the second
#            host received the secret
#     read   Reader.get: still follows the redirect and gets its answer
#
# WHY IT EXISTS
#   Audit F24 (2026-11-10): urllib follows redirects and keeps the
#   Authorization header across hosts. A 302 from a stand-in registry to
#   another host name delivered `Bearer <secret>` there.
#
# HOW IT WORKS
#   http.server on two loopback addresses, in threads; agent/client.py's
#   real Reader and Writer. Nothing leaves the machine.
#
# READING THE OUTPUT
#   `[write] ...` and `[read] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_the_secret_never_follows_a_redirect.py .
#
# CHANGELOG
#   2026-11-17  Written for audit F24 (batch 8).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, json, threading, http.server
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent.client import Reader, Writer, HttpError

SEEN = []


class Elsewhere(http.server.BaseHTTPRequestHandler):
    def _answer(self):
        SEEN.append(self.headers.get("Authorization"))
        n = int(self.headers.get("Content-Length") or 0)
        if n:
            self.rfile.read(n)
        body = json.dumps({"post_id": 77, "ok": True}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    do_GET = do_POST = _answer

    def log_message(self, *a):
        pass


def serve(host, handler):
    srv = http.server.HTTPServer((host, 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


other = serve("127.0.0.2", Elsewhere)
OTHER = f"http://127.0.0.2:{other.server_address[1]}"


class Registry(http.server.BaseHTTPRequestHandler):
    def _bounce(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n:
            self.rfile.read(n)
        self.send_response(302)
        self.send_header("Location", OTHER + self.path)
        self.send_header("Content-Length", "0")
        self.end_headers()
    do_GET = do_POST = _bounce

    def log_message(self, *a):
        pass


reg = serve("127.0.0.1", Registry)
BASE = f"http://127.0.0.1:{reg.server_address[1]}"
try:
    Writer(BASE, "s3cret-for-the-test").create_post("A title", "A body.")
    print("  [write] create_post went through the redirect")
except HttpError as e:
    print(f"  [write] riffle is told: HTTP {e.status}: {str(e.body).replace(OTHER, 'http://<other host>')[:120]}")
print(f"  [write] the other host received the secret: {any(a and 's3cret' in a for a in SEEN)}")
SEEN.clear()
r = Reader(BASE).get("/api/front")
print(f"  [read ] a plain read followed it and got: {r}; it carried a secret: {any(SEEN)}")
