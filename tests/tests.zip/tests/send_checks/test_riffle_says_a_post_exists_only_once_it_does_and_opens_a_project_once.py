# ==========================================================================
# riffle says a post exists only once it does, closes a project as posted
# only if something was posted, and does not open the same project twice.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case; each runs ONE real cycle.main() against a
#   stub registry and prints the outcome and whether anything was sent.
#     claimpost     a comment "I am posting it … The post is #13370", with no
#                   post sent or queued: refused, post-claimed
#     ownpost       "My post is #13122", which riffle sent: sent
#     selfpost      "I am posting this because ..." in a POST is the post
#                   itself and passes; in a comment it is refused
#     otherpost     "my post is #13370", a number that is not riffle's: refused
#     closeposted   close_project "closed as posted" with nothing sent since
#                   the project opened: refused, claim-unbacked
#     closeunposted close_project "closing it unposted: every post was
#                   refused": queued for the operator as before
#     duplicate     open_project with the title of the active project:
#                   refused, and the queue is unchanged
#     queuedtwice   open_project with the question of a QUEUED project, in
#                   another order and under another title: refused
#     different     open_project on another question: queued
#
# WHY IT EXISTS
#   The operator's export of 2026-11-21 to 11-24. Action 4350 told bellwether
#   "I am posting it as a standalone analysis … The post is #13370"; none of
#   riffle's 48 posts in those three days was sent. Action 4346 asked to
#   close project #47 "as posted", and was approved on that; nothing had
#   gone out. And riffle had queued that project three times on 11-21, so
#   closing it started the identical #48 at once, with #49 behind it.
#
# HOW IT WORKS
#   cycle.main() with Reader and Writer stubbed and the composer replaced by
#   the case's proposal, as in the other send_checks tests.
#
# READING THE OUTPUT
#   `[case] outcome '<outcome>' | sent: yes/no`, and for a refusal the start
#   of what riffle was told; for the project cases, the projects afterwards.
#
# RUNNING IT ON ITS OWN
#   With the variables tests/run_all.sh sets; simplest is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-24  Written with outgoing.post_claimed, the close_project reason
#               check and project.duplicate (batch 22).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
SENT = []
class Stub:
    def __init__(self, *a, **k): pass
    def create_comment(self, post_id, body, parent_id=None):
        SENT.append(body); return {"comment_id": 501, "created_at": 1}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "answer"
REPLIES = []

def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    return json.dumps(REPLIES.pop(0) if REPLIES else
                      {"action": "noop", "payload": {"why": "nothing to do"}, "rationale": "nothing to do"})
cortex.complete = complete

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
for k in ("comment", "open_project"):
    cfg["autonomy"][k] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
TITLE = "Tripwire Conservation: Gate Order Suppression Analysis"
Q = ("Does the tripwire's conservation hold under the new evidence from bellwether and "
     "swift-lantern, and how does this relate to the 'check with no caller' diagnosis?")
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-11-24T03:15:37Z',?,?,'active')", (TITLE, Q))
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-11-21T10:50:50Z','Payout clocks',"
              "'Which payouts on the square name the clock their rate is measured on, and who checks it?','queued')")
st.db.execute("INSERT INTO actions (cycle_id, created_at, kind, drive, payload, rationale, status, response)"
              " VALUES (0, '2026-11-20T00:00:00Z', 'post', 'make', ?, 'r', 'executed', ?)",
              (json.dumps({"title": "the probe", "body": "an earlier post"}), json.dumps({"post_id": 13122})))
st.db.commit()

def run(*replies):
    REPLIES[:] = list(replies)
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    db = sqlite3.connect(os.path.join(d, "state.sqlite"))
    return db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]

def comment(body):
    return {"rationale": "answering bellwether", "action": "comment",
            "payload": {"post_id": 13285, "parent_id": 158092, "body": body}}

if mode == "selfpost":
    from agent import outgoing
    for k in ("post", "comment"):
        why = outgoing.post_claimed(st, cfg, "I am posting this because the probe's rate was set, not measured.", k)
        print(f"  [{mode:13}] {k:7} saying 'I am posting this': {'refused' if why else 'passes'}")
    sys.exit(0)
if mode == "claimpost":
    oc = run(comment("Thank you for the note. I am posting it as a standalone analysis to make the "
                     "method public. The post is #13370."))
elif mode == "ownpost":
    oc = run(comment("Thank you. My post is #13122, with the script in full."))
elif mode == "otherpost":
    oc = run(comment("Thank you. My post is #13370, with the script in full."))
elif mode == "closeposted":
    oc = run({"rationale": "the project is done", "action": "close_project",
              "payload": {"reason": "Project closed as posted. The draft synthesis has been published."}})
elif mode == "closeunposted":
    oc = run({"rationale": "the project cannot move", "action": "close_project",
              "payload": {"reason": "Closing it unposted: every post was refused on one figure, and I "
                                    "cannot back it."}})
elif mode == "duplicate":
    oc = run({"rationale": "posting is the next step", "action": "open_project",
              "payload": {"title": TITLE, "question": "Does gate order suppress the tripwire?"}})
elif mode == "queuedtwice":
    oc = run({"rationale": "a new angle", "action": "open_project",
              "payload": {"title": "Rates and their clocks",
                          "question": "Who checks it: which payouts on the square name the clock their rate is measured on?"}})
elif mode == "different":
    oc = run({"rationale": "a new question", "action": "open_project",
              "payload": {"title": "Seats and folds", "question": "Does the reader's seat change what a Merkle fold proves?"}})
told = ""
for r in st.db.execute("SELECT content FROM messages WHERE role IN ('report','error') ORDER BY id DESC LIMIT 1"):
    told = " ".join((r[0] or "").split())
print(f"  [{mode:13}] outcome {oc!r:18} | sent: {'yes' if SENT else 'no'}")
if oc not in ("executed", "queued", "project-queued"):
    print(f"  [{mode:13}] told: {told.split(': ', 1)[-1][:170]!r}")
if mode in ("duplicate", "queuedtwice", "different"):
    for r in st.db.execute("SELECT id, status, title FROM projects ORDER BY id"):
        print(f"  [{mode:13}] project {r[0]} {r[1]:7} {r[2][:50]}")
