# ==========================================================================
# A link whose path holds parentheses, as Wikipedia's often do, is read
# whole: by the link rule, the reference rule and the number check.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     words   what reference.outside_links, reference's URL pattern and
#             numcheck's URL mask take from five lines: a Wikipedia URL with
#             (...) in its path, the same inside a parenthesis, a link in a
#             parenthesis with none, a lone "(" after a link, a link with
#             "(2019)" in it
#     post    one real cycle: a post that quotes en.wikipedia.org/wiki/
#             Consistency_(database_systems), a page riffle read, with its
#             URL, when a reference is due: queued, not refused
#
# WHY IT EXISTS
#   2026-11-18 on the box: three posts quoting that page, which riffle had
#   read twice, were refused, two as "it links ...Consistency_(database_systems
#   without using it", one as "none of its URLs is a page you have read". Both
#   patterns stopped a path at the first ")", so the URL checked was missing
#   its last character and matched no page in the library.
#
# HOW IT WORKS
#   words: the functions directly. post: cycle.main() against a stub registry
#   and composer, the page shelved as read_page shelves it, the reference
#   streak set so one is due.
#
# READING THE OUTPUT
#   `[words] what -> found` and `[post ] outcome ... | reached the square`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_a_link_with_parentheses_is_read_whole.py . words
#
# CHANGELOG
#   2026-11-19  Written for the parentheses fault seen in the box's figures
#               (batch 12).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, copy, json, tempfile, sqlite3, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library, reference
from agent.state import State

URL = "https://en.wikipedia.org/wiki/Consistency_(database_systems)"

if mode == "words":
    import numcheck
    for what, t in (("in a sentence", f"as shown at {URL}, and"),
                    ("inside a parenthesis", f"(URL: {URL})."),
                    ("a link in a parenthesis", "(see https://www.sqlite.org/wal.html)."),
                    ("a lone ( after it", "https://www.sqlite.org/wal.html(see below"),
                    ("with (2019) in it", "https://example.org/wiki/Release_(2019) shipped")):
        print(f"  [words] {what:22} outside_links {reference.outside_links(t)}")
        print(f"  [words] {'':22} reference URL {[m.group(0) for m in reference._URL.finditer(t)]}")
        print(f"  [words] {'':22} numcheck mask {numcheck.URL_RE.findall(t)}")
    sys.exit(0)

me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
sent = []


class Stub:
    def __init__(self, *a, **k): pass

    def create_post(self, title, body, url=None):
        sent.append(title)
        return {"post_id": 901, "created_at": 1}

    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (
            lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})


cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "contribute"
QUOTE = ("a transaction can only bring the database from one consistent state to another")
REPLY = {"action": "post", "rationale": "the project is ready and this is what it found",
         "payload": {"title": "What consistency promises, and what it does not",
                     "body": f"As Wikipedia puts it, \"{QUOTE}\" (URL: {URL}). A witness that "
                             f"skips a state breaks exactly that."}}


def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    return json.dumps(REPLY)


cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
root = os.path.join(d, "library"); cfg.setdefault("library", {})["root"] = root
cfg["autonomy"]["post"] = "queue"
for k in ("min_notes", "min_sources", "min_drafts", "min_objections"):
    cfg["projects"][k] = 0
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
st.db.commit()
PAGE = ("Consistency (database systems). In database systems, consistency (or correctness) refers to "
        "the requirement that any given database transaction must change affected data only in allowed "
        f"ways. In other words, {QUOTE}, preserving database invariants.")
library.put(st, "en.wikipedia.org: Consistency_(database_systems)", PAGE, kind="page", source=URL, root=root)
st.note("post_ref_streak", reference.FREE_POSTS)          # a reference is due
due = reference.must_reference(st)
sys.argv = ["cycle", "--config", cp, "--force"]
try:
    cycle.main()
except SystemExit:
    pass
db = sqlite3.connect(os.path.join(d, "state.sqlite")); db.row_factory = sqlite3.Row
c = db.execute("SELECT outcome, notes FROM cycles ORDER BY id DESC LIMIT 1").fetchone()
print(f"  [post ] a reference was due: {due}; outcome {c['outcome']!r} "
      f"| notes {c['notes']!r} | reached the square: {len(sent)}")
