# ==========================================================================
# Every outside link in a post is a page riffle read, with a passage from
# THAT page quoted; a link anywhere else must at least be on a site riffle
# read, or in something it read.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     post-two      one link quoted correctly from sqlite.org, a second to a
#                   page never read: refused, naming the second
#     post-bare     the second link written without https://: still a link,
#                   still refused
#     post-shared   two pages read, but the one quote is only on the first:
#                   refused, naming the second
#     post-each     two pages read, each with its own quote: queued
#     comment-unread  a comment linking a site riffle never read a page on,
#                   an address in nothing it read: refused (link-unread)
#     comment-host  a comment linking another page on a site it read: passes
#     comment-seen  a comment linking an address a thread it read gave: passes
#     comment-home  a comment linking the registry's own page: passes
#     words         what counts as a link: file names, a site's bare name,
#                   e-mail addresses and code paths do not
#
# WHY IT EXISTS
#   Audit F7 (2026-11-10): the link rule called reference.check once, which
#   passes when any one link is a page read and any one quote is on it, so
#   every other link in a post rode along; a link with no scheme was not a
#   link to it; and a comment, porch line, submission, attestation or flag
#   could carry any URL at all.
#
# HOW IT WORKS
#   One real cycle.main() against a stub registry and composer; the pages
#   riffle "read" are library documents of kind page, as read_page shelves
#   them; the thread it read is a thread_reads row.
#
# READING THE OUTPUT
#   `[case] outcome ... | the refusal names: ...`
#
# RUNNING IT ON ITS OWN
#   python3 tests/send_checks/test_every_link_is_a_page_riffle_read.py . post-two
#
# CHANGELOG
#   2026-11-16  Written for audit F7 (batch 6).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, copy, json, tempfile, sqlite3, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library, reference
from agent.state import State

if mode == "words":
    t = ("See agent/cycle.py:3498 and src/attestations.ts, the sqlite.org docs, mail a@b.com, "
         "e.g. this, v1.2/x, README.md, https://1f916.ai/posts/12, then docs.python.org/3/library/os.html "
         "and https://www.sqlite.org/wal.html, and 1f916.square/docs/durability.")
    print(f"  [words ] links found: {reference.outside_links(t, '1f916.ai')}")
    sys.exit(0)

me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
sent = []
class Stub:
    def __init__(self, *a, **k): pass
    def create_post(self, title, body, url=None):
        sent.append(title); return {"post_id": 901, "created_at": 1}
    def create_comment(self, post_id, body, parent_id=None):
        sent.append(body[:40]); return {"comment_id": 7001, "created_at": 1}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "contribute"
REPLY = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    return json.dumps(REPLY)
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
root = os.path.join(d, "library"); cfg.setdefault("library", {})["root"] = root
cfg["autonomy"]["post"] = "queue"; cfg["autonomy"]["comment"] = "auto"
for k in ("min_notes", "min_sources", "min_drafts", "min_objections"):
    cfg["projects"][k] = 0
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
WAL = ("Write-ahead logging. The WAL approach inverts this. The original content is preserved in the database "
       "file and the changes are appended into a separate WAL file. A COMMIT occurs when a special record "
       "indicating a commit is appended to the WAL.")
PRAGMA = ("PRAGMA synchronous. When synchronous is NORMAL, the SQLite database engine will still sync at the "
          "most critical moments, but less often than in FULL mode.")
library.put(st, "Write-Ahead Logging", WAL, kind="page", source="https://www.sqlite.org/wal.html", root=root)
library.put(st, "Pragma statements", PRAGMA, kind="page", source="https://www.sqlite.org/pragma.html", root=root)
project.record_read(st, 1, 0, 4, "Durability notes", "coppice", 0, 0,
                    "the spec is at https://journal.example.net/durability-2026 if anyone wants it", "", "d4")

Q1 = '"The original content is preserved in the database file and the changes are appended into a separate WAL file."'
Q2 = '"the SQLite database engine will still sync at the most critical moments, but less often than in FULL mode"'
def post(body):
    return {"action": "post", "rationale": "the project is ready and this is what it found",
            "payload": {"title": "What a write-ahead log does and does not promise", "body": body}}
def comment(body):
    return {"action": "comment", "rationale": "answering the thread with what I read",
            "payload": {"post_id": 4, "body": body}}
CASES = {
    "post-two": post(f"SQLite says {Q1} (https://www.sqlite.org/wal.html). A durability spec "
                     "(https://csrc.nist.gov/pubs/sp/800/999/final) sets the bar."),
    "post-bare": post(f"SQLite says {Q1} (https://www.sqlite.org/wal.html). The square's notes are at "
                      "1f916.square/docs/durability."),
    "post-shared": post(f"SQLite says {Q1} (https://www.sqlite.org/wal.html), and see "
                        "https://www.sqlite.org/pragma.html for the sync setting."),
    "post-each": post(f"SQLite says {Q1} (https://www.sqlite.org/wal.html), and of the sync setting "
                      f"{Q2} (https://www.sqlite.org/pragma.html)."),
    "comment-unread": comment("The bar for this is set in https://csrc.nist.gov/pubs/sp/800/999/final, "
                              "which your write-up does not meet."),
    "comment-host": comment("SQLite's own page on it, https://www.sqlite.org/atomiccommit.html, covers "
                            "the rollback-journal side of this."),
    "comment-seen": comment("The spec you linked, https://journal.example.net/durability-2026, asks for "
                            "an fsync per commit, which WAL in NORMAL mode does not give."),
    "comment-home": comment("This was settled in https://1f916.ai/posts/3312 a week ago; the WAL file is "
                            "where the commit lands first."),
}
REPLY.update(CASES[mode])
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite")); db.row_factory = sqlite3.Row
c = db.execute("SELECT outcome, notes FROM cycles ORDER BY id DESC LIMIT 1").fetchone()
print(f"  [{mode:14}] outcome {c['outcome']!r:20} | cycle notes: {c['notes']!r} | reached the square: {len(sent)}")
