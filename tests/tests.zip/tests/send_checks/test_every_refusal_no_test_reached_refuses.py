# ==========================================================================
# Every refusal that no recorded test reached (the mutation sweep of
# 2026-11-27) refuses what it exists to refuse.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one refusal; each runs ONE real cycle.main() with the
#   state that should trigger it and prints the outcome, whether anything
#   reached the registry, and whether the composer was asked at all.
#     queuefull      twenty proposals waiting on the operator: queue-full,
#                    the composer not woken
#     composerbusy   the composer lock held by a chat turn: composer-busy
#     cooldown       a post while posting is closed: cooldown
#     notready       a post with the project bar not cleared: not-ready
#     capreached     a comment with today's comments spent: cap-reached
#     votedalready   a second vote on a post already voted on: voted-already
#     postqueued     a post while another waits for approval: post-queued-already
#     saidalready    a porch line the same as one already sent: said-already
#     commented      a second top-level comment on one post in a day:
#                    already-commented
#     hashunres      a 64-hex "sha256 of my script" no library file has:
#                    hash-unresolvable
#     artifact       a listing submission whose artifact is a short hash:
#                    artifact-unfetchable
#     libpage        library_put filing a note as a fetched page: library-refused
#     askempty       ask_operator with an empty question: ask-refused
#     goalbad        adjust_drive on a drive that does not exist: goal-refused
#     extracapped    request_cycle with today's extra cycles spent: extra-capped
#     noproject      project_note with no project open: no-project
#
# WHY IT EXISTS
#   The mutation sweep of 2026-11-27 (AUDIT-RESPONSE §32): one run of the
#   suite under coverage found 23 refusals whose refusing line no test
#   executed, among them said-already, voted-already, already-commented and
#   post-queued-already, which refused real actions on the box every day.
#   A refusal no test reaches can be switched off unnoticed.
#
# HOW IT WORKS
#   cycle.main() with Reader and Writer stubbed (every send recorded), the
#   composer replaced by the case's proposal, and the planted state each
#   refusal reads.
#
# READING THE OUTPUT
#   `[case] outcome '<outcome>' | sent: yes/no | composer asked: yes/no`
#
# RUNNING IT ON ITS OWN
#   With the variables tests/run_all.sh sets; simplest is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-27  Written from the coverage sweep (batch 26).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, time
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library, chat, desk
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
SENT = []
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        if n == "listings" and mode == "artifact":
            return lambda *a, **k: {"listings": [{"id": 65, "title": "Marrow", "lifecycle": "open"}]}
        if n.startswith(("create_", "vote", "porch", "tag", "submit", "attest", "seal")):
            return lambda *a, **k: (SENT.append(n) or {"ok": True, "comment_id": 9, "post_id": 9})
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
DRIVE = {"queuefull": "understand", "composerbusy": "understand", "cooldown": "make",
         "notready": "make", "capreached": "answer", "votedalready": "curate", "postqueued": "make",
         "saidalready": "greet", "commented": "contribute", "hashunres": "contribute",
         "artifact": "earn", "libpage": "understand", "askempty": "understand",
         "goalbad": "understand", "extracapped": "understand", "noproject": "deepen"}[mode]
drives.pick_drive = lambda *a, **k: DRIVE
ASKED = []
REPLY = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    ASKED.append(1)
    return json.dumps(dict(REPLY, rationale="a reason long enough for the gate"))
cortex.complete = complete

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
for k in list(cfg["autonomy"]):
    if cfg["autonomy"][k] == "queue" and k not in ("post", "listing_submission"):
        cfg["autonomy"][k] = "auto"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root); desk.ensure(st)
now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
if mode != "noproject":
    st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
def action(kind, payload, status, response=None, ago="0 seconds"):
    st.db.execute("INSERT INTO actions (cycle_id, created_at, kind, drive, payload, rationale, status, response)"
                  f" VALUES (0, strftime('%Y-%m-%dT%H:%M:%SZ','now','-{ago}'), ?, 'x', ?, 'r', ?, ?)",
                  (kind, json.dumps(payload), status, json.dumps(response) if response else None))
from agent import project as _pj
st.db.executescript(_pj.READS_SCHEMA)

if mode == "queuefull":
    for i in range(int(cfg.get("max_queued", 20))):
        action("post", {"title": f"t{i}", "body": "b"}, "queued")
    REPLY.update(action="noop", payload={"why": "x"})
elif mode == "composerbusy":
    chat.ComposerLock.acquire = lambda self, *a, **k: False
    REPLY.update(action="noop", payload={"why": "x"})
elif mode in ("cooldown", "notready", "postqueued"):
    import datetime as _dt
    _until = _dt.datetime.now(_dt.timezone.utc) + _dt.timedelta(hours=5)
    project.in_cooldown = (lambda *a, **k: (True, _until, 5.0)) if mode == "cooldown" else (lambda *a, **k: (False, None, 0))
    project.ready = (lambda *a, **k: (False, "the project needs two more notes")) if mode == "notready" else (lambda *a, **k: (True, ""))
    if mode == "postqueued":
        action("post", {"title": "the first one", "body": "waiting"}, "queued")
    REPLY.update(action="post", payload={"title": "A finding", "body": "Something worth saying, plainly."})
elif mode == "capreached":
    cfg["caps"]["comment"] = 0
    REPLY.update(action="comment", payload={"post_id": 4, "body": "A reply that says something new."})
elif mode == "votedalready":
    st.db.execute("INSERT INTO thread_reads (post_id, title, digest) VALUES (123, 'a thread', 'd')")
    action("vote", {"target_type": "post", "target_id": 123}, "executed", ago="2 hours")
    REPLY.update(action="vote", payload={"target_type": "post", "target_id": 123})
elif mode == "saidalready":
    action("porch", {"body": "Good morning. The tripwire project is ready to post once the build is appended."},
           "executed", ago="2 hours")
    REPLY.update(action="porch", payload={"body": "Good morning. The tripwire project is ready to post once the build is appended."})
elif mode == "commented":
    action("comment", {"post_id": 77, "body": "My first top-level comment on this thread."}, "executed", ago="3 hours")
    REPLY.update(action="comment", payload={"post_id": 77, "body": "A different top-level comment on the same thread."})
elif mode == "hashunres":
    # The hash is one the build PRINTED, the build appended so a reader (and
    # the number check) can see it, presented as the hash of the script,
    # which no library file has.
    H = "ab12cd34ef56ab12cd34ef56ab12cd34ef56ab12cd34ef56ab12cd34ef56ab12"
    _c, _ = library.put(st, "solve.py — a build", "import hashlib\nprint(hashlib.sha256(b'x').hexdigest())\n",
                        kind="code", source="build:c1", root=root)
    library.put(st, "output of solve.py — a build", H + "\n", kind="data", source="build:c1:stdout", root=root)
    st.note("last_build", json.dumps({"entry": "solve.py", "stdout": H + "\n", "ok": True,
                                      "files": ["solve.py"], "at": now}))
    REPLY.update(action="comment", payload={"post_id": 5, "body": "My script checks out: sha256 " + H + ".",
                                            "append": [_c]})
elif mode == "artifact":
    REPLY.update(action="listing_submission", payload={"listing_id": 65, "artifact": "#415",
                                                       "note": "my artifact"})
elif mode == "libpage":
    REPLY.update(action="library_put", payload={"title": "my notes", "body": "my own notes on the thread", "kind": "page"})
elif mode == "askempty":
    from agent import state as _state
    _state.ask_operator(st, "Should I close the tripwire project unposted?", "it is stuck", 0)
    REPLY.update(action="ask_operator", payload={"question": "Should I close the tripwire project unposted?",
                                                 "why": "it is stuck"})
elif mode == "goalbad":
    REPLY.update(action="adjust_drive", payload={"name": "understand", "weight": 0.95,
                 "reason": "I want to read far more than I do now, all day."})
elif mode == "extracapped":
    st.note("extra_cycles_" + now[:10], str(int((cfg.get("extra_cycles") or {}).get("max_per_day", 12))))
    REPLY.update(action="request_cycle", payload={"reason": "I want another go at the thread right away"})
elif mode == "noproject":
    REPLY.update(action="project_note", payload={"kind": "objection", "text": "A note with nowhere to go."})
st.db.commit()
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
oc = sqlite3.connect(os.path.join(d, "state.sqlite")).execute(
    "SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
print(f"  [{mode:12}] outcome {oc!r:24} | sent: {'yes' if SENT else 'no'} | composer asked: {'yes' if ASKED else 'no'}")
if oc == "blocked":
    for r in st.db.execute("SELECT content FROM messages WHERE role IN ('report','error') ORDER BY id DESC LIMIT 1"):
        print(f"  [{mode:12}] the gate: {' '.join((r[0] or '').split())[-160:]}")
