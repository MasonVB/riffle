# ==========================================================================
# Below the disk limit, telemetry is kept: samples, dumps and each boot's
# kept rows, however old and however many. (It used to keep samples for a
# day and dumps for 21 days, 500 at most.)
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   A store with three samples (2 h, 30 h and 30 days old), 604 dumps (600
#   from an error run two days ago) and a 30-day-old kept-boot row, after
#   storage.check with the disk 40% used (stood in): how many of each are
#   left, and whether telemetry still has its own prune.
#
# WHY IT EXISTS
#   M6 (audit round 1): dumps were never pruned, so telemetry got a prune.
#   The operator's rule of 2026-11-19 replaced it: everything is kept until
#   the disk is 85% used, and past that only as much of the oldest goes as
#   is newly saved (tests/dashboard/test_past_the_disk_limit_...).
#
# HOW IT WORKS
#   Fills a store, runs the check, counts.
#
# READING THE OUTPUT
#   `below the limit: samples N of 3, dumps M of 604, kept-boot rows K of 1
#   | telemetry.prune exists: ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/telemetry/test_pruning_keeps_recent_samples_and_at_most_500_dumps.py .
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (tm6p.py) for M6.
#   2026-11-05  Moved into tests/telemetry.
#   2026-11-19  Turned round for the disk rule (batch 14): telemetry.prune is
#               gone, and below the limit nothing is deleted. The file keeps
#               its name so the record's order stands.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, datetime as dt; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import telemetry as T, storage
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite")); T.ensure(st)
now = dt.datetime.now(dt.timezone.utc)
iso = lambda d: d.isoformat(timespec="seconds").replace("+00:00", "Z")
ins = lambda ts, kind: st.db.execute("INSERT INTO telemetry (ts,kind,label,payload) VALUES (?,?,'x','{}')", (iso(ts), kind))
for h in (2, 30, 30 * 24): ins(now - dt.timedelta(hours=h), "sample")
for h in (2, 30, 10 * 24, 25 * 24): ins(now - dt.timedelta(hours=h), "dump")
for i in range(600): ins(now - dt.timedelta(hours=48, minutes=i), "dump")         # a run of errors two days ago
if hasattr(T, "boot_id"):
    st.db.execute("INSERT INTO telemetry_kept (boot,ts,kind,label,payload) VALUES ('A',?,'sample','x','{}')", (iso(now - dt.timedelta(days=30)),))
st.db.commit()
storage.disk_used_percent = lambda p: 40.0
storage.check(st, {})
c = lambda q: st.db.execute(q).fetchone()[0]
samples = c("SELECT COUNT(*) FROM telemetry WHERE kind='sample'")
dumps = c("SELECT COUNT(*) FROM telemetry WHERE kind='dump'")
extra = f", kept-boot rows {c('SELECT COUNT(*) FROM telemetry_kept')} of 1" if hasattr(T, "boot_id") else ""
print(f"  below the limit: samples {samples} of 3, dumps {dumps} of 604{extra} | telemetry.prune exists: {hasattr(T, 'prune')}")
