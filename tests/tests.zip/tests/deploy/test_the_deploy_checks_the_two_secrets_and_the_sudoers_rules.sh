#!/bin/bash
# ==========================================================================
# The deploy checks changed files for the citizen secret and the signing
# seed as root (it cannot read them as you), and reports sudoers rules that
# have fallen behind the repo.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   On a scratch "box": a citizen secret, a raw 32-byte signing seed, and a
#   commit that adds two files, one holding the secret and one the seed's
#   hex. Then two installed sudoers rules, one matching the repo and one not.
#   Prints what each of update.sh's two blocks says.
#
# WHY IT EXISTS
#   Audit F31 (2026-11-10): the scan ran as you and skipped, without a word,
#   the two files you cannot read, which are the two secrets that matter;
#   and the report of hand-installed copies left out the sudoers rules.
#
# HOW IT WORKS
#   Each block is cut out of the real update.sh (from its comment header to
#   the next) with its fixed paths (/var/lib/riffle, /var/lib/riffle-signer,
#   /opt/riffle) pointed at the scratch box, and run with tests/lib's
#   stand-in sudo, which never gains privilege.
#
# READING THE OUTPUT
#   The blocks' own lines; the scratch path is shown as <box>, and their
#   `!!` warnings as `WARNS:` (run_all.sh uses `!!` for its own lines).
#
# RUNNING IT ON ITS OWN
#   Through tests/run_all.sh (it needs RIFFLE_TMP and RIFFLE_TESTS).
#
# CHANGELOG
#   2026-11-18  Written for audit F31 (batch 10).
# ==========================================================================
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
U=$(realpath "$1"); export PATH="$RIFFLE_TESTS/lib/stand_in_sudo:$PATH"
B=$(mktemp -d "$RIFFLE_TMP/box.XXXX")
mkdir -p "$B/var/lib/riffle" "$B/var/lib/riffle-signer" "$B/opt/riffle/bin" "$B/etc/sudoers.d"
SECRET="1f916_sk_scratchsecret_for_the_test_0123456789"
printf '%s\n' "$SECRET" > "$B/var/lib/riffle/riffle.secret"
python3 -c "import os; open('$B/var/lib/riffle-signer/citizen.seed','wb').write(bytes(range(32)))"
SEEDHEX=$(python3 -c "print(bytes(range(32)).hex())")
cd "$B/opt/riffle" && git init -q && git -c user.email=t@t -c user.name=t commit -q --allow-empty -m start
BEFORE=$(git rev-parse HEAD)
echo "token = \"$SECRET\"" > leaked.py
echo "seed: $SEEDHEX" > notes.txt
echo "clean" > fine.txt
git add . && git -c user.email=t@t -c user.name=t commit -qm leak
AFTER=$(git rev-parse HEAD)
block() {  # $1 = the line the block starts with, $2 = the line the next starts with
  awk -v a="$1" -v b="$2" 'index($0,a)==1{on=1} index($0,b)==1&&on&&!first{first=1; if(NR>1&&seen)exit} on{print; seen=1}' "$U" \
    | sed "s#/var/lib/riffle-signer/#$B/var/lib/riffle-signer/#g; s#/var/lib/riffle/#$B/var/lib/riffle/#g; s#\"/opt/riffle\"#\"$B/opt/riffle\"#g; s#/opt/riffle/#$B/opt/riffle/#g"
}
echo "== the literal check, as root"
{ echo "BEFORE=$BEFORE; AFTER=$AFTER"; block "# THE TWO SECRETS THAT MATTER" "# Two gates, in order"; } > "$B/lit.sh"
bash "$B/lit.sh" 2>&1 | sed "s#$B#<box>#g; s/^!! /  WARNS: /"
echo "== the same, with neither secret on the box"
rm -f "$B/var/lib/riffle/riffle.secret" "$B/var/lib/riffle-signer/citizen.seed"
bash "$B/lit.sh" 2>&1 | sed "s#$B#<box>#g; s/^!! /  WARNS: /"
echo "== the sudoers rules"
printf 'riffle ALL=(root) NOPASSWD: /usr/local/bin/riffle-build\n' > bin/sudoers-riffle-build
printf 'riffle ALL=(root) NOPASSWD: /usr/local/bin/riffle-reader\n' > bin/sudoers-riffle-reader
cp bin/sudoers-riffle-build "$B/etc/sudoers.d/riffle-build"
printf 'riffle ALL=(root) NOPASSWD: ALL\n' > "$B/etc/sudoers.d/riffle-reader"
{ echo "RIFFLE_INSTALL_ROOT=$B"; block "# --- the sudoers rules, which are hand-installed too" "# --- hand-installed copies that have fallen behind"; } > "$B/sud.sh"
bash "$B/sud.sh" 2>&1 | sed "s#$B#<box>#g; s/^!! /  WARNS: /"
cd / && rm -rf "$B"
