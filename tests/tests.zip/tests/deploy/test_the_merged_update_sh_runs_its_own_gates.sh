#!/bin/bash
# ==========================================================================
# After the merge, update.sh carries on as the MERGED file, not as the copy
# bash was reading before it, and the cycle lock is still held.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   A scratch remote holds version 1 of update.sh; a clone of it is the
#   "box". Version 2 is pushed to the remote, and the box's version 1 is run.
#   Each version ends, after the merge, by printing its own name and whether
#   the cycle lock is still held. Prints which version's code ran after the
#   merge, and the lock's state there.
#
# WHY IT EXISTS
#   Audit F18 (2026-11-10): git merge replaces update.sh with a new file,
#   and bash goes on reading the old one, so every gate ran as the previous
#   version's code against the new tree. A commit changing a mirrored line
#   and its gate together was rolled back every time.
#
# HOW IT WORKS
#   The real update.sh, from its first line to its `git log` line after the
#   merge, with `cd /opt/riffle` pointed at the clone, and a two-line tail
#   per version. sudo is tests/lib/stand_in_sudo (never gains privilege).
#
# READING THE OUTPUT
#   `after the merge, the code that ran was: version N` and the lock line.
#
# RUNNING IT ON ITS OWN
#   Through tests/run_all.sh (it needs RIFFLE_TMP and RIFFLE_TESTS).
#
# CHANGELOG
#   2026-11-17  Written for audit F18 (batch 8).
# ==========================================================================
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
command -v flock >/dev/null || { echo "  SKIPPED: needs flock (util-linux)"; exit 0; }
U=$(realpath "$1"); export PATH="$RIFFLE_TESTS/lib/stand_in_sudo:$PATH"
D=$(mktemp -d "$RIFFLE_TMP/merged.XXXX")
git init -q --bare "$D/origin.git"
git -C "$D" clone -q "$D/origin.git" work 2>/dev/null
touch "$D/cycle.lock"
make_version() {   # $1 = the version's name
  awk '{print} /^git --no-pager log --oneline/{exit}' "$U" \
    | sed "s#^cd /opt/riffle\$#cd \"$D/box\"#" > "$D/work/update.sh"
  cat >> "$D/work/update.sh" <<EOF
echo "  after the merge, the code that ran was: $1"
python3 -c "import fcntl,sys; f=open('$D/cycle.lock'); fcntl.flock(f, fcntl.LOCK_EX|fcntl.LOCK_NB)" 2>/dev/null \\
  && echo "  the cycle lock there: FREE (a cycle could start mid-deploy)" \\
  || echo "  the cycle lock there: held"
EOF
  git -C "$D/work" add update.sh
  git -C "$D/work" -c user.email=t@t -c user.name=t commit -qm "$1"
  git -C "$D/work" push -q origin HEAD:master 2>/dev/null
}
make_version "version 1"
git -C "$D" clone -q "$D/origin.git" box 2>/dev/null
make_version "version 2"
( cd "$D/box" && RIFFLE_CYCLE_LOCK="$D/cycle.lock" RIFFLE_LOCK_WAIT=5 bash ./update.sh 2>&1 ) \
  | grep -E "after the merge|cycle lock there|merged; running" | sed 's/^  //; s/^/  /'
rm -rf "$D"
