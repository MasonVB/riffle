# ==========================================================================
# riffle-restart-composer.service creates the lock files it takes as riffle,
# not as root, and in a way that cannot replace a file already locked.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For each file the unit's ExecStart takes with flock: whether an earlier
#   ExecStartPre touches it as riffle (runuser -u riffle -- touch), and
#   whether anything in the unit would replace it (install, cp, mv, rm).
#
# WHY IT EXISTS
#   Audit F27 (2026-11-10): the unit runs as root, and flock creates a lock
#   file that does not exist yet. On a fresh install or a restored data
#   directory, cycle.lock or composer.lock became root's, and the cycle,
#   which opens cycle.lock "a+" as riffle, could not open it.
#
# HOW IT WORKS
#   Reads systemd/riffle-restart-composer.service; runs nothing.
#
# READING THE OUTPUT
#   One line per lock file.
#
# RUNNING IT ON ITS OWN
#   python3 tests/deploy/test_the_composer_restart_never_creates_a_lock_file_as_root.py .
#
# CHANGELOG
#   2026-11-17  Written for audit F27 (batch 8).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import os, re, shlex, sys
repo = sys.argv[1]
lines = [l.strip() for l in open(os.path.join(repo, "systemd", "riffle-restart-composer.service"))
         if l.strip() and not l.strip().startswith("#")]
pre = [l.split("=", 1)[1].lstrip("-+!@:") for l in lines if l.startswith("ExecStartPre=")]
start = next(l.split("=", 1)[1] for l in lines if l.startswith("ExecStart="))
locks = re.findall(r"flock\s+(/\S+)", start)
touched = set()
for cmd in pre:
    w = shlex.split(cmd)
    if w[:3] == ["/usr/sbin/runuser", "-u", "riffle"] and "--" in w and w[w.index("--") + 1].endswith("/touch"):
        touched |= set(w[w.index("--") + 2:])
replaces = [c for c in pre if re.search(r"(^|/)(install|cp|mv)\s", c)]
for lk in locks:
    gone = [c for c in pre if re.search(r"(^|/)rm\s", c) and lk in c]
    print(f"  {lk}: created as riffle before flock: {lk in touched} | removed or replaced first: "
          f"{bool(gone or [c for c in replaces if lk in c])}")
