# ==========================================================================
# A broken chain raises the alarm on whatever page of the walk it shows up,
# and on a first run with no mark saved, not only on the first page's
# re-check of a saved mark.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     later   a mark is saved; identity is 26,728 rows long, paged 20,000 at
#             a time, and the second page comes back `broken`
#     first   no mark saved yet; the very first page comes back `broken`
#   Each prints the alarm lines, whether you were notified, and whether a
#   mark was saved over it.
#
# WHY IT EXISTS
#   Audit F20 (2026-11-10): do_witness acted on an alarm verdict only when
#   `walked == 1 and prior[name]`. A broken page later in a walk, or any
#   alarm on a first run, fell through to "did not verify this pass" at warn
#   level. witness.py treats the same verdicts as alarms on every page.
#
# HOW IT WORKS
#   cycle.do_witness with a stand-in reader, as the other witness tests;
#   notify.alarm is recorded rather than sent.
#
# READING THE OUTPUT
#   `[case] alarms: [...] | notified: N | identity mark: ...`
#
# RUNNING IT ON ITS OWN
#   python3 tests/witness/test_a_broken_chain_alarms_on_any_page_and_on_a_first_run.py . later
#
# CHANGELOG
#   2026-11-17  Written for audit F20 (batch 8).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import cycle, notify
mode = sys.argv[2]
TOTAL = {"identity": 26728, "ledger": 500}; PAGE = 20000
def h(c, n): return f"{c}-h{n}"


class FakeReader:
    def attest(self, **q):
        out = {}
        for c, key in (("identity", "identity_log"), ("ledger", "treasury")):
            frm = int(q.get(f"{c}_from", 0)); tot = TOTAL[c]
            end = min(frm + PAGE, tot)
            broken = c == "identity" and ((mode == "later" and frm >= 20000) or (mode == "first" and frm == 0))
            if broken:
                out[key] = {"status": "broken", "verified_through_id": frm, "head": h(c, tot)}
                continue
            out[key] = {"status": "verified" if end == tot else "incomplete", "verified_through_id": end,
                        "verified_head": h(c, end), "head": h(c, tot),
                        "expect_matches": True if q.get(f"{c}_expect") else None}
        return out


told = []
notify.alarm = lambda state, cfg, text, log=None: told.append(text)
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
if mode == "later":
    st.save_head("identity", h("identity", 0), 0)
    st.save_head("treasury", h("ledger", 0), 0)
logs = []
cycle.do_witness(st, FakeReader(), lambda t, level="info", **k: logs.append((level, t)))
mark = st.last_head("identity")
print(f"  [{mode:5}] alarms: {[t[:90] for l, t in logs if l == 'alarm']}")
print(f"  [{mode:5}] notified: {len(told)} | warn lines: {len([1 for l, t in logs if l == 'warn'])} | "
      f"identity mark: {dict(mark)['through_id'] if mark else None}")
