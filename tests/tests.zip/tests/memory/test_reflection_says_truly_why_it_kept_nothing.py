# ==========================================================================
# When reflection keeps nothing, its log says why: duplicates (a warning),
# or only passing notes offered, which are kept only beside durable ones
# (not a fault).
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   memory.reflect on two ended cycles, the triage model a stand-in:
#     the first reply offers one durable note already stored, and a passing one
#     the second offers two passing notes and nothing durable
#   Prints, for each, how many notes were kept and the line it logged.
#
# WHY IT EXISTS
#   The box's figures for 2026-11-18: three of fifteen warnings were
#   "model offered 0 durable and N passing, kept 0 (too short, or duplicates
#   of something already stored)". Passing notes are kept at 5-10% of the
#   durable ones kept, so with none durable none can be: not short, not
#   duplicates, and not a fault. And the other way round: a durable note
#   that repeated a stored one was counted as kept ("kept 1 note(s)"),
#   because remember() returns the id of the memory it matched.
#
# HOW IT WORKS
#   The real reflect on a fresh store, cortex.complete replaced.
#
# READING THE OUTPUT
#   `[case] kept N | [level] the line`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/memory/test_reflection_says_truly_why_it_kept_nothing.py .
#
# CHANGELOG
#   2026-11-19  Written from the box's figures (batch 13).
#   2026-11-24  The warning counts the notes dropped for a reason already
#               logged (batch 20's footing checks, batch 22's repeat check):
#               "too short, or duplicates" was all it ever said, and on the
#               box most of the "kept 0" cycles were those drops.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile, yaml
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import memory, cortex
from agent.state import State

cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = tempfile.mkdtemp()
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))
STORED = "I was refused a post because posting is closed until the clock opens."
memory.remember(st, STORED, kind="self", source="test", ttl_days=7)
REPLIES = [f"DURABLE\n- me: {STORED}\nPASSING\n- the front page had nine posts about witnesses",
           "DURABLE\nNONE\nPASSING\n- the front page had nine posts about witnesses\n"
           "- kilmon-ai replied twice in the same hour"]
cortex.complete = lambda *a, **k: REPLIES.pop(0)
for case in ("a duplicate", "passing only"):
    cid = st.begin_cycle("understand")
    st.end_cycle(cid, "noop")
    said = []
    made = memory.reflect(st, cfg, log=lambda t, level="info": said.append((level, t)))
    line = next((f"[{lv}] {t}" for lv, t in said if "reflected on" in t), None)
    print(f"  [{case:12}] kept {len(made)} | {line[:150] if line else None}")
