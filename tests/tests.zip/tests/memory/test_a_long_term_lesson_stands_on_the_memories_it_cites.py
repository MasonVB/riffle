# ==========================================================================
# A long-term lesson consolidation writes stands on the memories it cites,
# and loses long term when one of them is found wrong.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   One daily pass over three short-term notes (one of them a borrowed
#   refusal reason), with four long-term writes:
#     grounded   cites the notes it is made of: long term, its sources in
#                `source`
#     uncited    cites nothing: kept, short term
#     unfounded  cites a note and says something else (memory 1540's "I must
#                rename the artifact"): kept, short term
#     echo       the prompt's own instructions: not written
#   Then the source of the grounded lesson is forgotten (as the operator did
#   by hand on 2026-11-22): the lesson goes back to short term, to expire
#   unless it earns its place again.
#
# WHY IT EXISTS
#   2026-11-22: two of the wrong memories retired by hand, 1540 and 1643,
#   were consolidation's long-term writes. Long term never expires, and a
#   write carried no record of what it came from.
#
# HOW IT WORKS
#   consolidate.run with cortex.complete stubbed to the plan; memory.forget.
#
# READING THE OUTPUT
#   `[write] <case> -> tier, source` and `[forget] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/memory/test_a_long_term_lesson_stands_on_the_memories_it_cites.py .
#
# CHANGELOG
#   2026-11-23  Written with consolidate's "from" and memory.demote_citing (batch 21).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import memory, consolidate, cortex
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = tempfile.mkdtemp()
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))
a = memory.remember(st, "kilmon-ai checks every percentage in a reply against its own counts", kind="self")
b = memory.remember(st, "My figure on #12557 was wrong and kilmon-ai found it within the hour", kind="self")
c = memory.remember(st, "The board refused my listing submission because the artifact name was under eight characters", kind="self")
st.db.commit()
W = {
    "grounded": {"text": "kilmon-ai checks figures within the hour: count every percentage before replying",
                 "tier": "long", "from": [a, b], "why": "w"},
    "uncited": {"text": "Bishop prefers proofs to simulations in every thread", "tier": "long", "from": [], "why": "w"},
    "unfounded": {"text": "I must rename the artifact so the registry accepts it for Listing 65",
                  "tier": "long", "from": [b], "why": "w"},
    "echo": {"text": "one durable sentence standing in for several short-term ones you would otherwise promote",
             "tier": "short", "from": [a], "why": "w"},
}
plan = {"promote": [], "write": list(W.values()), "drop": [], "note": "n"}
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps({"continuity": "I keep a short note."}) \
    if "continuity" in (schema or {}).get("required", []) else json.dumps(plan)
said = []
consolidate.run(st, cfg, lambda *a, **k: None, say=lambda *a, **k: said.append(" ".join(str(x) for x in a)))
ids = {}
for name, w in W.items():
    r = st.db.execute("SELECT id, tier, source, expires_at IS NOT NULL AS exp FROM memories WHERE text=?", (w["text"],)).fetchone()
    ids[name] = r["id"] if r else None
    src = (r["source"] or "").replace(f"{a}", "<a>").replace(f"{b}", "<b>") if r else ""
    print(f"  [write] {name:9} -> " + (f"tier {r['tier']}{', expires' if r['exp'] else ''}, source {src}" if r else "not written"))
memory.forget(st, a)
r = st.db.execute("SELECT tier, expires_at IS NOT NULL AS exp FROM memories WHERE id=?", (ids["grounded"],)).fetchone()
print(f"  [forget] its source <a> forgotten: the grounded lesson is now tier {r['tier']}{', expires' if r['exp'] else ''}")
