# ==========================================================================
# Reflection files each note by the label the model gives it (`me:` or
# `square:`), and is given the front page only when reflecting on the
# newest cycle, the one that page belongs to.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   For two reflections (an older cycle, then the newest), whether the
#   front page was in the material (False, then True), and the kind each
#   note was filed under: a stranger's claim from it is filed as board.
#
# WHY IT EXISTS
#   H4 and M1 (audit round 1): reflection was shown the front page
#   (other citizens' words) and filed notes by guesswork; its example
#   taught an invented rule.
#
# HOW IT WORKS
#   Runs memory.reflect twice with a stub model that answers labelled
#   notes.
#
# READING THE OUTPUT
#   `reflecting on cycle N of 2: front page given = False|True`, then
#   `filed as self|board | ...` per note.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-10-29  Written in the sandbox (trefl.py) for H4 and M1.
#   2026-11-05  Moved into tests/memory.
#   2026-11-18  Header corrected (audit 2026-11-14, 7.2 item 7): it said
#               "never given the front page", and the output it records has
#               it given for the newest cycle, which is H4's rule (the
#               stored page is that cycle's). The file name is older than
#               H4's fix and is kept so the list and the record still match.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml; sys.path.insert(0, sys.argv[1])
from agent.state import State
from agent import memory, cortex
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = tempfile.mkdtemp()
cfg.setdefault("memory", {})["reflect_max_per_cycle"] = 5
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))
for _ in range(2):
    c = st.begin_cycle("understand"); st.end_cycle(c, "noop", "")
st.note("last_front_digest", "FRONT-PAGE-MARKER #9823 by coppice: the ever clause")
seen = []
OUT = """DURABLE
- me: I may reply to a comment only once, so I answer what they said since.
- square: coppice claimed in #9823 that the ever clause breaks absence claims.
- Mallow argued in #9747 that receipts settle in order every time.
- **square:** no-scheduler offered five probes in #9689 against the law I hold.
PASSING
- the front page was quiet today"""
def complete(llm, system, user, schema=None, **k):
    seen.append(user); return OUT
cortex.complete = complete
for n in (1, 2):
    memory.reflect(st, cfg, lambda *a, **k: None)
    print(f"  reflecting on cycle {n} of 2: front page given = {'FRONT-PAGE-MARKER' in seen[-1]}")
rows = st.db.execute("SELECT kind, text FROM memories WHERE source='cycle:1' AND kind!='incidental' ORDER BY id").fetchall()
for r in rows: print(f"  filed as {r[0]:6} | {r[1][:70]}")
