# ==========================================================================
# Reflection's failure counts are deleted once the marker has passed their
# cycle; and when the store is over its limit, expired and superseded
# memories are pruned before any live one.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     fails   notes reflect_fail_5, _9 and _12 with the marker at cycle 9:
#             which are left after memory.reflect runs (nothing to reflect on)
#     prune   six short-term memories, the store's limit set to three: a live
#             one used twice, two live never used, an expired one used three
#             times, a superseded one used once, an expired one never used.
#             Which three memory.prune deletes, and that the search index
#             loses their words too
#
# WHY IT EXISTS
#   The box's figures on 2026-11-18: 494 reflect_fail_* notes, never deleted
#   (the second audit pass named them under F26, and batch 9 missed them);
#   and the store at exactly its 1,200 limit, 765 of them expired, with the
#   prune taking the least-used first, so an expired note recalled once went
#   after a live one never recalled.
#
# HOW IT WORKS
#   The real functions on a fresh store.
#
# READING THE OUTPUT
#   `[fails] left: [...]`; `[prune] deleted: [...] | kept: [...]`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/memory/test_failure_counts_are_cleared_and_dead_memories_are_pruned_first.py . prune
#
# CHANGELOG
#   2026-11-19  Written from the box's figures (batch 12).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import memory
from agent.state import State

cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = tempfile.mkdtemp()
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))

if mode == "fails":
    for c in (5, 9, 12):
        st.note(f"reflect_fail_{c}", "1")
    st.note("reflect_fail_note_kept", "not a cycle's count")
    st.note("last_reflected_cycle", 9)
    memory.reflect(st, cfg)
    left = [r[0] for r in st.db.execute("SELECT key FROM notes WHERE key LIKE 'reflect_fail%' ORDER BY key")]
    print(f"  [fails] left: {left}")
else:
    rows = {}
    for name, text, use, dead in (
            ("live-used", "the registry help page says receipts settle per batch", 2, None),
            ("live-new-a", "kilmon-ai found an arithmetic slip in thread twelve", 0, None),
            ("live-new-b", "gradient-dissent asked for mutation tests on the projection", 0, None),
            ("expired-used", "posting closes until the clock reaches the next window", 3, "expired"),
            ("superseded", "the witness chain was at a different mark this morning", 1, "superseded"),
            ("expired-new", "cairnfield disputed the rule of three for consistency", 0, "expired")):
        mid = memory.remember(st, text, kind="self", source="test", ttl_days=7)
        rows[mid] = name
        st.db.execute("UPDATE memories SET use_count=? WHERE id=?", (use, mid))
        if dead == "expired":
            st.db.execute("UPDATE memories SET expired=1 WHERE id=?", (mid,))
        elif dead == "superseded":
            st.db.execute("UPDATE memories SET superseded_by=? WHERE id=?", (min(rows), mid))
    st.db.commit()
    gone = memory.prune(st, keep=3)
    kept = {r[0] for r in st.db.execute("SELECT id FROM memories")}
    deleted = [rows[m] for m in sorted(rows) if m not in kept]
    found = st.db.execute("SELECT COUNT(*) FROM memories_fts WHERE memories_fts MATCH 'cairnfield'").fetchone()[0]
    print(f"  [prune] deleted {gone}: {deleted} | kept: {[rows[m] for m in sorted(kept)]}")
    print(f"  [prune] 'cairnfield' still in the search index: {bool(found)}")
