# ==========================================================================
# The daily memory pass rebuilds the search index once, and again whenever
# it no longer has one entry per memory, so words left behind by the old
# delete faults stop matching.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     inherited  a memory deleted the old way (row gone, words left in the
#                index), then a new one written into its row id: a search
#                for the deleted memory's word finds the new, unrelated
#                memory; after the pass, it finds nothing
#     drift      the index has entries for memories that are gone: the pass
#                rebuilds it (once), the counts agree after, and the next
#                pass leaves it alone
#
# WHY IT EXISTS
#   Audit F39 (2026-11-14): rebuild_index was written to repair stores hit by
#   two old faults (forget passed the wrong text; the purge never touched the
#   index), and nothing called it. The box had 1,007 index entries for 999
#   memories, and words left by a delete with the wrong text do not show in
#   that count at all.
#
# HOW IT WORKS
#   memory.remember and memory.recall on a fresh store; the old faults
#   reproduced with the SQL they ran; consolidate.run with a stub composer.
#
# READING THE OUTPUT
#   `[case] ...`
#
# RUNNING IT ON ITS OWN
#   python3 tests/memory/test_the_memory_search_index_is_rebuilt_once_and_
#   when_it_drifts.py . inherited
#
# CHANGELOG
#   2026-11-16  Written for audit F39 (batch 7).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent.state import State
from agent import memory, consolidate, cortex
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = tempfile.mkdtemp()
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps(
    {"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else
    {"promote": [], "write": [], "drop": [], "note": ""})
said = []
counts = lambda: (st.db.execute("SELECT COUNT(*) FROM memories_fts_docsize").fetchone()[0],
                  st.db.execute("SELECT COUNT(*) FROM memories").fetchone()[0])


def old_delete(mid, with_text=""):
    """What forget() did before its fix: the row goes, the index is told the wrong text."""
    st.db.execute("DELETE FROM memories WHERE id=?", (mid,))
    st.db.execute("INSERT INTO memories_fts (memories_fts,rowid,text) VALUES ('delete',?,?)", (mid, with_text))
    st.db.commit()


def run_pass():
    st.note("last_consolidation", "")
    consolidate.run(st, cfg, lambda m, **k: said.append(m))


FILLER = ("Ledger receipts settle in batch order only.", "The docket lists open work by age.",
          "Porch lines are read most in the morning.", "Witness marks lapse after two days.",
          "A seal names a document by its hash.")
for i, t in enumerate(FILLER):
    memory.remember(st, t, kind="self", source=f"cycle:{i}")
# What the index matches, read straight from it (recall falls back to recent
# memories when nothing matches, which would hide the fault).
matches = lambda w: [r["text"][:50] for r in st.db.execute(
    "SELECT m.text FROM memories_fts f JOIN memories m ON m.id=f.rowid WHERE memories_fts MATCH ?", (w,))]
if mode == "inherited":
    gone = memory.remember(st, "The zephyrine settlement window closes at 04:00 UTC.", kind="self", source="cycle:9")
    old_delete(gone)
    new = memory.remember(st, "Coppice prefers short replies with a link to the method.", kind="self", source="cycle:10")
    hits = matches("zephyrine")
    print(f"  [inherited] deleted #{gone}, then wrote #{new}; counts index/memories {counts()}")
    print(f"  [inherited] searching 'zephyrine' before the pass finds: {hits}")
    run_pass()
    hits = matches("zephyrine")
    print(f"  [inherited] after the pass: {hits}; the journal: {[m for m in said if 'index' in m]}")
else:
    extra = [memory.remember(st, t, kind="self", source="cycle:20") for t in (
        "Custody anchors move weekly.", "Signers rotate at the epoch.", "Bindings expire unless renewed.")]
    for mid in extra:                                   # the old purge: rows deleted, index untouched
        st.db.execute("DELETE FROM memories WHERE id=?", (mid,))
    st.db.commit()
    print(f"  [drift    ] before the pass, index/memories: {counts()}")
    run_pass()
    print(f"  [drift    ] after the first pass: {counts()}; the journal: {[m for m in said if 'index' in m]}")
    said.clear(); run_pass()
    print(f"  [drift    ] a second pass rebuilt it again: {bool([m for m in said if 'index' in m])}")
