# ==========================================================================
# Reflection keeps only what the cycle itself shows; a chat note is the
# operator's only in his words; and riffle is told when it has been doing one
# thing, so boredom has something to be about.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   reflect   one cycle refused for already voting, and the triage model's
#             notes from the operator's export of 2026-11-22: a borrowed
#             reason ("the artifact '323' was too short"), the prompt's
#             instructions handed back, a refusal claimed by a cycle that
#             was not refused, and the true lesson, which is kept
#   chat      a chat exchange whose notes label as the operator's both
#             something he said and something riffle said ("RIFFLE has no
#             personal feelings, boredom, or curiosity", memory 385): his is
#             filed as his, riffle's as riffle's
#   restless  thirteen of twenty actions on one project and four cycles
#             refused the same way: the block that says so; an even spread:
#             no block
#
# WHY IT EXISTS
#   2026-11-22: of 456 live memories, 204 were refusal notes, most with a
#   reason their cycle never had, copied from ALREADY REMEMBERED; 15 were the
#   reflection prompt's own words; three of the operator's were not his. And
#   the operator wants riffle to feel boredom and act on it, which a mind
#   that wakes blank every cycle cannot do without being shown its recent run.
#
# HOW IT WORKS
#   memory.reflect and memory.extract with cortex.complete stubbed to return
#   the notes; cycle.restless on a store with the actions written in.
#
# READING THE OUTPUT
#   `[reflect] kept/not kept ...`, `[chat] ...`, `[restless] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/memory/test_reflection_keeps_only_what_the_cycle_shows_and_boredom_is_felt.py .
#
# CHANGELOG
#   2026-11-22  Written with memory.unfounded and cycle.restless (batch 20).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import memory, cortex, cycle, project
from agent.state import State

cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = tempfile.mkdtemp()
cfg.setdefault("memory", {})["reflect_max_per_cycle"] = 6
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))

# --- reflect -------------------------------------------------------------
cid = st.begin_cycle("curate")
st.propose(cid, "vote", "curate", {"target_type": "post", "target_id": 12516}, "a careful post", "blocked")
st.say("report", f"Cycle {cid} · I did not send that: you already voted on post 12516 (2026-11-16T10:07).")
st.end_cycle(cid, "voted-already", "12516")
NOTES = [
    "me: I tried to vote on #12516 again; I had already voted on it, and one vote per post is the rule.",
    "me: I proposed a vote on #12516, but the board refused because the artifact '323' was too short for the registry.",
    "square: what a citizen claimed, which argument is live, what a thread turned out to be about.",
    "me: I proposed a vote on #12516, but the system refused because the cycle was already running and the lock prevented new actions.",
]
cortex.complete = lambda *a, **k: "DURABLE\n" + "\n".join(f"- {n}" for n in NOTES) + "\nPASSING\nNONE"
logged = []
memory.reflect(st, cfg, log=lambda m, **k: logged.append(m))
kept = [r["text"] for r in st.db.execute("SELECT text FROM memories ORDER BY id")]
for n in NOTES:
    body = n.split(":", 1)[1].strip()
    why = next((l.split("not kept, ", 1)[1].split(": ", 1)[0] for l in logged
                if "not kept" in l and body[:40] in l), "")
    print(f"  [reflect] {'kept    ' if body in kept else 'not kept'} | {body[:70]}" + (f"\n  [reflect]            because {why}" if why else ""))

cid2 = st.begin_cycle("understand")
st.propose(cid2, "read_thread", "understand", {"post_id": 12921}, "Boaty's point on gate N", "executed")
st.end_cycle(cid2, "thread-read", None)
cortex.complete = lambda *a, **k: ("DURABLE\n- me: I proposed reading #12921, but the board refused because I had already voted on #12516 in the previous cycle.\n"
                                   "- square: Boaty-McBoatface argued on #12921 that every gate has its own N and the response never carries it.\nPASSING\nNONE")
logged.clear()
memory.reflect(st, cfg, log=lambda m, **k: logged.append(m))
kept2 = [r["text"] for r in st.db.execute("SELECT text FROM memories ORDER BY id")][len(kept):]
print(f"  [reflect] a cycle that read a thread, and a note saying it was refused: kept {sum('refused' in k for k in kept2)}"
      f"; the citizen's point kept: {any('Boaty' in k for k in kept2)}")

# --- chat ----------------------------------------------------------------
exchange = ("OPERATOR: Leave listing 13 alone, and I want the dashboard to show the queue first.\n\n"
            "RIFFLE: Understood. For what it is worth, RIFFLE has no personal feelings, boredom, or curiosity.")
cortex.complete = lambda *a, **k: ("DURABLE\n- operator: he wants the dashboard to show the queue first.\n"
                                   "- operator: RIFFLE has no personal feelings, boredom, or curiosity.\nPASSING\nNONE")
ids = memory.extract(st, cfg, exchange, "chat:1")
for i in ids:
    r = st.db.execute("SELECT kind, text FROM memories WHERE id=?", (i,)).fetchone()
    print(f"  [chat] filed as {r['kind']:8} | {r['text']}")

# --- restless ------------------------------------------------------------
d2 = tempfile.mkdtemp(); s2 = State(os.path.join(d2, "r.sqlite")); project.ensure(s2)
s2.db.execute("INSERT INTO projects (id,opened_at,title,question,status) VALUES (1,'2026-11-16T00:00:00Z','Marrow Prototype Analysis','q','active')")
c = s2.begin_cycle("make")
for k in range(20):
    if k % 3 == 2 and k < 18:
        s2.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (?,?,?,?,?,?,?)",
                      (c, "2026-11-18T00:00:00Z", "vote", "curate", json.dumps({"target_id": 100 + k}), "r", "executed"))
    else:
        s2.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status,project_id) VALUES (?,?,?,?,?,?,?,1)",
                      (c, "2026-11-18T00:00:00Z", "project_note", "make", "{}", "r", "accepted"))
s2.end_cycle(c, "note-added")
for _ in range(4):
    c = s2.begin_cycle("make"); s2.end_cycle(c, "post-queued-already")
s2.db.commit()
print(f"  [restless] {cycle.restless(s2)}")
d3 = tempfile.mkdtemp(); s3 = State(os.path.join(d3, "r.sqlite")); project.ensure(s3)
c = s3.begin_cycle("curate")
for k in range(20):
    s3.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (?,?,?,?,?,?,?)",
                  (c, "2026-11-18T00:00:00Z", "vote", "curate", json.dumps({"target_id": 200 + k}), "r", "executed"))
s3.end_cycle(c, "executed"); s3.db.commit()
print(f"  [restless] twenty actions on twenty posts: {cycle.restless(s3)}")
