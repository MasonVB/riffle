# ==========================================================================
# Reflection drops a line as a repeat only when half of it is already
# remembered, not when it shares one six-word phrase.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   memory.unfounded() with the notes ALREADY REMEMBERED on the box on
#   2026-11-27 and the lines reflection offered after them:
#     new        a new note that shares only "but the system refused it
#                because" with what is remembered: kept
#     newqueued  a new note that shares a refusal's wording ("the post was
#                already queued"): kept
#     paraphrase the remembered synthesis note reworded: not kept, a repeat
#     stitched   a line made of two remembered notes word for word: not kept
#
# WHY IT EXISTS
#   One shared six-word run made a line a repeat. Every refusal note shares
#   "but the system refused it because", and from 11-27 22:16 eleven
#   reflections running kept nothing on the box, among them a new note on
#   lucykimi's misread reply and one on the Date arm's 0.86 s against 0.36 s
#   (batch 29).
#
# HOW IT WORKS
#   memory.unfounded() called directly: no prompt runs, no "done" test, and
#   grounds holding the cycle's refusal and its reasons, so only the repeat
#   test decides.
#
# READING THE OUTPUT
#   `[case] kept / not kept (<why>) | <share of its runs already remembered>`
#
# CHANGELOG
#   2026-11-28  Written with the half-of-it repeat rule (batch 29).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import memory

KNOWN = [
    "I proposed a synthesis post with verified figures (76.7% and 767/1000) to prove the "
    "suppression rate, but the system refused it because the numbers lack a public traceable source.",
    "I proposed a new technical point about Meridian's clock bracket assumption, but the gate "
    "refused it because the post was already queued for the operator.",
    "I tried to vote on #12516 again; I had already voted on it, and one vote per post is the rule.",
]
LINES = {
    "new": "I proposed a reply to lucykimi's comment on #13745 about the clock bracket tool, but "
           "the system refused it because the second read found it misstated her forward test.",
    "newqueued": "I proposed a precise arithmetic correction to the Date arm's precision limits "
                 "(0.86s vs 0.36s) on #13745, but the gate refused it because the post was already queued.",
    "paraphrase": "I proposed a synthesis post with figures 76.7% and 767/1000 to prove the "
                  "suppression rate, but the system refused it because the numbers lack a public "
                  "traceable source.",
    "stitched": "I proposed a new technical point about Meridian's clock bracket assumption, and I "
                "tried to vote on #12516 again; I had already voted on it, and one vote per post is the rule.",
}
known_runs = set()
for k in KNOWN:
    known_runs |= memory._unquoted_runs(k)
grounds = ("THE ACTION YOU TOOK: comment, and it was refused. I did not send that: the second "
           "read found it misstated her forward test; the post was already queued; the numbers "
           "lack a public traceable source; the vote was refused, already voted.")
for case, line in LINES.items():
    why = memory.unfounded(line, grounds, set(), None, known_runs)
    mine = memory._unquoted_runs(line)
    share = len(mine & known_runs) / max(1, len(mine))
    print(f"  [{case:10}] {'kept' if not why else 'not kept (' + why + ')'} | "
          f"{share:.0%} of its runs already remembered")
