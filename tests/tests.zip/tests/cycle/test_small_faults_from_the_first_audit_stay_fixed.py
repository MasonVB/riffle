# ==========================================================================
# Seven small faults from the 2026-11-10 audit, each shown fixed.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     stuck-late    (F21) a post proposed 40 hours ago and sent 2 hours ago:
#                   the stuck failsafe does not ask (it measured the proposal)
#     stuck-never   (F21) nothing ever sent, 12 cycles in 20 hours, the first
#                   30 hours ago: the failsafe asks (it could never fire)
#     deepen-gone   (F28) the operator deleted `deepen`; a cycle during the
#                   cooldown does not draw it back
#     weights       (F28) NaN, a negative, infinity and 0.3 as a weight from
#                   the goals page
#     dash          (F30) /api/decide with a non-number id; discarding an
#                   `accepted` local action; approving a `remember` that asks
#                   to be pinned; a goal's restrictions changed from settings
#     fields        (F32) the front page and the inbox rows riffle sees use the
#                   registry's names (body_length), never body_full_chars
#     alias         (F33) a page whose text riffle had already shelved under
#                   another URL; a build whose output matches a document
#                   riffle wrote itself
#     short         (F34) a short porch line repeated word for word, the same
#                   words reordered, and a different short line
#
# WHY IT EXISTS
#   Audit 2026-11-10, Low findings F21, F28, F30, F32, F33 and F34; each is
#   described at its fix in the code.
#
# HOW IT WORKS
#   The real functions, on a fresh store; the cycle cases run cycle.main()
#   against a stub registry and composer.
#
# READING THE OUTPUT
#   `[case] ...`, one or more lines each.
#
# RUNNING IT ON ITS OWN
#   python3 tests/cycle/test_small_faults_from_the_first_audit_stay_fixed.py . weights
#
# CHANGELOG
#   2026-11-17  Written for audit F21, F28, F30, F32, F33, F34 (batch 8).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, io, copy, json, tempfile, datetime, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library, goals, dash, policy, inbox, reference
from agent.state import State, utcnow

d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
root = os.path.join(d, "library"); cfg.setdefault("library", {})["root"] = root
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
ago = lambda h: (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(hours=h)).strftime("%Y-%m-%dT%H:%M:%SZ")


PROMPTS = []


def run_cycle(pick=None, front=None):
    me = json.load(open(os.environ["RIFFLE_ME_JSON"]))

    class Stub:
        def __init__(self, *a, **k): pass

        def front(self, *a, **k):
            return {"posts": copy.deepcopy(front or [])}

        def __getattr__(self, n):
            return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
    cycle.Reader = cycle.Writer = Stub
    cycle.do_witness = lambda *a, **k: None
    cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
    drives.pick_drive = pick or (lambda *a, **k: "understand")
    cortex.complete = lambda llm, system, user, schema=None, **k: (PROMPTS.append(user) if "Choose ONE action" in user else None) or json.dumps(
        {"action": "noop", "payload": {"why": "nothing"}, "rationale": "nothing to do"} if "Choose ONE action" in user
        else {"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
        else {"promote": [], "write": [], "drop": [], "note": ""})
    sys.argv = ["cycle", "--config", cp, "--force"]
    try:
        cycle.main()
    except SystemExit:
        pass


if mode.startswith("stuck"):
    for i in range(12):
        t = 30 - i * (20 / 11) if mode == "stuck-never" else 20 - i * 1.5
        st.db.execute("INSERT INTO cycles (started_at,ended_at,drive,outcome) VALUES (?,?,'understand','noop')",
                      (ago(t), ago(t - 0.1)))
    if mode == "stuck-late":
        st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status,executed_at)"
                      " VALUES (1,?,'post','contribute','{}','r','executed',?)", (ago(40), ago(2)))
    st.db.commit()
    run_cycle()
    q = st.db.execute("SELECT question FROM questions WHERE why LIKE '%stuck%'").fetchone()
    print(f"  [{mode:11}] the failsafe asked: {bool(q)}" + (f" | {q['question'][:70]!r}" if q else ""))

elif mode == "deepen-gone":
    cycle._seed_drive_once(st, "deepen", 0.25, "seeded as the cycle does")
    goals.remove(st, "deepen", "you", "not wanted")
    seen = {}
    _until = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=5)
    project.in_cooldown = lambda s: (True, _until, 5)
    project.ready = lambda s, c: (False, "not ready")

    def pick(c, available, rng=None, weights_override=None):
        seen["available"] = "deepen" in available
        seen["weight"] = (weights_override or {}).get("deepen")
        return "understand"
    run_cycle(pick)
    print(f"  [deepen-gone] during the cooldown: deepen offered {seen.get('available')}, weight {seen.get('weight')}")

elif mode == "weights":
    goals.add(st, cfg, "probe", 0.1, "a goal to set", "you", "testing")
    for w in ("nan", -0.5, "inf", 0.3):
        try:
            goals.set_weight(st, cfg, "probe", w, "you", "")
            r = f"stored {st.db.execute('SELECT weight FROM drives WHERE name=?', ('probe',)).fetchone()['weight']}"
        except goals.Rejected as e:
            r = f"refused: {e}"
        print(f"  [weights] {str(w):5} -> {r}")

elif mode == "dash":
    out = {}
    h = dash.Handler.__new__(dash.Handler)
    h.state, h.cfg = st, cfg
    h._host_refused = lambda: False
    h._json = lambda obj, code=200: out.update(obj=obj, code=code)
    h._update_card = lambda *a, **k: None
    h._local_time = lambda: "now"

    def post(path, body):
        raw = json.dumps(body).encode()
        h.path, h.command = path, "POST"
        h.headers = {"Content-Type": "application/json", "Content-Length": str(len(raw))}
        h.rfile = io.BytesIO(raw)
        out.clear()
        try:
            h.do_POST()
        except Exception as e:
            out.update(obj=f"raised {type(e).__name__}: {e}", code=None)
        return out.get("code"), out.get("obj")
    print(f"  [dash   ] /api/decide with id 'abc': {post('/api/decide', {'id': 'abc', 'verdict': 'approve'})}")
    aid = st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
                        " VALUES (1,?,'build','make','{}','r','accepted')", (utcnow(),)).lastrowid
    st.db.commit()
    c, o = post("/api/dismiss", {"id": aid})
    print(f"  [dash   ] discarding an accepted build: {str(o)[:110]} | its status: {st.action(aid)['status']!r}")
    rid = st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
                        " VALUES (1,?,'remember','understand',?,'r','queued')",
                        (utcnow(), json.dumps({"text": "Coppice answers within the hour.", "pinned": True}))).lastrowid
    st.db.commit()
    print(f"  [dash   ] approving a remember that asks for a pin: {h.decide(rid, 'approve')}")
    m = st.db.execute("SELECT pinned FROM memories WHERE text LIKE 'Coppice answers%'").fetchone()
    print(f"  [dash   ] stored pinned: {bool(m and m['pinned'])}")
    goals.add(st, cfg, "probe", 0.1, "a goal to restrict", "you", "testing")
    policy.set_restrictions(st, "probe", ["read_thread"], [], "you")
    ch = st.db.execute("SELECT field, new, actor FROM drive_changes WHERE name='probe' AND field IN ('selects','forbids')").fetchall()
    print(f"  [dash   ] a goal's restrictions changed; its history records: {[tuple(r) for r in ch]}")

elif mode == "fields":
    front = [{"id": 5, "title": "A long one", "author": "coppice", "votes": 2, "comments": 1,
              "body": "word " * 200, "body_length": 1000, "body_truncated": True}]
    run_cycle(front=front)
    u = PROMPTS[-1] if PROMPTS else ""
    fp = u[u.find("FRONT PAGE"):][:900]
    print(f"  [fields ] the front page row says body_length: {'body_length' in fp}; body_full_chars: "
          f"{'body_full_chars' in fp}; the registry's own length (1000) is the one shown: {chr(34) + 'body_length' + chr(34) + ': 1000' in fp}")
    rows = inbox.for_prompt([{"comment_id": 9, "post_id": 5, "author": "coppice", "body": "x " * 400}], body_chars=100)
    print(f"  [fields ] an inbox row's keys: {sorted(rows[0])}")

elif mode == "alias":
    TEXT = "Please accept cookies to continue reading this page about write-ahead logging and its guarantees."
    library.put(st, "consent wall", TEXT, kind="page", source="https://www.sqlite.org/wal.html", root=root)
    lid, _ = library.put(st, "consent wall again", TEXT, kind="page", source="https://www.sqlite.org/pragma.html", root=root)
    pages = reference._pages(st)
    print(f"  [alias  ] same text from a second URL: one document #{lid}; the second URL counts as a page read: "
          f"{reference._norm_url('https://www.sqlite.org/pragma.html') in pages}")
    OUT = "drift ok: 0.0123 over 400 runs\n"
    nid, _ = library.put(st, "my note of the output", OUT, kind="note", root=root)
    bid, _ = library.put(st, "output of replicate.py", OUT, kind="data", source="build:41:stdout", root=root)
    print(f"  [alias  ] a build's output matching a note riffle wrote: same document {nid == bid}; "
          f"counts as a build's: {library.from_build(st, bid)}")

elif mode == "short":
    def said(body):
        st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
                      " VALUES (1,?,'porch','greet',?,'r','executed')", (utcnow(), json.dumps({"body": body})))
        st.db.commit()
    said("Morning, square. Reading the docket today.")
    for b in ("Morning, square. Reading the docket today.", "Reading the docket today. Morning, square!",
              "Evening, square. Building tonight."):
        r, ov = cycle.near_duplicate(st, "porch", b)
        print(f"  [short  ] {b!r:46} -> {'repeat of #' + str(r['id']) if r else 'new'}")
