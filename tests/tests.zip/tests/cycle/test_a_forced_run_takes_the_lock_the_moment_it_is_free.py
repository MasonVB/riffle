# ==========================================================================
# A forced run (the dashboard's button, request_cycle, an approval) waiting
# for the cycle lock gets it the moment it is released, ahead of a timer
# wake that asks right after; and gives up when the wait runs out.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     queue   a stand-in for the timer holds the cycle lock for 1.5 s,
#             releases it, and 20 ms later asks for it again, four times, as
#             back-to-back timer wakes do. A forced cycle.main is waiting
#             meanwhile: how long it waited, whether it ran a cycle, and how
#             many of the stand-in's asks after the first release found the
#             lock taken
#     giveup  the lock held throughout, the forced run's wait set to 2 s:
#             what it logged, and whether a cycle ran
#
# WHY IT EXISTS
#   2026-11-18 on the box: a forced run waited from 21:01 to 21:41 UTC while
#   three timer cycles ran, then logged "a cycle has held the lock for 40
#   minutes" and gave up. It tried the lock every ten seconds; the timer's
#   next wake starts the moment a cycle ends and takes the lock within a
#   second or two, so the poller kept finding it taken.
#
# HOW IT WORKS
#   cycle.main against a stub registry and composer; the stand-in timer is a
#   separate process flocking the same cycle.lock. In giveup,
#   cycle._FORCED_WAIT is set to 2 (the tree before batch 12 has no such
#   setting and waits 40 minutes; the runner's timeout then cuts it off and
#   it prints nothing).
#
# READING THE OUTPUT
#   `[case] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/cycle/test_a_forced_run_takes_the_lock_the_moment_it_is_free.py . queue
#
# CHANGELOG
#   2026-11-19  Written for the forced-run wait seen in the box's figures
#               (batch 12).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, copy, json, subprocess, tempfile, time, sqlite3, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project
from agent.state import State

d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg.setdefault("library", {})["root"] = os.path.join(d, "library")
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))


class Stub:
    def __init__(self, *a, **k): pass

    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {})


cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "understand"
cortex.complete = lambda *a, **k: json.dumps(
    {"action": "noop", "payload": {"why": "nothing"}, "rationale": "nothing to do"})
lock = os.path.join(d, "cycle.lock")
open(lock, "a").close()
ready = os.path.join(d, "ready")
# The stand-in timer. Prints, for each ask after a release, got/refused.
TIMER = f"""
import fcntl, os, sys, time
f = open({lock!r}, "a+")
fcntl.flock(f, fcntl.LOCK_EX)
open({ready!r}, "w").close()
seen = []
for i in range({4 if mode == "queue" else 1}):
    time.sleep({1.5 if mode == "queue" else 8})
    if seen and seen[-1] == "refused":
        break
    fcntl.flock(f, fcntl.LOCK_UN)
    time.sleep(0.02)
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        seen.append("got")
    except OSError:
        seen.append("refused")
print(" ".join(seen))
"""
timer = subprocess.Popen([sys.executable, "-c", TIMER], stdout=subprocess.PIPE, text=True)
while not os.path.exists(ready):
    time.sleep(0.01)
if mode == "giveup":
    cycle._FORCED_WAIT = 2
sys.argv = ["cycle", "--config", cp, "--force"]
t0 = time.monotonic()
try:
    cycle.main()
except SystemExit:
    pass
waited = time.monotonic() - t0
if cycle._CYCLE_LOCK:
    cycle._CYCLE_LOCK.close()
    cycle._CYCLE_LOCK = None
out = timer.communicate(timeout=60)[0].split()
db = sqlite3.connect(os.path.join(d, "state.sqlite"))
n = db.execute("SELECT COUNT(*) FROM cycles").fetchone()[0]
said = [r[0] for r in db.execute("SELECT text FROM journal WHERE text LIKE '%lock%' ORDER BY id")]
if mode == "queue":
    print(f"  [queue ] the forced run ran within 8 s of starting (a 10 s poll could not): {waited < 8}; cycles run {n}")
    print(f"  [queue ] the stand-in timer's asks after its first release: {out[:2]}")
else:
    print(f"  [giveup] cycles run {n}; gave up within 5 s: {waited < 5}")
    print(f"  [giveup] it logged: {said[-1][:110] if said else None!r}")
