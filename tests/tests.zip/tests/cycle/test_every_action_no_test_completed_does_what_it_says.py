# ==========================================================================
# Every action that no recorded test carried through to success (the
# coverage sweep of 2026-11-27) does what its outcome says it did.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one action; each runs ONE real cycle.main() and prints
#   the outcome with what is now in the state, so an outcome that claims
#   success without the effect shows:
#     libread      library_read of a shelved document: library-read, and the
#                  note for the next cycle holds its text and whole sha256
#     fetched      fetch of the docket: fetched, shelved whole in the library
#                  with the registry as its source, and the note points at it
#     batchread    read_more on a thread with 25 unread replies: batch-read,
#                  the cursor moved by one batch (threads.batch_comments, 20)
#     exhausted    read_more on a thread already read to the end:
#                  thread-exhausted, the cursor unchanged
#     requested    request_cycle: cycle-requested, today's count up by one and
#                  the reason kept for the dashboard
#     opened       open_project with none running: project-opened, the
#                  project active
#     queuedproj   open_project while one runs: project-queued, the new one
#                  queued and the running one still active
#     noteadded    project_note: note-added, the note on the open project
#     remembered   remember with pinned: true: remembered, the memory saved
#                  UNPINNED (pinning is the operator's)
#     adjusted     adjust_drive by 0.05 with adjust_drive auto: adjusted, the
#                  weight moved
#     queuedgoal   adjust_drive with adjust_drive set to queue: queued, the
#                  weight unchanged
#     addgoal      add_goal: queued however autonomy is set, no goal added
#     queuedclose  close_project (queue): queued with the open project's id
#                  in its payload, the project still active
#
# WHY IT EXISTS
#   The coverage sweep of 2026-11-27 (AUDIT-RESPONSE §32) listed the success
#   outcomes no test reached; the operator asked for them to be tested
#   (batch 27). An outcome no test reaches can stop doing what it says, and
#   the cycle record would still say it was done.
#
# HOW IT WORKS
#   cycle.main() with Reader and Writer stubbed (every send recorded), the
#   composer replaced by the case's proposal, and the state each action reads.
#
# READING THE OUTPUT
#   `[case] outcome '<outcome>' | sent: yes/no | <what the state now shows>`
#
# RUNNING IT ON ITS OWN
#   With the variables tests/run_all.sh sets; simplest is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-27  Written from the coverage sweep (batch 27).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, sqlite3, time
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library, desk
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
SENT = []
DOCKET = [{"id": i, "title": f"listing {i}", "lifecycle": "open"} for i in range(1, 41)]
class Stub:
    def __init__(self, *a, **k): pass
    def read_only(self, what, **k):
        return copy.deepcopy(DOCKET) if what == "docket" else {}
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        if n.startswith(("create_", "vote", "porch", "tag", "submit", "attest", "seal")):
            return lambda *a, **k: (SENT.append(n) or {"ok": True})
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
DRIVE = {"noteadded": "deepen", "opened": "deepen", "queuedproj": "deepen",
         "queuedclose": "deepen"}.get(mode, "understand")
drives.pick_drive = lambda *a, **k: DRIVE
REPLY = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                          else {"promote": [], "write": [], "drop": [], "note": ""})
    return json.dumps(dict(REPLY, rationale="a reason long enough for the gate"))
cortex.complete = complete

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
for k in ("library_read", "fetch", "read_more", "request_cycle", "open_project",
          "project_note", "remember", "adjust_drive"):
    cfg["autonomy"][k] = "auto"
if mode == "queuedgoal":
    cfg["autonomy"]["adjust_drive"] = "queue"
if mode == "addgoal":
    cfg["autonomy"]["add_goal"] = "auto"      # queued however it is set
cfg["autonomy"]["close_project"] = "queue"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root); desk.ensure(st)
st.db.executescript(project.READS_SCHEMA)
if mode != "opened":
    st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES "
                  "('2026-10-23T00:00:00Z','The tripwire rate','What does the tripwire catch?','active')")
PID = 1
COMMENTS = [{"id": 900 + i, "author": f"citizen{i}", "votes": 30 - i, "body": f"reply number {i}"}
            for i in range(25)]

if mode == "libread":
    DID, _ = library.put(st, "a page I kept", "The text of the page I kept, whole.\n",
                         kind="data", source="1f916:/api/docket", root=root)
    REPLY.update(action="library_read", payload={"id": DID})
elif mode == "fetched":
    REPLY.update(action="fetch", payload={"what": "docket"})
elif mode in ("batchread", "exhausted"):
    st.db.execute("INSERT INTO thread_reads (project_id, cycle_id, ts, post_id, title, author,"
                  " comments_total, comments_shown, body, replies, digest, comments_json, cursor)"
                  " VALUES (?, 0, '2026-11-27T00:00:00Z', 123, 'a thread', 'silt', 25, 0, 'b', '', 'd', ?, ?)",
                  (PID, json.dumps(COMMENTS), 25 if mode == "exhausted" else 0))
    REPLY.update(action="read_more", payload={"post_id": 123})
elif mode == "requested":
    REPLY.update(action="request_cycle", payload={"reason": "silt answered and I want to read it now"})
elif mode in ("opened", "queuedproj"):
    REPLY.update(action="open_project", payload={"title": "Why gate order matters",
                 "question": "Does the order of the gates change which posts get through?"})
elif mode == "noteadded":
    REPLY.update(action="project_note", payload={"kind": "objection",
                 "text": "silt says the fix is in #33, not the gate; that changes the question."})
elif mode == "remembered":
    REPLY.update(action="remember", payload={"text": "silt reads diffs before citing them; do the same.",
                                             "pinned": True})
elif mode in ("adjusted", "queuedgoal"):
    REPLY.update(action="adjust_drive", payload={"name": "understand", "weight": 0.35,
                 "reason": "I am citing threads I have not finished reading."})
elif mode == "addgoal":
    REPLY.update(action="add_goal", payload={"name": "verify", "weight": 0.05,
                 "description": "check a claim before repeating it",
                 "reason": "Five of my replies misstated what they answered."})
elif mode == "queuedclose":
    REPLY.update(action="close_project", payload={"reason": "The question is answered by silt's #33 diff."})
st.db.commit()
w0 = dict(cfg["drives"])          # the seed; the drives table is filled at the cycle's start
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
db = sqlite3.connect(os.path.join(d, "state.sqlite")); db.row_factory = sqlite3.Row
oc = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()[0]
def note(k):
    r = db.execute("SELECT value FROM notes WHERE key=?", (k,)).fetchone()
    return r[0] if r else None
shows = ""
if mode == "libread":
    n = note("last_library_read") or ""
    row = db.execute("SELECT sha256 FROM library WHERE id=?", (DID,)).fetchone()
    shows = (f"note holds the text: {'The text of the page I kept' in n} | "
             f"and its whole sha256: {row['sha256'] in n}")
elif mode == "fetched":
    r = db.execute("SELECT id, source, bytes FROM library WHERE source='1f916:/api/docket'").fetchone()
    lf = json.loads(note("last_fetch") or "{}")
    whole = r is not None and json.loads(library.read(st, r["id"], root=root)[1]) == DOCKET
    shows = (f"shelved: {'#' + str(r['id']) if r else 'no'} | all {len(DOCKET)} rows kept: {whole} | "
             f"note is the docket: {lf.get('what') == 'docket'}")
elif mode in ("batchread", "exhausted"):
    r = db.execute("SELECT cursor, comments_shown FROM thread_reads WHERE post_id=123").fetchone()
    shows = f"cursor now {r['cursor']} of {len(COMMENTS)}, shown {r['comments_shown']}"
elif mode == "requested":
    shows = (f"today's extra cycles: {note('extra_cycles_' + time.strftime('%Y-%m-%d', time.gmtime()))} | "
             f"reason kept: {(note('cycle_requested_why') or '')[:40]!r} | "
             f"requested at recorded: {bool(note('cycle_requested_at'))}")
elif mode in ("opened", "queuedproj"):
    shows = " | ".join(f"#{r['id']} {r['title'][:24]!r} {r['status']}"
                       for r in db.execute("SELECT id, title, status FROM projects ORDER BY id"))
elif mode == "noteadded":
    r = db.execute("SELECT project_id, kind, text FROM project_notes ORDER BY id DESC LIMIT 1").fetchone()
    shows = (f"note on project #{r['project_id']}: {r['kind']} {r['text'][:40]!r}" if r else "no note")
elif mode == "remembered":
    r = db.execute("SELECT text, pinned FROM memories ORDER BY id DESC LIMIT 1").fetchone()
    shows = f"memory {r['text'][:30]!r} pinned: {bool(r['pinned'])}" if r else "no memory"
elif mode in ("adjusted", "queuedgoal", "addgoal"):
    w1 = {r["name"]: r["weight"] for r in db.execute("SELECT name, weight FROM drives")}
    shows = (f"understand {w0.get('understand')} -> {w1.get('understand')} | "
             f"goal 'verify' exists: {'verify' in w1}")
if mode in ("queuedgoal", "addgoal", "queuedclose"):
    r = db.execute("SELECT kind, status, payload FROM actions ORDER BY id DESC LIMIT 1").fetchone()
    shows += (" | " if shows else "") + f"action {r['kind']} {r['status']}"
    if mode == "queuedclose":
        shows += (f" for project #{json.loads(r['payload']).get('project_id')} | project #1 "
                  + db.execute("SELECT status FROM projects WHERE id=1").fetchone()[0])
print(f"  [{mode:11}] outcome {oc!r:20} | sent: {'yes' if SENT else 'no'} | {shows}")
