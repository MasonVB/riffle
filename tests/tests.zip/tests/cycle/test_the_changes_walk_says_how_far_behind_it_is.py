# ==========================================================================
# The changes walk records how far behind its cursor is, and warns when it is
# more than two hours behind.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   cycle.walk_changes() against a stub registry whose page hands back a
#   cursor that is current, or five hours old, and has more behind it:
#     current   the cursor a minute old: lag noted, no warning
#     behind    the cursor five hours old with more to read: lag noted, and a
#               warning naming changes.max_rows_per_cycle
#
# WHY IT EXISTS
#   Brief II listed "the changes walk fetches 400 rows though ~1,500 are
#   shown" as a limit. The walk resumes from its cursor, so 400 a wake is a
#   pace, not a cap; what would matter is falling behind for good on a busy
#   board, and nothing said whether it was (2026-11-27, batch 26).
#
# HOW IT WORKS
#   A reader whose changes() returns one page and the cursor; the state's
#   notes and the log lines are read back.
#
# READING THE OUTPUT
#   `[case] lag noted: <hours> h | warned: yes/no`
#
# CHANGELOG
#   2026-11-27  Written with the lag note and warning (batch 26).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile, time, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle
from agent.state import State
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
now_ms = int(time.time() * 1000)
cursor = now_ms - (60 * 1000 if mode == "current" else 5 * 3600 * 1000)
class Reader:
    def changes(self, since, etag, nulls_since):
        return 200, {"posts": [{"id": 1}], "comments": [], "nulls": [], "next_since": cursor,
                     "has_more": False}, "e1"
logged = []
cycle.walk_changes(st, Reader(), cfg, lambda m, **k: logged.append((k.get("level"), m)))
lag = st.note("changes_lag_ms")
warned = any(lv == "warn" and "behind now" in m for lv, m in logged)
print(f"  [{mode:8}] lag noted: {int(lag) / 3.6e6:.0f} h | warned: {'yes' if warned else 'no'}"
      + (" | names the setting: " + str(any('max_rows_per_cycle' in m for _, m in logged)) if warned else ""))
