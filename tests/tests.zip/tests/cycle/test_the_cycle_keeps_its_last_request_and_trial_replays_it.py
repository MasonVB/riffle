# ==========================================================================
# A cycle keeps the request it sent the composer, and agent.trial replays
# it against another server with thinking switched on or off.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case:
#     kept       one real cycle.main(), the composer answered at the HTTP
#                layer: last-cycle-request.json is written, owner-only, with
#                the system prompt, the JSON form and the cycle's time
#     notkept    a cycle that ends before the composer is asked (the queue is
#                full) leaves the earlier file as it was
#     replay     agent.trial against a stub server, efforts none,low,medium:
#                each request carries the saved messages and JSON form, the
#                thinking switch and effort, and the answer is judged; low
#                comes back with thinking apart, medium with it inline
#     nothink    the server brings back no thinking for an effort: the trial
#                says the JSON form took over
#     notjson    an answer that is not a proposal is said to be one it is not
#     nosaved    no saved request: it says to wait for a cycle
#     noform     --no-json-form: the request goes without the JSON form, and
#                the report says so
#
# WHY IT EXISTS
#   The operator decided to move the composer to Qwen3.8-27B with thinking
#   on. Whether riffle's JSON form lets the model think first on this
#   llama.cpp build, and how much thinking a real decision takes at about a
#   token a second, could only be found by sending a real cycle's request,
#   and none was kept (batch 30).
#
# HOW IT WORKS
#   kept/notkept: cycle.main() with Reader and Writer stubbed and
#   cortex._post_json answering, so cortex.complete() itself runs. replay and
#   the rest: a local http.server on a free port as the trial server.
#
# READING THE OUTPUT
#   `[case] ...` lines naming what was written or sent, then the trial's own
#   report with its times removed.
#
# CHANGELOG
#   2026-11-28  Written with cortex.LAST_CYCLE_REQUEST and agent.trial (batch 30).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, stat, threading, io, re, contextlib
import http.server
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library
from agent.state import State

d = tempfile.mkdtemp(); root = os.path.join(d, "library")
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["library"]["root"] = root
SAVED = os.path.join(d, "last-cycle-request.json")

if mode in ("kept", "notkept"):
    me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
    class Stub:
        def __init__(self, *a, **k): pass
        def __getattr__(self, n):
            if n == "me": return lambda *a, **k: copy.deepcopy(me)
            if n == "ack": return lambda *a, **k: {"mode": "legacy"}
            return lambda *a, **k: {}
    cycle.Reader = cycle.Writer = Stub
    cycle.do_witness = lambda *a, **k: None
    cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
    drives.pick_drive = lambda *a, **k: "understand"
    def _post_json(url, body, timeout=None):
        if body.get("response_format"):
            c = json.dumps({"action": "noop", "payload": {"why": "nothing worth doing"},
                            "rationale": "a reason long enough for the gate"})
        else:
            c = json.dumps({"continuity": "c", "promote": [], "write": [], "drop": [], "note": ""})
        return {"choices": [{"message": {"content": c}, "finish_reason": "stop"}], "usage": {}}
    cortex._post_json = _post_json
    open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
    st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
    st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
    if mode == "notkept":
        open(SAVED, "w").write('{"at": "earlier", "body": {"messages": []}}')
        for i in range(int(cfg.get("max_queued", 20))):
            st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
                          " VALUES (0,'2026-11-28T00:00:00Z','post','x',?,'r','queued')",
                          (json.dumps({"title": f"t{i}", "body": "b"}),))
    st.db.commit()
    cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    if mode == "notkept":
        print(f"  [{mode:8}] the earlier file is unchanged: {open(SAVED).read().startswith('{\"at\": \"earlier\"')}")
        sys.exit(0)
    j = json.load(open(SAVED))
    b = j["body"]
    print(f"  [{mode:8}] written, owner-only: {stat.S_IMODE(os.stat(SAVED).st_mode) == 0o600} | "
          f"time recorded: {bool(re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ', j['at']))} | "
          f"messages: {len(b['messages'])}, the first the system prompt: "
          f"{b['messages'][0]['role'] == 'system' and len(b['messages'][0]['content']) > 10000} | "
          f"JSON form: {b.get('response_format', {}).get('type')} | url: {j['url']}")
    sys.exit(0)

# --- the trial ---------------------------------------------------------------------
from agent import trial
SCHEMA = {"type": "object", "required": ["action"]}
saved = {"at": "2026-11-28T09:00:00Z", "url": "http://127.0.0.1:8080",
         "body": {"messages": [{"role": "system", "content": "S" * 500},
                               {"role": "user", "content": "Choose ONE action. " + "U" * 200}],
                  "max_tokens": 4000, "temperature": 0.7, "cache_prompt": True,
                  "response_format": {"type": "json_schema",
                                      "json_schema": {"name": "proposal", "strict": True,
                                                      "schema": SCHEMA}}}}
if mode != "nosaved":
    json.dump(saved, open(SAVED, "w"))
SEEN = []
ANSWER = json.dumps({"action": "comment", "rationale": "silt asked about #33 and I read the diff",
                     "payload": {"post_id": 12752, "body": "The diff of #33 moves the gate."}})
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        SEEN.append(body)
        eff = (body.get("chat_template_kwargs") or {}).get("reasoning_effort", "none")
        msg = {"content": ANSWER}
        if mode == "notjson":
            msg = {"content": "I think the best action is to comment."}
        elif mode == "replay" and eff == "low":
            msg = {"reasoning_content": "Silt said #33. I should check the diff before " * 5,
                   "content": ANSWER}
        elif mode == "replay" and eff == "medium":
            msg = {"content": "<think>" + "Weigh the thread first. " * 8 + "</think>\n" + ANSWER}
        out = {"choices": [{"message": msg, "finish_reason": "stop"}],
               "usage": {"prompt_tokens": 180, "completion_tokens": 60},
               "timings": {"prompt_n": 0 if len(SEEN) > 1 else 180, "cache_n": 180 if len(SEEN) > 1 else 0,
                           "prompt_per_second": 3.4, "predicted_n": 60, "predicted_per_second": 1.2}}
        data = json.dumps(out).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
srv = http.server.HTTPServer(("127.0.0.1", 0), H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
url = f"http://127.0.0.1:{srv.server_port}"
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
efforts = {"replay": "none,low,medium", "nothink": "low"}.get(mode, "none")
buf = io.StringIO()
code = 0
with contextlib.redirect_stdout(buf):
    try:
        trial.main(["--url", url, "--effort", efforts, "--config", cp]
                   + (["--no-json-form"] if mode == "noform" else []))
    except SystemExit as e:
        code = e.code
for l in buf.getvalue().splitlines():
    l = re.sub(r"took [\d,]+ s", "took <s> s", l.replace(url, "<trial server>"))
    print(f"  [{mode:8}] {l}")
if code:
    print(f"  [{mode:8}] stopped: {str(code).replace(d, '<data dir>')}")
for i, b in enumerate(SEEN):
    print(f"  [{mode:8}] request {i + 1}: messages as saved: {b['messages'] == saved['body']['messages']} | "
          f"JSON form sent: {b.get('response_format') == saved['body']['response_format']} | "
          f"thinking switch: {json.dumps(b.get('chat_template_kwargs'), sort_keys=True)} | max_tokens {b['max_tokens']}")
