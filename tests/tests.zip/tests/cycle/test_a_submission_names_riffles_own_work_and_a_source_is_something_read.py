# ==========================================================================
# A listing submission's artifact, when it names a post or comment on the
# square, must be one riffle sent; and a project source counts toward
# readiness only when it is something riffle read.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     theirs   a submission whose artifact is the registry URL of post 777,
#              which riffle did not send: refused (artifact-not-yours)
#     mine     the same with post 900, which riffle sent: passes this check
#     forms    which posts and comments the check sees in five artifacts
#     sources  a project's notes cite a thread it read, a thread it did not,
#              "library #12", a page it read, its operator, and a phrase:
#              which count, and what "library #12" becomes
#
# WHY IT EXISTS
#   Audit F22 (2026-11-10): any eight characters passed as an artifact, so
#   a submission could name another citizen's post as riffle's work, and
#   `sign` is offered once a submission exists. Audit F23: readiness counted
#   distinct source strings riffle typed, matched against nothing, and
#   "library #12" was rewritten to board thread 12.
#
# HOW IT WORKS
#   One real cycle.main() against a stub registry and composer for the
#   submissions; project.stats and project.normalise_source for the sources.
#
# READING THE OUTPUT
#   `[case] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/cycle/test_a_submission_names_riffles_own_work_and_a_source_is_something_read.py . theirs
#
# CHANGELOG
#   2026-11-18  Written for audit F22 and F23 (batch 10).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, copy, json, tempfile, sqlite3, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, library
from agent.state import State, utcnow

d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
root = os.path.join(d, "library"); cfg.setdefault("library", {})["root"] = root
cfg["autonomy"]["listing_submission"] = "queue"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st); library.ensure(st, root)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','Seals','Do they hold?','active')")
st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status,response)"
              " VALUES (1,?,'post','contribute','{}','r','executed',?)", (utcnow(), json.dumps({"post_id": 900})))
st.db.commit()

if mode == "forms":
    for a in ("https://1f916.ai/api/post/8395", "post #8395 with its source", "1f916:8395",
              "https://1f916.ai/p/12#comment-77", "https://github.com/someone/repo/tree/abc1234"):
        print(f"  [forms  ] {a!r:46} -> {cycle._square_refs(a, cfg)}")
    sys.exit(0)

if mode == "sources":
    project.record_read(st, 1, 0, 4321, "Seals last week", "coppice", 0, 0, "a thread", "", "d1")
    library.put(st, "WAL", "The WAL file is where the commit lands first.", kind="page",
                source="https://www.sqlite.org/wal.html", root=root)
    from agent import state as state_mod
    st.db.executescript(state_mod.ASK_SCHEMA)
    qid = st.db.execute("INSERT INTO questions (asked_at,question) VALUES (?, 'Which listing?')", (utcnow(),)).lastrowid
    st.db.execute("UPDATE questions SET answer='Listing 57', answered_at=? WHERE id=?", (utcnow(), qid))
    st.db.commit()
    for src in ("1f916:4321", "1f916:999", "library #12", "https://www.sqlite.org/wal.html",
                "my operator, in chat", "what everyone says"):
        st.db.execute("INSERT INTO project_notes (project_id,ts,kind,text,source) VALUES (1,?,'observation',?,?)",
                      (utcnow(), f"A note citing {src} for the record.", project.normalise_source(src)))
    st.db.commit()
    s = project.stats(st, 1)
    print(f"  [sources] 'library #12' is stored as {project.normalise_source('library #12')!r}")
    print(f"  [sources] six listed, {s['sources']} count; not counted: {s.get('unread_sources')}")
    sys.exit(0)

me = json.load(open(os.environ["RIFFLE_ME_JSON"]))


class Stub:
    def __init__(self, *a, **k): pass

    def listings(self):
        return {"listings": [{"id": 57, "lifecycle": "open", "title": "Replicate a drift figure"}]}

    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})


cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "earn"
post = 777 if mode == "theirs" else 900
cortex.complete = lambda llm, system, user, schema=None, **k: json.dumps(
    {"action": "listing_submission", "rationale": "submitting the finished work",
     "payload": {"listing_id": 57, "artifact": f"https://1f916.ai/api/post/{post}",
                 "note": "The source and its captured output are in the post."}}
    if "Choose ONE action" in user else
    {"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else
    {"promote": [], "write": [], "drop": [], "note": ""})
sys.argv = ["cycle", "--config", cp, "--force"]
try:
    cycle.main()
except SystemExit:
    pass
db = sqlite3.connect(os.path.join(d, "state.sqlite")); db.row_factory = sqlite3.Row
c = db.execute("SELECT outcome, notes FROM cycles ORDER BY id DESC LIMIT 1").fetchone()
said = db.execute("SELECT content FROM messages WHERE content LIKE '%did not send that%' ORDER BY id DESC LIMIT 1").fetchone()
print(f"  [{mode:7}] artifact post {post}: outcome {c['outcome']!r}")
if said:
    print(f"  [{mode:7}] told: {said['content'].split('did not send that: ', 1)[1][:160]!r}")
