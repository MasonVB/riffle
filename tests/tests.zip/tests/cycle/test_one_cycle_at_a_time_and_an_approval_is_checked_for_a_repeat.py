# ==========================================================================
# Only one cycle runs at a time; and approving a queued comment on the
# dashboard is refused when riffle has already said the same thing.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     lock     while this process holds the cycle lock, a timer wake of
#              cycle.main: whether it ran a cycle, called the composer, and
#              what it logged
#     approve  a comment sent, then a second queued with the same words,
#              approved on the dashboard: what decide answers, the second
#              comment's status, and what reached the square
#
# WHY IT EXISTS
#   Audit 2026-11-14, section 7.1: the cycle lock, and the dashboard's
#   duplicate re-check on approval, could each be switched off with every
#   test still passing.
#
# HOW IT WORKS
#   cycle.main against a stub registry and composer, with the lock taken
#   first by this process; dash.Handler.decide with dash.execute replaced.
#
# READING THE OUTPUT
#   `[case] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/cycle/test_one_cycle_at_a_time_and_an_approval_is_checked_for_a_repeat.py . lock
#
# CHANGELOG
#   2026-11-18  Written for the audit's section 7.1 (batch 11).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, copy, json, fcntl, tempfile, threading, sqlite3, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, dash
from agent.state import State, utcnow

d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg.setdefault("library", {})["root"] = os.path.join(d, "library")
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)

if mode == "lock":
    me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
    calls = []

    class Stub:
        def __init__(self, *a, **k): pass

        def __getattr__(self, n):
            return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {})
    cycle.Reader = cycle.Writer = Stub
    cycle.do_witness = lambda *a, **k: None
    drives.pick_drive = lambda *a, **k: "understand"
    cortex.complete = lambda *a, **k: calls.append(1) or json.dumps(
        {"action": "noop", "payload": {"why": "nothing"}, "rationale": "nothing to do"})
    held = open(os.path.join(d, "cycle.lock"), "a+")
    fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
    sys.argv = ["cycle", "--config", cp]
    try:
        cycle.main()
    except SystemExit:
        pass
    db = sqlite3.connect(os.path.join(d, "state.sqlite"))
    n = db.execute("SELECT COUNT(*) FROM cycles").fetchone()[0]
    said = [r[0] for r in db.execute("SELECT text FROM journal WHERE text LIKE '%lock%'")]
    print(f"  [lock   ] with the lock held elsewhere: cycles run {n}, composer calls {len(calls)}")
    print(f"  [lock   ] it logged: {said[-1][:90] if said else None!r}")
else:
    sent = []
    dash.execute = lambda writer, kind, p: sent.append(p["body"]) or {"comment_id": 7000 + len(sent)}

    class W:
        def __init__(self, *a, **k): pass
    dash.Writer = W
    BODY = ("The receipts settle in order only within one batch, and the registry's own help page "
            "says so plainly, which nobody in this thread has quoted yet.")
    first = st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
                          " VALUES (1,?,'comment','answer',?,'r','executed')",
                          (utcnow(), json.dumps({"post_id": 4, "body": BODY}))).lastrowid
    second = st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status)"
                           " VALUES (1,?,'comment','answer',?,'r','queued')",
                           (utcnow(), json.dumps({"post_id": 9, "body": BODY}))).lastrowid
    st.db.commit()
    dash.Handler.state, dash.Handler.cfg = st, cfg
    h = dash.Handler.__new__(dash.Handler)
    h._update_card = lambda *a, **k: None
    h._local_time = lambda: "now"
    h.run_cycle = lambda *a, **k: None
    r = h.decide(second, "approve")
    for t in threading.enumerate():
        if t is not threading.current_thread():
            t.join(10)
    print(f"  [approve] #{first} sent; approving #{second}, the same words: {r}")
    print(f"  [approve] #{second} is now {st.action(second)['status']!r}; reached the square since: {len(sent)}")
