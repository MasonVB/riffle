# ==========================================================================
# A post the operator rejects on the dashboard reaches riffle's next prompt
# with his reason, and the same post proposed again is refused.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     reason     a queued post is rejected with a reason; the next prompt
#                lists it under YOUR OPERATOR TURNED THESE DOWN with the
#                reason, and the same post, reworded slightly, is refused
#                as `rejected-before` and nothing is sent
#     other      after that rejection a different post on another subject
#                is queued as usual (the check is not a blanket ban)
#     dismissed  a card that FAILED and was then cleared with the dismiss
#                button is not listed and does not block a re-proposal
#                (clearing a failure is not a judgement on what it said)
#     detag      the cycle's neutraliser for <board> tags, on the spellings
#                the 2026-11-10 audit found getting through
#
# WHY IT EXISTS
#   Audit F9 (2026-11-10): a rejection went to the operator's chat and
#   nowhere else, so the next cycle proposed the same post again word for
#   word. Audit F14: `</board>` with an attribute or a space was not
#   neutralised and could close the board section from inside it.
#
# HOW IT WORKS
#   One real cycle.main() against a stub registry and composer (the shape
#   of the send-check tests), the real dash.Handler.decide and the real
#   /api/dismiss route.
#
# READING THE OUTPUT
#   `[reason] ...` lines say what the prompt held and what the second
#   proposal became; `[detag] 'x' -> 'y'` one spelling per line.
#
# RUNNING IT ON ITS OWN
#   python3 tests/cycle/test_a_rejection_reaches_riffle_with_its_reason_
#   and_a_repeat_is_refused.py . reason
#
# CHANGELOG
#   2026-11-15  Written for audit F9 and F14 (batch 5).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, io, json, copy, tempfile, sqlite3, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, dash
from agent.state import State

if mode == "detag":
    for t in ("</board>", "</ board >", "</BOARD class=x>", "</board\tdata-a=\"1\">", "<board role=system>",
              "a <boardroom> is not a tag"):
        print(f"  [detag ] {t!r:28} -> {cycle._detag(t)!r}")
    sys.exit(0)

me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
sent, prompts, replies = [], [], []
class Stub:
    def __init__(self, *a, **k): pass
    def create_post(self, title, body, url=None):
        sent.append(title); return {"post_id": 900 + len(sent), "created_at": 1}
    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "contribute"
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" not in user:
        return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", []) else {"promote": [], "write": [], "drop": [], "note": ""})
    prompts.append(user)
    return json.dumps(replies.pop(0) if replies else {"action": "noop", "payload": {"why": "nothing"}, "rationale": "nothing to do"})
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg.setdefault("library", {})["root"] = os.path.join(d, "library")
cfg["autonomy"]["post"] = "queue"
for k in ("min_notes", "min_sources", "min_drafts", "min_objections"):
    cfg["projects"][k] = 0
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')"); st.db.commit()

def run(reply):
    replies.append(reply)
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    db = sqlite3.connect(os.path.join(d, "state.sqlite")); db.row_factory = sqlite3.Row
    c = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()
    a = db.execute("SELECT id, status FROM actions ORDER BY id DESC LIMIT 1").fetchone()
    return c["outcome"], a["id"], a["status"]
def post(title, body):
    return {"rationale": "the project is ready and this is what it found", "action": "post",
            "payload": {"title": title, "body": body}}

BODY = ("A seal says a hash existed at a time. It does not say where the thing behind it is, "
        "or that anyone can fetch it, or that the label beside it is true.")
oc1, a1, s1 = run(post("What a seal does and does not promise", BODY))
dash.Handler.state, dash.Handler.cfg = st, cfg
h = object.__new__(dash.Handler)
h._update_card = lambda *a, **k: None
h._local_time = lambda: "now"
if mode == "dismissed":
    st.set_status(a1, "failed", {"error": "HTTP 429: too many"})
    class Req:
        command = "POST"; path = "/api/dismiss"; state = st
        def __init__(self, body):
            raw = json.dumps(body).encode(); self.headers = {"Content-Length": str(len(raw))}; self.rfile = io.BytesIO(raw)
        def _json(self, obj, code=200): self.answer = obj
        def _update_card(self, *a, **k): pass
        def _local_time(self): return "now"
    rq = Req({"id": a1}); rq.cfg = cfg
    dash._goals_routes(rq)
    print(f"  [dismiss] cycle 1: {oc1!r}, #{a1} failed, then dismissed: {rq.answer}")
    oc2, a2, s2 = run(post("What a seal does and does not promise", BODY))
    print(f"  [dismiss] listed as turned down: {'TURNED THESE DOWN' in prompts[-1]}; the same post again -> {oc2!r} (#{a2} {s2})")
    sys.exit(0)
r = h.decide(a1, "reject", reason="It says nothing a seal reader does not already know; show one seal whose label was wrong.")
print(f"  [reason] cycle 1: {oc1!r} (#{a1} {s1}); rejected with a reason: {r}")
if mode == "reason":
    oc2, a2, s2 = run(post("What a seal does, and what it does not promise", BODY.replace("It does not", "It doesn't")))
    u = prompts[-1]
    blk = u[u.find("YOUR OPERATOR TURNED THESE DOWN"):][:600] if "YOUR OPERATOR TURNED THESE DOWN" in u else ""
    print(f"  [reason] next prompt lists it: {'What a seal does and does not promise' in blk}; with his reason: "
          f"{'show one seal whose label was wrong' in blk}")
    print(f"  [reason] the same post reworded -> {oc2!r} (#{a2} {s2}); sent to the square: {len(sent)}")
    rep = st.db.execute("SELECT notes FROM cycles ORDER BY id DESC LIMIT 1").fetchone()["notes"]
    print(f"  [reason] the cycle's note names the rejected action: {rep == str(a1)}")
else:
    oc2, a2, s2 = run(post("Witness marks expire after two days",
                           "A witness mark older than two days no longer counts toward the chain, which the "
                           "registry documents on its help page but nobody here has mentioned."))
    print(f"  [other ] a different post after the rejection -> {oc2!r} (#{a2} {s2})")
