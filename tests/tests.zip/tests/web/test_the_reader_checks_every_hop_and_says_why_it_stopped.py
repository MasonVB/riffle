# ==========================================================================
# bin/riffle-reader checks every redirect hop against the allowlist, and
# every way a read can stop says why.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case; each runs the tree's bin/riffle-reader main()
#   once against a stub network (no real request is made) and prints the
#   exit code, what it said, and every URL it asked for:
#     offlist       arxiv.org redirects to a host not on the list: refused,
#                   and the off-list host is never asked
#     plainhttp     a redirect to http://: refused, never asked
#     relative      a redirect to "/abs/2" on the same host: followed, read,
#                   both hops reported
#     nolocation    a 302 with no Location header
#     loop          redirects without end: stops after MAX_REDIRECTS
#     paywall       HTTP 403: says paywall, login, bot filter or proxy
#     ratelimited   HTTP 429: says to wait
#     servererror   HTTP 500
#     unreachable   the host cannot be reached
#     nourl         no --url and no --list-domains
#     listdomains   --list-domains: the list, without the path-only host
#     notaurl, badport, nohost   URLs host_ok cannot read
#     latin1        a windows-1252 page is decoded by its declared charset
#
# WHY IT EXISTS
#   The coverage sweep of bin/ (2026-11-27, batch 27): of 18 lines in
#   riffle-reader that refuse, 12 were reached by no test, among them the
#   check of each redirect hop. The reading allowlist holds only if a listed
#   page cannot hand the reader on to an unlisted one.
#
# HOW IT WORKS
#   bin/riffle-reader loaded as a module; urllib.request.build_opener is
#   replaced by an opener that answers from the case's script.
#
# READING THE OUTPUT
#   `[case] exit <code> | <what it said> | asked: <urls>`
#
# CHANGELOG
#   2026-11-27  Written from the coverage sweep of bin/ (batch 27).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, io, json, contextlib, email.message, urllib.error
import importlib.machinery, importlib.util
repo, mode = sys.argv[1], sys.argv[2]
ld = importlib.machinery.SourceFileLoader("rr", os.path.join(repo, "bin", "riffle-reader"))
spec = importlib.util.spec_from_loader("rr", ld)
rr = importlib.util.module_from_spec(spec); ld.exec_module(rr)

START = "https://arxiv.org/abs/1"
ASKED = []
def hdrs(**kv):
    h = email.message.Message()
    for k, v in kv.items():
        h[k.replace("_", "-")] = v
    return h
def redirect(code, loc=None):
    return urllib.error.HTTPError(ASKED[-1], code, "moved", hdrs(**({"Location": loc} if loc else {})), None)
class Page:
    def __init__(self, body, ctype="text/html; charset=utf-8"):
        self.status, self.headers, self._b = 200, hdrs(Content_Type=ctype), body
    def read(self, n=-1): return self._b
    def __enter__(self): return self
    def __exit__(self, *a): return False
def answer(url):
    if mode == "offlist": return redirect(301, "https://evil.example.com/abs/1")
    if mode == "plainhttp": return redirect(302, "http://arxiv.org/abs/1")
    if mode == "relative":
        return redirect(302, "/abs/2") if url.endswith("/1") else Page(b"<p>The abstract.</p>")
    if mode == "nolocation": return redirect(302)
    if mode == "loop": return redirect(302, f"/abs/{len(ASKED) + 1}")
    if mode == "paywall": return urllib.error.HTTPError(url, 403, "Forbidden", hdrs(), None)
    if mode == "ratelimited": return urllib.error.HTTPError(url, 429, "Too Many", hdrs(), None)
    if mode == "servererror": return urllib.error.HTTPError(url, 500, "Oops", hdrs(), None)
    if mode == "unreachable": return urllib.error.URLError("no route to host")
    if mode == "latin1":
        return Page("<p>Café — résumé</p>".encode("cp1252"),
                    "text/html; charset=windows-1252")
    return Page(b"<p>ok</p>")
class Opener:
    def open(self, req, timeout=None):
        ASKED.append(req.full_url)
        a = answer(req.full_url)
        if isinstance(a, Exception):
            raise a
        return a
rr.urllib.request.build_opener = lambda *h: Opener()

argv = {"nourl": [], "listdomains": ["--list-domains"],
        "notaurl": ["--url=https://[::1/abs"], "badport": ["--url=https://arxiv.org:abc/abs/1"],
        "nohost": ["--url=https:///abs/1"]}.get(mode, [f"--url={START}"])
sys.argv = ["riffle-reader"] + argv
out, err = io.StringIO(), io.StringIO()
code = 0
with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
    try:
        rr.main()
    except SystemExit as e:
        code = e.code if isinstance(e.code, int) else 1
said = " ".join(err.getvalue().replace("riffle-reader: ", "").split())
if out.getvalue().strip():
    j = json.loads(out.getvalue())
    if j.get("ok") is False:
        said = "refused: " + j["error"]
    elif "domains" in j:
        said = (f"{len(j['domains'])} domains; arxiv.org listed: {'arxiv.org' in j['domains']}; "
                f"gcc.gnu.org listed: {'gcc.gnu.org' in j['domains']}")
    else:
        said = f"read {j['url']} after {len(j['hops'])} hop(s): {j['text']!r}"
print(f"  [{mode:11}] exit {code} | {said[:110]!r} | asked: "
      + (", ".join(u.replace('https://', '') for u in ASKED[:3]) + (f" (+{len(ASKED) - 3})" if len(ASKED) > 3 else "")
         if ASKED else "nothing"))
