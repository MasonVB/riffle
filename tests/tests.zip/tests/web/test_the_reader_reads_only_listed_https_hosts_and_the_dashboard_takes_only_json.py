# ==========================================================================
# riffle's reader reads only listed hosts, over https; and the dashboard
# accepts a write only as JSON, so a page on another site cannot post to it.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     reader  bin/riffle-reader's host_ok on: a listed host; the same over
#             http; a host not on the list; a made-up subdomain of a listed
#             host whose parent is not open to subdomains; a subdomain of a
#             parent that is (nih.gov); an address given as an IP
#     dash    the dashboard's POST /api/decide sent as a form (what a page
#             on another site can send without asking), as text/plain, and
#             as JSON
#
# WHY IT EXISTS
#   Audit 2026-11-14, section 7.1: the reader's allowlist and its https-only
#   rule, and the dashboard's JSON-only rule (its cross-site protection),
#   could each be switched off with every test still passing. No test ran
#   bin/riffle-reader at all.
#
# HOW IT WORKS
#   Loads bin/riffle-reader as a module and calls host_ok (nothing is
#   fetched). Drives dash.Handler.do_POST directly with the three bodies.
#
# READING THE OUTPUT
#   `[reader] url -> allowed | refused: why` and `[dash] how it was sent ->
#   status`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/web/test_the_reader_reads_only_listed_https_hosts_and_the_dashboard_takes_only_json.py . reader
#
# CHANGELOG
#   2026-11-18  Written for the audit's section 7.1 (batch 11).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import importlib.machinery, importlib.util, io, os, sys, tempfile, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)

if mode == "reader":
    ld = importlib.machinery.SourceFileLoader("reader", os.path.join(repo, "bin", "riffle-reader"))
    reader = importlib.util.module_from_spec(importlib.util.spec_from_loader("reader", ld))
    ld.exec_module(reader)
    for url in ("https://arxiv.org/abs/2401.00001",
                "http://arxiv.org/abs/2401.00001",
                "https://example.com/anything",
                "https://evil.arxiv.org/abs/2401.00001",
                "https://www.ncbi.nlm.nih.gov/pmc/",
                "https://93.184.216.34/"):
        host, why = reader.host_ok(url)
        print(f"  [reader] {url:42} -> {'allowed' if host else 'refused: ' + why[:60]}")
else:
    from agent import dash
    from agent.state import State
    cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
    out = {}
    h = dash.Handler.__new__(dash.Handler)
    h.state = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
    h.cfg = cfg
    h._host_refused = lambda: False
    h._json = lambda obj, code=200: out.update(code=code)
    for how, ctype, raw in (("as a form (another site can)", "application/x-www-form-urlencoded", b"id=1&verdict=approve"),
                            ("as text/plain (another site can)", "text/plain", b'{"id": 1, "verdict": "approve"}'),
                            ("as JSON", "application/json", b'{"id": 1, "verdict": "approve"}')):
        h.path, h.command = "/api/decide", "POST"
        h.headers = {"Content-Type": ctype, "Content-Length": str(len(raw))}
        h.rfile = io.BytesIO(raw)
        out.clear()
        h.do_POST()
        print(f"  [dash  ] {how:34} -> {out.get('code')}")
