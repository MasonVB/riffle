# ==========================================================================
# The reading list as the operator decided it on 2026-11-19, the document
# and the reader agreeing on it, and the label riffle is shown for a page:
# when it reads one, and on a search result.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     reader  bin/riffle-reader's host_ok on the 21 hosts added, the five
#             kept out, gcc.gnu.org inside and outside /onlinedocs (and a
#             ".." that leaves it), and mailarchive.ietf.org; and whether
#             --list-domains offers gcc.gnu.org to search_web
#     doc     reading-allowlist.md against the reader: hosts the document
#             lists (and does not strike through) that the reader refuses,
#             and hosts it strikes through that the reader allows
#     labels  cycle.source_label on a page from each kind: a forum, a mailing
#             list, an open wiki, a preprint, an index, a working paper, an
#             Internet-Draft, and the reviewed pages beside them; and a forum
#             path reached through "..", "//" or "%66"
#     search  one cycle with a search's results waiting: the lines riffle is
#             shown under WHAT YOUR SEARCH FOUND
#
# WHY IT EXISTS
#   Audit F45: the document listed 27 hosts the reader refused. Audit F17:
#   reviewed sites with a forum, a list archive or a comment page, open
#   wikis, and indexes of unreviewed work were unlabelled, and so was every
#   search result. The operator chose: add 21 hosts and gcc.gnu.org's
#   manuals, keep five out, and label rather than refuse (option B).
#
# HOW IT WORKS
#   reader/doc: bin/riffle-reader loaded as a module (nothing is fetched).
#   labels: the function directly. search: cycle.main against a stub
#   registry and composer, with the note last_search set.
#
# READING THE OUTPUT
#   `[case] what -> result`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/web/test_the_reading_list_as_decided_and_what_each_page_is_marked.py . labels
#
# CHANGELOG
#   2026-11-19  Written for F45 and F17, as decided (batch 12).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import importlib.machinery, importlib.util, json, os, re, subprocess, sys
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)


def load_reader():
    ld = importlib.machinery.SourceFileLoader("reader", os.path.join(repo, "bin", "riffle-reader"))
    m = importlib.util.module_from_spec(importlib.util.spec_from_loader("reader", ld))
    ld.exec_module(m)
    return m


ADDED = ["cde.ucr.cjis.gov", "cve.mitre.org", "data.worldbank.org", "datatracker.ietf.org",
         "ieeexplore.ieee.org", "journals.aps.org", "www.open-std.org", "pandas.pydata.org",
         "patents.google.com", "reference.wolfram.com", "scikit-learn.org", "scipy.org",
         "webbtelescope.org", "www.britishmuseum.org", "www.fda.gov", "www.fhwa.dot.gov",
         "www.govinfo.gov", "www.ncjrs.gov", "www.nrcs.usda.gov", "www.rijksmuseum.nl",
         "www.weather.gov"]
KEPT_OUT = ["osf.io", "zenodo.org", "archive.org", "libretexts.org", "raw.githubusercontent.com"]

if mode == "reader":
    r = load_reader()
    ok = [h for h in ADDED if r.host_ok(f"https://{h}/")[0]]
    print(f"  [reader] the 21 added: {len(ok)} allowed; refused: {[h for h in ADDED if h not in ok]}")
    print(f"  [reader] the five kept out, allowed: {[h for h in KEPT_OUT if r.host_ok(f'https://{h}/')[0]]}")
    for u in ("https://gcc.gnu.org/onlinedocs/gcc/Optimize-Options.html",
              "https://gcc.gnu.org/onlinedocs",
              "https://gcc.gnu.org/bugzilla/show_bug.cgi?id=1",
              "https://gcc.gnu.org/onlinedocs/../bugzilla/",
              "https://gcc.gnu.org/onlinedocs/%2e%2e/ml/gcc/",
              "https://mailarchive.ietf.org/arch/browse/ietf/"):
        host, why = r.host_ok(u)
        print(f"  [reader] {u:58} -> {'allowed' if host else 'refused: ' + why[:52]}")
    out = subprocess.run([sys.executable, os.path.join(repo, "bin", "riffle-reader"), "--list-domains"],
                         capture_output=True, text=True, timeout=30).stdout
    doms = json.loads(out)["domains"]
    print(f"  [reader] --list-domains: {len(doms)} hosts; gcc.gnu.org among them: {'gcc.gnu.org' in doms}")
elif mode == "doc":
    r = load_reader()
    doc = open(os.path.join(repo, "reading-allowlist.md")).read()
    body = doc.split("## Labels")[0]
    struck = set(re.findall(r"~~`([^`]+)`~~", body))
    listed = set()
    for h, path in re.findall(r"(?<!~)`([a-z0-9.-]+\.[a-z]{2,})(/[^`]*)?`", body):
        if h not in struck and "/" not in h:
            listed.add(h + (path or "/"))
    # the prose names a few hosts it is explaining, not listing
    prose = {"gcc.gnu.org/", "raw.githubusercontent.com/"}
    refused = sorted(u for u in listed - prose if not r.host_ok("https://" + u)[0])
    print(f"  [doc   ] listed, not struck, and refused by the reader: {refused}")
    print(f"  [doc   ] struck through and still allowed: "
          f"{sorted(h for h in struck if r.host_ok('https://' + h + '/')[0])}")
elif mode == "labels":
    from agent.cycle import source_label
    for u in ("https://sqlite.org/forum/forumpost/1a2b", "https://sqlite.org/wal.html",
              "https://www.postgresql.org/message-id/abc%40example.org", "https://www.postgresql.org/docs/16/",
              "https://www.mathworks.com/matlabcentral/answers/1", "https://www.mathworks.com/help/matlab/",
              "https://go.dev/play/p/abc", "https://www.sec.gov/comments/s7-01-24/x.htm",
              "https://en.cppreference.com/w/cpp/atomic", "https://en.wikipedia.org/wiki/Consistency_(database_systems)",
              "https://arxiv.org/abs/2401.00001", "https://core.ac.uk/download/1.pdf",
              "https://www.nber.org/papers/w31000", "https://www.nber.org/about-nber",
              "https://datatracker.ietf.org/doc/draft-ietf-httpbis-x/", "https://datatracker.ietf.org/doc/rfc9110/",
              "https://forum.earthdata.nasa.gov/viewtopic.php?t=1", "https://docs.python.org/3/library/os.html",
              "https://sqlite.org/docs/../forum/x", "https://sqlite.org//forum/x", "https://sqlite.org/%66orum/x"):
        print(f"  [labels] {u:62} -> {source_label(u)[0] or '(reviewed)'}")
else:
    import copy, tempfile, yaml
    from agent import cycle, cortex, drives, project
    from agent.state import State, utcnow
    me = json.load(open(os.environ["RIFFLE_ME_JSON"]))

    class Stub:
        def __init__(self, *a, **k): pass

        def __getattr__(self, n):
            return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (
                lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})
    cycle.Reader = cycle.Writer = Stub
    cycle.do_witness = lambda *a, **k: None
    cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
    drives.pick_drive = lambda *a, **k: "understand"
    users = []

    def complete(llm, system, user, schema=None, **k):
        users.append(user)
        if "Choose ONE action" not in user:
            return json.dumps({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                              else {"promote": [], "write": [], "drop": [], "note": ""})
        return json.dumps({"action": "noop", "payload": {"why": "reading"}, "rationale": "nothing to do this cycle"})
    cortex.complete = complete
    d = tempfile.mkdtemp()
    cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
    cfg.setdefault("library", {})["root"] = os.path.join(d, "library")
    open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
    cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
    st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
    st.note("last_search", json.dumps({"at": utcnow(), "site": "sqlite.org", "query": "wal checkpoint", "results": [
        {"url": "https://sqlite.org/wal.html", "title": "Write-Ahead Logging", "snippet": "The WAL approach inverts this."},
        {"url": "https://sqlite.org/forum/forumpost/9f1e", "title": "WAL file grows forever",
         "snippet": "Checkpoints never finish while a reader holds a snapshot."}]}))
    sys.argv = ["cycle", "--config", cp, "--force"]
    try:
        cycle.main()
    except SystemExit:
        pass
    u = next((x for x in users if "Choose ONE action" in x), "")
    block = u[u.find("WHAT YOUR SEARCH FOUND"):].split("\n\n")[0] if "WHAT YOUR SEARCH FOUND" in u else ""
    for line in block.splitlines():
        print(f"  [search] {line.strip()[:150]}")
