# ==========================================================================
# A URL with a port or a user name in it is refused by the reader, and the
# cycle's "written by anyone" / "unreviewed preprint" labels go by the host,
# so neither can be slipped past by writing the address differently.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   One line per URL: what bin/riffle-reader's host_ok says, and the label
#   cycle.source_label gives it.
#
# WHY IT EXISTS
#   Audit F41 (2026-11-14): source_label looked up the URL's netloc, the
#   reader checked its hostname. They differ when the URL carries a port or
#   a user name, so https://en.wikipedia.org:443/wiki/Water was read and
#   shelved with no warning; the same for arXiv and the other preprint
#   hosts. riffle has no reason to write such a URL; a stranger steering it
#   to a page without the warning does.
#
# HOW IT WORKS
#   Loads bin/riffle-reader as a module (it runs main() only as a script)
#   and calls host_ok; calls cycle.source_label. Nothing is fetched.
#
# READING THE OUTPUT
#   `url | reader: allowed / refused: why | label: ...`
#
# RUNNING IT ON ITS OWN
#   python3 tests/web/test_a_port_or_user_name_does_not_lose_the_written_by_
#   anyone_label.py .
#
# CHANGELOG
#   2026-11-16  Written for audit F41 (batch 7).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import importlib.machinery, importlib.util, os, sys
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle
ld = importlib.machinery.SourceFileLoader("reader", os.path.join(repo, "bin", "riffle-reader"))
reader = importlib.util.module_from_spec(importlib.util.spec_from_loader("reader", ld))
ld.exec_module(reader)
for url in ("https://en.wikipedia.org/wiki/Water",
            "https://en.wikipedia.org:443/wiki/Water",
            "https://en.wikipedia.org:8443/wiki/Water",
            "https://reader@en.wikipedia.org/wiki/Water",
            "https://arxiv.org:443/abs/2401.00001",
            "https://www.arxiv.org/abs/2401.00001",
            "https://docs.python.org/3/library/os.html"):
    host, why = reader.host_ok(url)
    tag, _ = cycle.source_label(url)
    print(f"  {url:44} | reader: {'allowed' if host else 'refused: ' + why[:48]:56} | label: {tag or '-'}")
