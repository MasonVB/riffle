# ==========================================================================
# An open question from riffle is always on the dashboard: on the first
# load however many messages came after it, after the clear button, and
# counted in "waiting". It is pushed to the operator's phone once. Once
# answered it stops counting.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   One question asked the way the cycle asks one, followed by 500 ordinary
#   messages. Then, from the dashboard's own snapshot(): whether the
#   question's card is in the first load, whether it is in waiting_ids, and
#   the question count; the same after clear_chat(); the same after it is
#   answered. And how many pushes two cycles' worth of announce_pending()
#   send for it.
#
# WHY IT EXISTS
#   Found on the box, 2026-11-14. Three questions had waited up to five
#   weeks (asked 10-08, 11-07 and 11-08) and the operator had never seen
#   one. A question was one message in the chat log: the page's first load
#   is the newest 400 messages, about two days of riffle's reports, and the
#   clear button archived everything, so each scrolled out or was cleared.
#   Nothing re-sent it the way queued proposals are re-sent, nothing counted
#   it as waiting, and no push was sent for it (audit 2026-11-10, F29).
#   riffle, at its limit of three open questions, could ask nothing more.
#
# HOW IT WORKS
#   The dashboard's Handler is made without a server, with a stand-in for
#   the chat worker. notify.send is replaced by a recorder and the notify
#   window held open.
#
# READING THE OUTPUT
#   `first load: card True, waiting True, questions 1`; the same after the
#   clear; `answered: card still sent True, waiting False, questions 0`;
#   `pushes: 1`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON, and
#   PYTHONPATH=tests/lib for the safety net). The simplest way is
#   tests/run_all.sh, which runs everything on a temporary copy of the tree.
#
# CHANGELOG
#   2026-11-14  Written for the questions fix.
#   2026-11-15  Checks that an answered card is still sent (for a day): only
#               open ones were, so on the box every answered card stayed at
#               "sending..." though the answer was saved.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile, yaml; sys.path.insert(0, sys.argv[1])
from agent import dash, notify
from agent.state import State, ask_operator, answer_question
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = d
cfg["notify"]["enabled"] = True
st = State(os.path.join(d, "s.sqlite"))
qid, _ = ask_operator(st, "Is listing 13 set aside for good, or only for now?", "", 1)
st.say("question", "Is listing 13 set aside for good, or only for now?",
       {"drive": "earn", "qid": qid, "status": "open", "why": ""})
for i in range(500):
    st.say("report", f"Cycle {i} · I read a thread.")
class Wk:
    busy = False
    def depth(self): return 0
class H(dash.Handler): pass
H.state, H.cfg = st, cfg
h = H.__new__(H); h.worker = Wk()
qmid = st.db.execute("SELECT id FROM messages WHERE role='question'").fetchone()[0]
def show(label):
    snap = h.snapshot(0)
    print(f"  {label}: card {any(m['id'] == qmid for m in snap['messages'])}, "
          f"waiting {qmid in snap['waiting_ids']}, questions {snap.get('questions')}")
show("first load")
h.clear_chat()
show("after clear")
SENT = []
notify.send = lambda cfg, title, msg, url=None, priority=0: SENT.append(title) or (True, "ok")
notify.in_window = lambda cfg, now=None: True
notify.announce_pending(st, cfg, lambda *a, **k: None)
notify.announce_pending(st, cfg, lambda *a, **k: None)
answer_question(st, qid, "For good.")
snap = h.snapshot(0)
print(f"  answered: card still sent {any(m['id'] == qmid for m in snap['messages'])}, "
      f"waiting {qmid in snap['waiting_ids']}, questions {snap.get('questions')}")
print(f"  pushes: {len(SENT)} ({', '.join(SENT)})")
