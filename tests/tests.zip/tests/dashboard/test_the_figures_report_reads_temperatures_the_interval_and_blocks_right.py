# ==========================================================================
# Three lines of the figures report read what is there: the day's hottest
# temperature, the cycle interval actually in force, and one row per kind of
# prompt block however its heading's numbers change.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   figures.report on a store holding: two telemetry samples whose
#   temperatures are flat, as telemetry.temps() writes them; the interval
#   set on the dashboard (15) and absent from config.yaml; three prompt fits
#   whose blocks are one heading with a different count each time. Prints the
#   report's interval line, its "last 24 h" line, and its block rows for that
#   heading.
#
# WHY IT EXISTS
#   The box's figures on 2026-11-18 said "hottest -" beside a reading of 80.0
#   (it looked only for nested temperatures, and they are flat), "interval
#   None min (set: 15)" (config.yaml's value alone, which is absent), and
#   listed WHAT ACTUALLY MOVED seven times, once per count in its heading.
#
# HOW IT WORKS
#   The real functions on a fresh store; rows written as the cycle and
#   telemetry write them.
#
# READING THE OUTPUT
#   `[figures] <the report's line>`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/dashboard/test_the_figures_report_reads_temperatures_the_interval_and_blocks_right.py .
#
# CHANGELOG
#   2026-11-19  Written from the box's figures (batch 12).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import figures, telemetry
from agent.state import State, utcnow

cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = tempfile.mkdtemp()
(cfg.get("cycle") or {}).pop("interval_minutes", None)
st = State(os.path.join(cfg["data_dir"], "s.sqlite"))
telemetry.ensure(st); figures.ensure(st)
st.note("cycle_interval_minutes", 15)
for temps, avail in (({"coretemp.Package id 0": 80.0, "coretemp.Core 0": 78.0}, 43000),
                     ({"coretemp.Package id 0": 76.5, "acpitz": 27.8}, 42945)):
    st.db.execute("INSERT INTO telemetry (ts, kind, label, payload) VALUES (?, 'sample', 'tick', ?)",
                  (utcnow(), json.dumps({"mem": {"MemAvailable": avail}, "cpu": {"load1": 5.9}, "temps": temps})))
for n in (0, 3, 4):
    blocks = {f"WHAT ACTUALLY MOVED since your last walk — {n} new posts, {n + 2} comments": [7335, 7335],
              "FRONT PAGE — an index": [5987, 5987]}
    st.db.execute("INSERT INTO prompt_fits (at, cycle_id, ceiling, running_ctx, sys_chars, tail_chars, room,"
                  " wanted, sent, blocks) VALUES (?, 1, 105000, 49152, 30965, 4133, 69535, 13322, 13322, ?)",
                  (utcnow(), json.dumps(blocks)))
st.db.commit()
text = figures.report(st, cfg)
for line in text.splitlines():
    s = line.strip()
    if s.startswith("max_prompt_chars") or s.startswith("last 24 h,") or s.startswith("WHAT ACTUALLY MOVED"):
        print(f"  [figures] {s[:120]}")
