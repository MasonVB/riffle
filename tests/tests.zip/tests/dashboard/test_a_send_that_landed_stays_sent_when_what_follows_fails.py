# ==========================================================================
# An approval that reached the square stays `executed` when the bookkeeping
# after it fails, and an unreadable secret ends the send as `failed`.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     landed   the registry accepts the comment, then the follow-up cycle
#              the dashboard starts raises: the row stays `executed`, the
#              day's count includes it, and the journal says what failed
#     secret   the secret file is missing: nothing reaches the registry
#              and the row ends `failed` (not stuck at `sending`)
#
# WHY IT EXISTS
#   Audit F11 (2026-11-10): everything after a successful send sat in the
#   same try as the send, so a failure there marked a comment the registry
#   HAD received as failed; the duplicate checks ignore failed rows, so it
#   could be sent again. The secret was read before the try, so a missing
#   secret killed the worker with the row at `sending`.
#
# HOW IT WORKS
#   The real dash.Handler.decide with dash.execute replaced by a stand-in
#   registry; waits for the worker thread to finish.
#
# READING THE OUTPUT
#   `[landed] ...` or `[secret] ...`: what reached the registry, the row's
#   status, and the journal line.
#
# RUNNING IT ON ITS OWN
#   python3 tests/dashboard/test_a_send_that_landed_stays_sent_when_what_
#   follows_fails.py . landed
#
# CHANGELOG
#   2026-11-15  Written for audit F11 (batch 5).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import dash
from agent.state import State, utcnow
received = []
def fake_execute(writer, kind, p):
    received.append(p.get("body")); return {"comment_id": 7001, "now_utc": utcnow()}
dash.execute = fake_execute
class W:
    def __init__(self, *a, **k): pass
dash.Writer = W
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
if mode != "secret":
    open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
st = State(os.path.join(d, "s.sqlite"))
class H(dash.Handler):
    pass
H.state, H.cfg = st, cfg
h = H.__new__(H)
h._update_card = lambda *a, **k: None
h._local_time = lambda: "now"
def boom(*a, **k):
    raise RuntimeError("the follow-up cycle could not be started")
h.run_cycle = boom if mode == "landed" else (lambda *a, **k: None)
aid = st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,?,'answer',?,'r','queued')",
                    (utcnow(), "comment", json.dumps({"post_id": 4, "parent_id": 2,
                                                      "body": "The receipts settle in order only within one batch."}))).lastrowid
st.db.commit()
r = h.decide(aid, "approve")
import threading
for t in threading.enumerate():          # the send worker, to the end of its bookkeeping
    if t is not threading.current_thread():
        t.join(10)
row = st.action(aid)
used = st.cap_used(utcnow()[:10], "comment")
line = st.db.execute("SELECT text FROM journal WHERE text LIKE '%#" + str(aid) + "%' ORDER BY id DESC LIMIT 1").fetchone()
print(f"  [{mode:6}] decide -> {r}; the registry received it: {bool(received)}; the row says {row['status']!r};"
      f" counted against today: {used}")
print(f"  [{mode:6}] the journal: {(line['text'] if line else '').split(': [Errno')[0][:110]!r}")
