# ==========================================================================
# agent/transcript.py exports what riffle said and did over a window: each
# action in full with what it answered, what a check told it and why you
# rejected it; its questions; your chat. It writes nothing.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   A store with, in the last four days: a reply to a comment from the
#   inbox; a post refused by a check (and what riffle was told); a vote on a
#   comment from a thread riffle read; a post you rejected, with your
#   reason; a question; two chat messages; and an action from ten days ago
#   that must not appear. Prints the export, then whether the database file
#   changed and whether its old action is in it.
#
# WHY IT EXISTS
#   2026-11-19: the operator asked for an audit of everything riffle said
#   over four days. The square is out of reach from the auditor's sandbox,
#   and riffle's own database holds more than the square does (what was
#   refused, queued and rejected, and why), so the record is exported from it.
#
# HOW IT WORKS
#   transcript.main(["--db", path, "--days", "4"]) on a fresh store; the
#   database file's sha256 before and after.
#
# READING THE OUTPUT
#   The export itself, then `[after] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/dashboard/test_the_transcript_export_reads_everything_and_writes_nothing.py .
#
# CHANGELOG
#   2026-11-19  Written with agent/transcript.py (batch 16).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, io, json, re, hashlib, tempfile, contextlib, datetime as dt
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import transcript, inbox, project, chat
from agent.state import State

d = tempfile.mkdtemp(); path = os.path.join(d, "state.sqlite")
st = State(path); inbox.ensure(st); project.ensure(st); st.db.executescript(project.READS_SCHEMA); st.db.executescript(chat.CACHE_SCHEMA)
from agent import state as _state_mod; st.db.executescript(_state_mod.ASK_SCHEMA)
now = dt.datetime.now(dt.timezone.utc)
at = lambda h: (now - dt.timedelta(hours=h)).strftime("%Y-%m-%dT%H:%M:%SZ")


def act(h, kind, payload, status, rationale="r", response=None, cycle=1):
    return st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status,response,executed_at)"
                         " VALUES (?,?,?,?,?,?,?,?,?)",
                         (cycle, at(h), kind, "answer", json.dumps(payload), rationale, status,
                          json.dumps(response) if response else None,
                          at(h) if status == "executed" else None)).lastrowid


st.db.execute("INSERT INTO cycles (id, started_at, ended_at, drive, outcome, notes) VALUES (1, ?, ?, 'answer', 'executed', NULL)", (at(50), at(50)))
st.db.execute("INSERT INTO cycles (id, started_at, ended_at, drive, outcome, notes) VALUES (2, ?, ?, 'make', 'post-link-unused', 'https://en.wikipedia.org/wiki/X')", (at(30), at(30)))
st.db.execute("INSERT INTO inbox_items (key, comment_id, post_id, post_title, author, body, status) VALUES"
              " ('c501', 501, 12, 'On witness chains', 'kilmon-ai', 'Your arithmetic is off: 7 of 11 is 64%, not 70%.', 'answered')")
st.db.execute("INSERT INTO thread_reads (project_id, cycle_id, ts, post_id, title, author, comments_total, comments_shown, body, replies, digest, comments_json)"
              " VALUES (1, 1, ?, 12, 'On witness chains', 'kael', 2, 2, 'b', '', 'd', ?)",
              (at(60), json.dumps([{"id": 502, "author": "gradient-dissent", "body": "Mutation (c) is the test that matters."}])))
act(240, "comment", {"post_id": 12, "body": "Too old to be in the window."}, "executed")
act(50, "comment", {"post_id": 12, "parent_id": 501, "body": "You are right: 7 of 11 is 64%. I have corrected the note."},
    "executed", "answering kilmon-ai's correction", {"comment_id": 900})
act(30, "post", {"title": "What a witness chain proves", "body": "See https://en.wikipedia.org/wiki/X for more."},
    "blocked", "the project is ready", cycle=2)
st.say("report", "Cycle 2 \u00b7 I did not send that: it links https://en.wikipedia.org/wiki/X without quoting it.")
act(20, "vote", {"target_type": "comment", "target_id": 502, "value": 1}, "executed", "a specific, checkable point")
act(10, "post", {"title": "Marrow, again", "body": "The same post a third time."}, "rejected", "posting is open",
    {"by": "you", "reason": "you posted this yesterday"})
st.db.execute("INSERT INTO questions (asked_at, question, why, answered_at, answer) VALUES (?, 'Should I keep listing 65?', 'it has no submissions', ?, 'Yes, keep it.')", (at(40), at(39)))
st.db.execute("INSERT INTO messages (ts, role, content, done) VALUES (?, 'user', 'How is the Marrow work going?', 1)", (at(5),))
st.db.execute("INSERT INTO messages (ts, role, content, done) VALUES (?, 'agent', 'The analysis is done and waiting for the posting clock.', 1)", (at(5),))
st.db.commit(); st.db.close()
before = hashlib.sha256(open(path, "rb").read()).hexdigest()
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    rc = transcript.main(["--db", path, "--days", "4"])
out = buf.getvalue()
out = re.sub(r"\d{4}-\d\d-\d\d \d\d:\d\d", "<time>", out)
for line in out.splitlines():
    print("  " + line if line else "")
after = hashlib.sha256(open(path, "rb").read()).hexdigest()
print(f"  [after] exit {rc}; the database file unchanged: {before == after}; the ten-day-old comment in it: {'Too old' in out}")
