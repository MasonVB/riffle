# ==========================================================================
# The figures report (agent/figures.py) records every model call's timings
# and every cycle's fit, and carries, in one copyable page and one file, the
# figures the operator used to be asked to fetch with journalctl, systemctl
# and sqlite.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Two real cycle.main() runs against a stand-in composer that answers the
#   way llama-server does (`timings`, `usage`), with cortex's own HTTP call
#   replaced, not cortex.complete, so the recording path is the real one.
#   Then: how many model calls were stored and with what purpose; whether
#   the fit was recorded; whether figures.txt was written after the cycle;
#   which sections the report has; how long it took to build; and that the
#   dashboard serves it as a page with a copy button and as plain text.
#
# WHY IT EXISTS
#   2026-11-15, the operator: "Instead of [commands to run on the box],
#   update one of riffle's files to record this and every other figure you
#   asked me to check into a log so I can just take a snapshot or a copy of
#   the log and provide it." Every measurement requested over the past month
#   is in the report; the composer's timings and the per-block fit were not
#   recorded anywhere riffle could read, and now are.
#
# READING THE OUTPUT
#   One line each: calls stored, fit recorded, file written, the sections,
#   the build time (under a second), the two dashboard routes.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets. The
#   simplest way is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-15  Written with agent/figures.py.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, time, threading, http.client
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project, figures, dash
from agent.state import State
from http.server import ThreadingHTTPServer
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "understand"
cortex.composer_ctx = lambda llm: 49152
def post_json(url, body, timeout=1800):
    user = body["messages"][-1]["content"]
    if "response_format" in body:
        text = json.dumps({"rationale": "nothing needs doing this cycle", "action": "noop",
                           "payload": {"why": "nothing to do"}})
    else:
        text = json.dumps({"continuity": "c", "promote": [], "write": [], "drop": [], "note": ""})
    n = sum(len(m["content"]) for m in body["messages"]) // 3
    return {"choices": [{"message": {"content": text}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": n, "completion_tokens": 40},
            "timings": {"cache_n": n - 2000, "prompt_n": 2000, "prompt_ms": 95000.0,
                        "predicted_n": 40, "predicted_ms": 5000.0}}
cortex._post_json = post_json
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
for _ in range(2):
    sys.argv = ["cycle", "--config", cp, "--force"]
    try: cycle.main()
    except SystemExit: pass
    if cycle._CYCLE_LOCK: cycle._CYCLE_LOCK.close(); cycle._CYCLE_LOCK = None
    time.sleep(1.1)
rows = st.db.execute("SELECT purpose, prompt_n, cache_n, predicted_n FROM composer_calls").fetchall()
print(f"  calls stored: {len(rows)}, purposes {sorted({r[0] for r in rows})}, "
      f"each with tokens read and reused: {all(r[1] and r[2] for r in rows)}")
fits = st.db.execute("SELECT COUNT(*), MAX(length(blocks)) FROM prompt_fits").fetchone()
print(f"  fits recorded: {fits[0]}, with blocks: {bool(fits[1] and fits[1] > 20)}")
path = os.path.join(d, "figures.txt")
print(f"  figures.txt written after the cycle: {os.path.exists(path)}")
t0 = time.monotonic(); text = figures.report(st, cfg); took = time.monotonic() - t0
secs = [l[3:] for l in text.splitlines() if l.startswith("== ")]
print(f"  sections: {', '.join(secs)}")
print(f"  could not read in any section: {text.count('(could not read')} | built in under a second: {took < 1.0}")
print(f"  composer line for the cycle: {'cycle@8080' in text and 'chars/token' in text}")
class H(dash.Handler): pass
H.state, H.cfg = st, cfg
srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
port = srv.server_address[1]
for path in ("/figures", "/api/figures.txt"):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=20)
    c.request("GET", path, headers={"Host": f"127.0.0.1:{port}"})
    r = c.getresponse(); b = r.read().decode()
    print(f"  GET {path}: {r.status} {r.getheader('Content-Type')} | "
          + ("copy button: " + str("copy all" in b) if path == "/figures" else "starts: " + repr(b[:15])))
srv.shutdown()
