# ==========================================================================
# riffle keeps its history (journal, telemetry, model calls, dashboard
# messages, the board cache) until the disk is 85% used; past that, as much
# of the oldest goes as the database grew, and the record of what riffle did
# never goes.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   A store with old rows in every history table, plus cycles, actions, a
#   card for an action still waiting, and a 40-day-old model call:
#     40%     figures.after_cycle (which runs the check): whether the 40-day
#             model call and a 2-day-old telemetry sample are still there,
#             and whether telemetry still has its own prune
#     90%     about 200 KB of new journal rows, then storage.check: which
#             rows went, oldest first across the tables; whether what went
#             adds up to at least the growth; and that cycles, actions and
#             the waiting card are all still there
#     again   storage.check once more with nothing new: nothing goes
#
# WHY IT EXISTS
#   The operator's rule, 2026-11-19: keep everything until 85% of the disk
#   is used, by anything; past that, for each thing saved, delete the oldest
#   whose sizes add up to at least its own. Telemetry used to drop samples
#   after a day and the figures tables after 30 days, whatever the disk.
#
# HOW IT WORKS
#   The real functions on a fresh store, storage.disk_used_percent stood in.
#
# READING THE OUTPUT
#   `[case] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/dashboard/test_past_the_disk_limit_the_oldest_history_goes_as_the_database_grows.py .
#
# CHANGELOG
#   2026-11-19  Written for the disk rule (batch 14).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, yaml
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import figures, storage, telemetry, chat
from agent.state import State

cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
d = tempfile.mkdtemp(); cfg["data_dir"] = d
st = State(os.path.join(d, "state.sqlite"))
telemetry.ensure(st); figures.ensure(st); st.db.executescript(chat.CACHE_SCHEMA)
X = "x" * 3000
for day in range(1, 61):                     # sixty days of old history, oldest first
    ts = f"2026-09-{(day - 1) // 2 + 1:02d}T{12 if day % 2 else 18}:00:00Z"
    st.db.execute("INSERT INTO journal (ts, level, drive, text) VALUES (?, 'info', NULL, ?)", (ts, f"day {day:02d} {X}"))
    st.db.execute("INSERT INTO telemetry (ts, kind, label, payload) VALUES (?, 'sample', 'tick', ?)", (ts, json.dumps({"x": X})))
    st.db.execute("INSERT INTO messages (ts, role, content, meta, done) VALUES (?, 'agent', ?, '{}', 1)", (ts, f"said on day {day} {X}"))
    st.db.execute("INSERT INTO board_cache (post_id, fetched_at, title, body) VALUES (?, ?, 't', ?)", (day, ts, X))
cid = st.db.execute("INSERT INTO cycles (started_at, ended_at, drive, outcome) VALUES ('2026-10-01T00:00:00Z', '2026-10-01T00:10:00Z', 'answer', 'queued')").lastrowid
aid = st.db.execute("INSERT INTO actions (cycle_id, created_at, kind, drive, payload, rationale, status) VALUES (?, '2026-10-01T00:05:00Z', 'post', 'answer', '{}', 'r', 'queued')", (cid,)).lastrowid
st.db.execute("INSERT INTO messages (ts, role, content, meta, done) VALUES ('2026-08-30T00:00:00Z', 'proposal', 'the card', ?, 1)", (json.dumps({"action_id": aid}),))
st.db.execute("INSERT INTO composer_calls (at, purpose, chars) VALUES ('2026-10-09T00:00:00Z', 'cycle', 100)")
st.db.execute("INSERT INTO telemetry (ts, kind, label, payload) VALUES (strftime('%Y-%m-%dT%H:%M:%SZ','now','-2 days'), 'sample', 'two days old', '{}')")
st.db.commit()


def count(t, w=""):
    return st.db.execute(f"SELECT COUNT(*) FROM {t} {w}").fetchone()[0]


def history_bytes():
    """The history's size as storage.py counts it."""
    n = 0
    for name, order, ts, size, where in storage.HISTORY:
        n += st.db.execute(f"SELECT COALESCE(SUM({size}), 0) + COUNT(*) * {storage._ROW}"
                           f" FROM {name}").fetchone()[0]
    return n


storage.disk_used_percent = lambda p: 40.0
figures.after_cycle(st, cfg, [])
print(f"  [40%   ] the 40-day model call kept: {count('composer_calls') == 1}; the 2-day sample kept: "
      f"{count('telemetry', 'WHERE label=' + chr(39) + 'two days old' + chr(39)) == 1}; "
      f"telemetry has its own prune: {hasattr(telemetry, 'prune')}")
before = {t: count(t) for t in ("journal", "telemetry", "messages", "board_cache")}
storage.check(st, cfg)                       # below the limit: notes where it stands
live0 = storage.db_live_bytes(st)
for i in range(200):
    st.log(f"new line {i} " + "y" * 1000)
grew = storage.db_live_bytes(st) - live0
storage.disk_used_percent = lambda p: 90.0
hb = history_bytes()
said = []
gone = storage.check(st, cfg, lambda t, level="info": said.append(t))
after = {t: count(t) for t in before}
# Which tables lost rows, not how many: the counts follow SQLite's page use,
# which is not worth pinning to the row.
print(f"  [90%   ] the database grew by more than 150 KB: {grew > 150_000}; rows went from: {sorted(gone)}")
print(f"  [90%   ] what went adds up to at least the growth: {hb - history_bytes() >= grew}, "
      f"and not more than one more row's worth: {hb - history_bytes() < grew + 4000}")
print(f"  [90%   ] oldest first: the journal's day 01 gone {count('journal', 'WHERE text LIKE ' + chr(39) + 'day 01 %' + chr(39)) == 0}, "
      f"its day 60 kept {count('journal', 'WHERE text LIKE ' + chr(39) + 'day 60 %' + chr(39)) == 1}, "
      f"its new lines all kept {count('journal', 'WHERE text LIKE ' + chr(39) + 'new line%' + chr(39)) >= 200}")
print(f"  [90%   ] cycles {count('cycles')}, actions {count('actions')}, the waiting card kept: "
      f"{count('messages', 'WHERE role=' + chr(39) + 'proposal' + chr(39)) == 1}")
print(f"  [90%   ] logged: {said[0].split(' the database grew')[0] if said else None!r}")
gone2 = storage.check(st, cfg)
print(f"  [again ] nothing new, nothing more went: {gone2 == {}}")
