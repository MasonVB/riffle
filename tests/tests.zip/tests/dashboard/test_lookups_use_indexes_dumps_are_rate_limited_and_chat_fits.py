# ==========================================================================
# The dashboard finds cards through indexes, a burst of errors makes one
# telemetry dump a minute, and a chat turn is held to the composer's window.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case:
#     indexes  the plans sqlite chooses for finding a proposal's card and an
#              open question's card, with a malformed meta row in the table
#     dumps    ten error lines in a row: how many dumps were started
#     chat     a turn with ten 4,000-character turns of history, a 16,000-
#              character record and five lookup rounds of 14,000 characters
#              each, against a 24,576-token window: what is sent, and what
#              is kept (the system message and the question always)
#
# WHY IT EXISTS
#   Audit F26 (2026-11-10): the dashboard parsed the meta of every proposal
#   message on every 2.5-second poll while anything waited, and every error
#   line started a dump of eight subprocesses with no limit. Audit F35: the
#   chat prompt had caps on its parts and none on the whole.
#
# HOW IT WORKS
#   agent.state, agent.telemetry and agent.chat on a fresh store; telemetry's
#   dump is replaced by a counter; the composer's window is set, not asked.
#
# READING THE OUTPUT
#   `[case] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/dashboard/test_lookups_use_indexes_dumps_are_rate_limited_and_chat_fits.py . chat
#
# CHANGELOG
#   2026-11-17  Written for audit F26 and F35 (batch 9).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent.state import State
from agent import state as state_mod

st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite"))
if mode == "indexes":
    st.db.execute("INSERT INTO messages (ts,role,content,meta) VALUES ('t','proposal','old','{not json')")
    for i in range(1, 40):
        st.say("proposal", f"card {i}", {"action_id": i})
        st.say("question", f"q {i}", {"qid": i})
    st = State(st.path)                 # reopened, as the dashboard starts
    for name, sql in (
            ("a proposal's card", "SELECT id FROM messages WHERE role='proposal' AND json_valid(meta)"
                                  " AND json_extract(meta,'$.action_id') IN (3,7) ORDER BY id"),
            ("a question's card", "SELECT id FROM messages WHERE role='question' AND json_valid(meta)"
                                  " AND json_extract(meta,'$.qid') IN (5) ORDER BY id")):
        plan = " | ".join(r[3] for r in st.db.execute("EXPLAIN QUERY PLAN " + sql))
        print(f"  [indexes] {name}: {plan}")
    from agent import dash
    print(f"  [indexes] card_for(7) finds card {dash.card_for(st, 7)[0]}; the malformed row is skipped")
elif mode == "dumps":
    from agent import telemetry
    started = []
    telemetry.dump = lambda *a, **k: started.append(1)
    telemetry.install(st, {})
    for i in range(10):
        st.log(f"error number {i}", level="error")
    import time
    time.sleep(0.5)
    print(f"  [dumps  ] ten error lines in a row started {len(started)} dump(s); "
          f"all ten are in the journal: {st.db.execute('SELECT COUNT(*) FROM journal WHERE level=?', ('error',)).fetchone()[0] == 10}")
else:
    from agent import chat, cortex
    cortex.composer_ctx = lambda llm: 24576
    llm = {"max_tokens": 1800}
    msgs = [{"role": "system", "content": "S" * (5000 + 16000)}]
    for i in range(10):
        msgs.append({"role": "user" if i % 2 == 0 else "assistant", "content": f"turn {i} " + "h" * 4000})
    msgs.append({"role": "user", "content": "THE QUESTION: what did the build print?"})
    n_hist = 10
    for r in range(5):
        msgs += [{"role": "assistant", "content": f"round {r} " + "t" * 14000},
                 {"role": "user", "content": "<untrusted source=\"tool\">" + "r" * 1800 + "</untrusted>"}]
    before = sum(len(m["content"]) for m in msgs)
    said = []
    n_hist = chat._fit_chat(msgs, llm, n_hist, said.append)
    after = sum(len(m["content"]) for m in msgs)
    budget = int((24576 - 1800 - 96) * 3.0)
    print(f"  [chat   ] {before} chars wanted, {after} sent, budget {budget}: fits {after + 16 * len(msgs) <= budget}")
    print(f"  [chat   ] history turns left: {n_hist} of 10 | system kept: {msgs[0]['content'].startswith('SSSS')}"
          f" | the question kept whole: {any(m['content'] == 'THE QUESTION: what did the build print?' for m in msgs)}")
    print(f"  [chat   ] the log: {said}")
