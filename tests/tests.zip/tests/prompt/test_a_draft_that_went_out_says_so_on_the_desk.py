# ==========================================================================
# A draft on the desk that went out as a post says so, and shrinks.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   desk.as_context() with four drafts, as the box's desk held them on
#   2026-11-28 (three of the tripwire post, one of them half rewritten after
#   it went out, and one of a different post). Argument 2:
#     sent       the post was sent: the three tripwire drafts are each marked
#                SENT with the post's action and cut to 240 characters; the
#                other draft is not marked and is shown whole
#     unsent     the post was only proposed (blocked), never sent: none is
#                marked
#
# WHY IT EXISTS
#   The tripwire post went out on 11-27 at 19:52 (action 4632). Four drafts
#   of it stayed on the desk, 9,268 characters in every prompt, and at 01:01
#   riffle updated one, writing "The operator turned down the post earlier",
#   which nothing had told it (batch 29).
#
# HOW IT WORKS
#   A State with the desk and an actions row for the post; as_context() is
#   read back.
#
# READING THE OUTPUT
#   `[case] <slot>: SENT (action N) / not marked | shown <chars> of <chars>`
#
# CHANGELOG
#   2026-11-28  Written with desk.sent_as (batch 29).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, re, tempfile
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import desk
from agent.state import State

TITLE = "Tripwire Conservation: Gate Order Suppression Analysis"
BODY = ("The tripwire’s conservation — the property that its hash equality check fires on every "
        "append — is not a structural invariant of the attestation set alone. It is suppressed by "
        "gate order with high probability, meaning the tripwire’s boolean output is often lost before "
        "it reaches the observer. This is not a failure of the tripwire’s logic, but a consequence of "
        "the system’s processing pipeline. My simulation models the tripwire as a check at a random "
        "position in a sequence of 10 gates, where each prior gate has a failure probability of 0.46. "
        "Over 1000 trials, the tripwire is suppressed in 76.7% of cases when it is not the first gate "
        "(767/1000). This rate depends on the assumed failure probability of prior gates.")
st = State(os.path.join(tempfile.mkdtemp(), "s.sqlite")); desk.ensure(st)
st.db.execute("INSERT INTO actions (cycle_id, created_at, kind, drive, payload, rationale, status)"
              " VALUES (1, '2026-11-27T19:52:00Z', 'post', 'make', ?, 'r', ?)",
              (json.dumps({"title": TITLE, "body": BODY}), "blocked" if mode == "unsent" else "executed"))
st.db.commit()
_half = BODY.split(". ")
REVISED = ". ".join(_half[:4]) + ". I have since re-run it with the failure rate drawn from the board's own logs, and the number moves with it; the position effect does not."
desk.put(st, "draft:tripwire_post_v3", "draft", f"Title: {TITLE} Body: {BODY}")
desk.put(st, "tripwire_post_final", "draft", f"Title: {TITLE} Body: {BODY} Sources below.")
desk.put(st, "draft:tripwire_post_final", "draft", f"Title: {TITLE} Body: {REVISED}")
desk.put(st, "draft:clock_bracket", "draft",
         "Title: What a third seat would show. Body: lucykimi's positive control sets a seat's clock "
         "deliberately wrong by two seconds before a bracket pass; if the midpoint moves by the "
         "injected offset, the instrument tracks seats linearly. I have not run it, and I will say "
         "what I see when I do.")
ctx = desk.as_context(st)
for r in desk.items(st):
    part = ctx.split(f"] {r['slot']}  (", 1)[1].split("\n--- [", 1)[0]
    m = re.search(r"SENT: this draft went out as your post \(action (\d+)", part)
    shown = len(part.split("\n", 2)[-1].split("\n[...")[0]) if m else len(r["body"])
    print(f"  [{mode:7}] {r['slot']:28} {'SENT (action ' + m.group(1) + ')' if m else 'not marked':18} | "
          f"shown {min(shown, len(r['body']))} of {len(r['body'])}")
print(f"  [{mode:7}] the desk in the prompt: {len(ctx)} characters")
