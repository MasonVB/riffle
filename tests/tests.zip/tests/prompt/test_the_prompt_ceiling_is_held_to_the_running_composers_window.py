# ==========================================================================
# The prompt ceiling is held to the context window the RUNNING composer
# reports, whatever max_prompt_chars says.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   A stand-in llama-server whose /props reports n_ctx 24,576 (the old
#   window), with max_prompt_chars at 105,000 and a prompt that wants more
#   than the old window holds. One real cycle.main(). Prints the ceiling the
#   cycle used (from its journal), whether the prompt sent stayed inside the
#   old window by gate 4's arithmetic, and whether the journal says why.
#
# WHY IT EXISTS
#   2026-11-15: the window went from 24,576 to 49,152 tokens and the ceiling
#   from 62,000 to 105,000 characters. Gate 4 checks the ceiling against the
#   composer's unit FILE; the composer keeps the window it started with until
#   it restarts. Raised in the wrong order, every prompt would overflow and
#   every cycle end `composer-failed`.
#
# HOW IT WORKS
#   The stand-in serves /props on a free local port; the composer's url in
#   the config points there; cortex.complete is replaced by a recorder.
#
# READING THE OUTPUT
#   `prompt sent N chars | ceiling used: 66560 | sent within the running
#   window: True | journal says why: True`. Without the clamp the same
#   prompt is sent at about 104,600 characters, past the old window.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON, and
#   PYTHONPATH=tests/lib for the safety net). The simplest way is
#   tests/run_all.sh, which runs everything on a temporary copy of the tree.
#
# CHANGELOG
#   2026-11-15  Written with the larger window.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, copy, tempfile, yaml, threading, re
repo = sys.argv[1]; sys.path.insert(0, repo)
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from agent import cycle, cortex, drives, project
from agent.state import State
me = json.load(open(os.environ["RIFFLE_ME_JSON"]))
class P(BaseHTTPRequestHandler):
    def do_GET(self):
        b = json.dumps({"default_generation_settings": {"n_ctx": 24576}}).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def log_message(self, *a): pass
srv = ThreadingHTTPServer(("127.0.0.1", 0), P)
threading.Thread(target=srv.serve_forever, daemon=True).start()
class Stub:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n):
        if n == "me": return lambda *a, **k: copy.deepcopy(me)
        if n == "ack": return lambda *a, **k: {"mode": "legacy"}
        return lambda *a, **k: {}
cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "make"
SEEN = {}
def complete(llm, system, user, schema=None, **k):
    if "Choose ONE action" in user:
        SEEN["n"] = len(system) + len(user)
    return json.dumps({"action": "noop", "payload": {"why": "nothing"}, "rationale": "nothing to do"}
                      if "Choose ONE action" in user else
                      ({"continuity": "c"} if "continuity" in (schema or {}).get("required", [])
                       else {"promote": [], "write": [], "drop": [], "note": ""}))
cortex.complete = complete
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
cfg["data_dir"] = d; cfg["cycle"]["max_prompt_chars"] = 105000
cfg["llm"]["composer"]["url"] = f"http://127.0.0.1:{srv.server_address[1]}"
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','T','Q?','active')")
st.db.commit()
pid = project.active(st)["id"]
LINE = "a long line of a thread that riffle read, to make the board wide enough to matter\n"
for i in range(6):
    project.record_read(st, pid, 1, 9000 + i, f"thread {i}", "bob", 30, 30, LINE * 120,
                        "".join(f"  [c{i}{j:03}] bob (1 votes): " + LINE for j in range(60)), "d")
st.note("last_fetch", json.dumps({"what": "post/1", "at": "2026-11-15T00:00:00Z", "body": LINE * 400}))
st.note("last_library_read", "https://en.wikipedia.org/wiki/X (fetched)\n\n" + LINE * 200)
st.note("last_build", json.dumps({"run_id": "c1", "entry": "solve.py", "at": "2026-11-15T00:00:00Z", "ok": False,
                                  "exit_code": 1, "stdout": LINE * 60, "stderr": LINE * 60, "files": ["solve.py"]}))
from agent import desk
desk.ensure(st) if hasattr(desk, "ensure") else None
for k in range(3):
    desk.put(st, f"draft:part{k}", "draft", LINE * 36) if hasattr(desk, "put") else None
for k in range(30):
    project.add_note(st, pid, 1, "observation", f"note {k}: " + LINE * 3, source=f"1f916:{9000 + k}")
sys.argv = ["cycle", "--config", cp, "--force"]
try: cycle.main()
except SystemExit: pass
j = [r[0] for r in st.db.execute("SELECT text FROM journal WHERE text LIKE '%running composer%'")]
used = int(re.search(r"holds (\d+)", j[0]).group(1)) if j else None
mt = int(cfg["llm"]["composer"].get("max_tokens", 1600))
print(f"  prompt sent {SEEN.get('n')} chars | ceiling used: {used} | sent within the running window: "
      f"{SEEN.get('n', 10 ** 9) / 3.25 + 96 + mt <= 24576} | journal says why: {bool(j)}")
srv.shutdown()
