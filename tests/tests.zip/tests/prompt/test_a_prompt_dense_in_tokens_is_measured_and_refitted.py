# ==========================================================================
# A prompt the character estimate says fits, but whose real token count
# would overflow the composer's window, is measured with the composer's own
# tokenizer and fitted again before it is sent.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   A stand-in llama-server holds a 17,000-token window, counts hex as one
#   token a character and other text at about four characters a token, and
#   refuses (HTTP 400, "exceeds the available context size") a prompt that
#   would not leave room for the reply. The thread riffle read last is
#   10,000 characters of hashes. Argument 2 picks the case:
#     measured    /tokenize answers: what the cycle measured, what it did,
#                 and how the cycle ended
#     no-measure  /tokenize is not there: the composer refuses the first
#                 prompt, and the cycle fits again and asks once more
#
# WHY IT EXISTS
#   Audit F19 (2026-11-10): the prompt was fitted in characters at 3.25 a
#   token. Hashes, base64 signatures, emoji and CJK run at one to two, so
#   such a board overflows with the character count unchanged; the cycle
#   ended composer-failed and the next built the same prompt.
#
# HOW IT WORKS
#   One real cycle.main() with the real cortex.complete, against a stand-in
#   llama-server on loopback (http.server in a thread) and a stub registry.
#
# READING THE OUTPUT
#   `[case] ...`: the journal lines about the window, and the outcome.
#
# RUNNING IT ON ITS OWN
#   python3 tests/prompt/test_a_prompt_dense_in_tokens_is_measured_and_refitted.py . measured
#
# CHANGELOG
#   2026-11-17  Written for audit F19 (batch 9).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, re, copy, json, sqlite3, tempfile, threading, http.server, yaml
repo, mode = sys.argv[1], sys.argv[2]; sys.path.insert(0, repo)
from agent import cycle, cortex, drives, project
from agent.state import State

NCTX, CALLS = 17000, []


def tokens(text):
    hexchars = sum(len(m) for m in re.findall(r"[0-9a-f]{16,}", text))
    return hexchars + (len(text) - hexchars) // 4


class Llama(http.server.BaseHTTPRequestHandler):
    def _send(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

    def do_GET(self):
        if self.path.startswith("/props"):
            return self._send(200, {"default_generation_settings": {"n_ctx": NCTX}})
        if self.path.startswith("/health"):
            return self._send(200, {"status": "ok"})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
        if self.path.startswith("/tokenize"):
            if mode == "no-measure":
                return self._send(404, {"error": "not found"})
            return self._send(200, {"tokens": [0] * tokens(body.get("content", ""))})
        msgs = body.get("messages") or []
        text = "\n".join(m.get("content") or "" for m in msgs)
        need = tokens(text) + 8 * len(msgs) + int(body.get("max_tokens") or 0)
        main = "Choose ONE action" in text
        CALLS.append((main, need))
        if need > NCTX:
            return self._send(400, {"error": {"code": 400, "type": "exceed_context_size_error",
                                              "message": "the request exceeds the available context size, try increasing it"}})
        if main:
            out = {"action": "noop", "payload": {"why": "nothing"}, "rationale": "nothing to do"}
        elif "continuity" in json.dumps(body.get("response_format") or {}):
            out = {"continuity": "c"}
        else:
            out = {"promote": [], "write": [], "drop": [], "note": ""}
        self._send(200, {"choices": [{"message": {"content": json.dumps(out)}, "finish_reason": "stop"}],
                         "usage": {}, "timings": {}})

    def log_message(self, *a):
        pass


srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Llama)
threading.Thread(target=srv.serve_forever, daemon=True).start()
URL = f"http://127.0.0.1:{srv.server_address[1]}"

me = json.load(open(os.environ["RIFFLE_ME_JSON"]))


class Stub:
    def __init__(self, *a, **k): pass

    def __getattr__(self, n):
        return (lambda *a, **k: copy.deepcopy(me)) if n == "me" else (lambda *a, **k: {"mode": "legacy"} if n == "ack" else {})


cycle.Reader = cycle.Writer = Stub
cycle.do_witness = lambda *a, **k: None
cycle.walk_changes = lambda *a, **k: {'posts': [], 'comments': [], 'nulls': [], 'saturated': False, 'window_age_ms': None}
drives.pick_drive = lambda *a, **k: "understand"
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml"))); cfg["data_dir"] = d
cfg.setdefault("library", {})["root"] = os.path.join(d, "library")
for k in ("composer", "triage"):
    if k in cfg["llm"]:
        cfg["llm"][k]["url"] = URL
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
cp = os.path.join(d, "c.yaml"); yaml.safe_dump(cfg, open(cp, "w"))
st = State(os.path.join(d, "state.sqlite")); project.ensure(st)
st.db.execute("INSERT INTO projects (opened_at,title,question,status) VALUES ('2026-10-23T00:00:00Z','Seals','Do they hold?','active')")
st.db.commit()
HASHES = "\n".join(os.urandom(32).hex() for i in range(160))
project.record_read(st, 1, 0, 4321, "Every seal from last week", "coppice", 0, 0, HASHES, "", "d1")
LOGS = []
cycle_log = cycle.__dict__.get("_log")
sys.argv = ["cycle", "--config", cp, "--force"]
try:
    cycle.main()
except SystemExit:
    pass
db = sqlite3.connect(os.path.join(d, "state.sqlite")); db.row_factory = sqlite3.Row
c = db.execute("SELECT outcome FROM cycles ORDER BY id DESC LIMIT 1").fetchone()
lines = [r["text"] for r in db.execute("SELECT text FROM journal ORDER BY id")
         if "window" in r["text"] and ("tokens and the window" in r["text"] or "longer than its window" in r["text"])]
mains = [n for m, n in CALLS if m]
print(f"  [{mode:10}] the composer was asked {len(mains)} time(s); tokens each would take: "
      f"{['over' if n > NCTX else 'fits' for n in mains]}")
for l in lines:
    print(f"  [{mode:10}] journal: {re.sub(r'[0-9]+', 'N', l)[:150]}")
print(f"  [{mode:10}] the cycle ended: {c['outcome']!r}")
