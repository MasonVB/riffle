# ==========================================================================
# A composer call gets the time its size needs, not a flat 1,800 s; a
# cycle's calls share one budget; a call is not started that the budget
# cannot finish; and a timeout says how long it had and why.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   1. cortex.call_timeout for the prompt of the cycle that died on
#      2026-11-19 (63,678 characters, a 4,000-token ceiling) gives more than
#      that call needed at the composer's measured speeds (19.6 tokens/s
#      read, nothing cached; 3.1 written, its own log), where 1,800 did not;
#      for the worst prompt the deploy allows (105,000 characters) it gives
#      the cap; a short call gets the floor.
#   2. Against a stand-in llama-server: a call takes its wall time out of the
#      budget; with less than the floor left, the next call is refused
#      before the server is asked; an explicit timeout (the triage calls)
#      leaves the budget alone.
#   3. A call that runs out says how long it ran, what it had, and from what.
#
# WHY IT EXISTS
#   2026-11-21: "composer failed: timed out" at 02:53Z, the second in three
#   days. On 11-19 the composer was still writing, 3,570 tokens of 4,000 at
#   3.1 tokens/s, when 1,800 s ran out, and the cycle's work was lost.
#
# HOW IT WORKS
#   call_timeout() on built bodies; complete() against an http.server thread
#   that answers after a delay the test sets, with CALL_FLOOR and CALL_CAP
#   shrunk to seconds for parts 2 and 3.
#
# READING THE OUTPUT
#   `[size] ...`, `[budget] ...`, `[timeout] ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/prompt/test_a_composer_call_gets_the_time_its_size_needs.py .
#
# CHANGELOG
#   2026-11-21  Written with cortex.call_timeout and set_budget (batch 19).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, json, re, threading, time, http.server
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cortex

# 1. sizes
def body(chars, max_tokens):
    return {"messages": [{"role": "system", "content": "x" * chars}], "max_tokens": max_tokens}
t, why = cortex.call_timeout({}, body(63678, 4000))
needed = (63678 / 3.62) / 19.6 + 4000 / 3.1
print(f"  [size] the 11-19 cycle's call: {t} s ({why}); it needed about {needed:.0f} s;"
      f" 1800 held it: {1800 >= needed}; this holds it: {t >= needed}")
t, why = cortex.call_timeout({}, body(105000, 4000))
worst = (105000 / 3.62) / 19.6 + 4000 / 3.2
print(f"  [size] the worst prompt the deploy allows: {t} s, the cap; it needs about {worst:.0f} s; holds: {t >= worst}")
t, why = cortex.call_timeout({}, body(1000, 100))
print(f"  [size] a short call: {t} s, the floor")
t, why = cortex.call_timeout({"read_tok_s": 40, "write_tok_s": 8}, body(63678, 4000))
print(f"  [size] the same call, with faster speeds set in config.yaml: {t} s")

# 2 and 3: a stand-in server
DELAY = {"s": 0.0}; ASKED = []
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        ASKED.append(self.path); self.rfile.read(int(self.headers["Content-Length"]))
        time.sleep(DELAY["s"])
        out = json.dumps({"choices": [{"message": {"content": "{}"}, "finish_reason": "stop"}],
                          "timings": {}, "usage": {}}).encode()
        try:
            self.send_response(200); self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)
        except OSError:
            pass
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
llm = {"url": f"http://127.0.0.1:{srv.server_address[1]}", "max_tokens": 50}
cortex.CALL_FLOOR, cortex.CALL_CAP = 2, 3

cortex.set_budget(4)
DELAY["s"] = 1.2
cortex.complete(llm, "s", "u")
left = cortex._BUDGET["left"]
print(f"  [budget] after a 1.2 s call, of 4 s: {left:.0f} s left (took its wall time: {2.5 < left < 2.9})")
cortex.complete(llm, "s", "u", timeout=30)
print(f"  [budget] an explicit-timeout call leaves it alone: {abs(cortex._BUDGET['left'] - left) < 0.01}")
cortex.complete(llm, "s", "u")
n = len(ASKED)
try:
    cortex.complete(llm, "s", "u")
    print("  [budget] a call with under the floor left: started (wrong)")
except cortex.OutOfTime as e:
    print(f"  [budget] a call with under the floor left: refused, server not asked: {len(ASKED) == n}")
    print(f"  [budget]   {re.sub(r'[0-9.]+ s of', '<n> s of', str(e))}")

cortex.set_budget(None)
DELAY["s"] = 5
try:
    cortex.complete(llm, "s", "u")
    print("  [timeout] no timeout (wrong)")
except TimeoutError as e:
    print(f"  [timeout] {e}")
try:
    cortex.complete(llm, "s", "u", timeout=1)
except TimeoutError as e:
    print(f"  [timeout] {e}")
srv.shutdown()
