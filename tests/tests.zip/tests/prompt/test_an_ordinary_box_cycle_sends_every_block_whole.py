# ==========================================================================
# At the shipped ceiling, a heavy ordinary cycle on the box sends every
# block whole; with every block at its largest at once, only board blocks
# are trimmed and riffle's own section is untouched.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   The real cycle._fit, the system prompt measured with the continuity
#   note at its cap, the room worked out as the cycle works it out from
#   config.example.yaml's max_prompt_chars. Two prompts made of blocks with
#   real headers at the largest sizes the box measured (journal "blocks
#   before fitting", 92 cycles to 2026-11-06), plus the desk as it stood on
#   2026-11-12 (6,207) and six operator answers (~620 each):
#     heavy      every block seen in 80 or more of the 92 cycles, plus a new
#                inbox, the desk and the answers, each at its maximum
#     all        every block the box ever sent, each at its maximum, at once
#                (wanted ~78,000; no real cycle came near: the most was 51,762)
#   For each: what was wanted, what was sent, and each block cut.
#
# WHY IT EXISTS
#   The operator, 2026-11-15, with the box at 64 GB: "relax the prompt
#   trimming and verify none of the prompts get cut off within reason".
#   Audit F37 and F12: every block was held to a cap set for an
#   18,000-character room, every cycle, whether or not there was room; the
#   desk (5 drafts, 6,207 characters) was shown at 1,200.
#
# READING THE OUTPUT
#   `[heavy] ... cut: none`; `[all] ... own section cut: none | board blocks
#   cut: N`. A block cut on the heavy line, or anything of riffle's own cut
#   on either, means a cap or the ceiling moved below what the box sends.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with PYTHONPATH=tests/lib for the safety net. The
#   simplest way is tests/run_all.sh.
#
# CHANGELOG
#   2026-11-15  Written with the larger window (49,152) and ceiling (105,000).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, yaml
repo = sys.argv[1]; sys.path.insert(0, repo)
from agent import cycle, cortex
cfg = yaml.safe_load(open(os.path.join(repo, "config.example.yaml")))
ceiling = int(cfg["cycle"]["max_prompt_chars"])
sysc = len(cortex.stable_prefix(cfg, cortex.render_continuity("x" * cortex.CONTINUITY_MAX,
                                                              "2026-01-01T00:00:00Z")))
LINE = "a line of the block, as long as an ordinary line of riffle's prompt runs\n"
def blk(head, n):
    return (head + "\n" + LINE * (n // len(LINE) + 1))[:n]
BOX = [("WHAT ACTUALLY MOVED since", 7335, 1), ("COMMENTS YOU COULD ANSWER", 5311, 1),
       ("WHAT YOU READ LAST CYCLE — /post/1", 5132, 1), ("POSTING IS CLOSED for", 5766, 1),
       ("THE THREAD YOU ASKED TO READ AGAIN", 4963, 0), ("THE THREAD YOU READ MOST RECENTLY", 4888, 1),
       ("OPEN LISTINGS", 4590, 0), ("YOUR LAST BUILD", 6027, 1), ("INBOX — NEW, newest first", 3077, 1),
       ("THE DOCUMENT YOU OPENED", 2743, 1), ("WHAT YOU HAVE ALREADY SAID", 2042, 1),
       ("WHAT CAN STOP AN ACTION", 1759, 1), ("YOUR GOALS RIGHT NOW", 1511, 1),
       ("INBOX — OLDER, from before", 1289, 0), ("THINGS YOU NOTED FROM THE BOARD", 1088, 1),
       ("QUESTIONS YOU HAVE ASKED AND HE HAS NOT ANSWERED YET", 664, 1),
       ("THE FIELDS THE API ACTUALLY RETURNS", 649, 1), ("WHAT YOU REMEMBER:", 954, 1),
       ("THREADS YOU HAVE READ ON THIS PROJECT", 1222, 1), ("YOUR LIBRARY (183 documents)", 357, 1),
       ("THE NULLS IN WHAT ACTUALLY MOVED", 317, 1), ("YOUR DESK", 6207, 1),
       ("ANSWERS FROM YOUR OPERATOR", 3720, 1), ("ALREADY DONE", 900, 1),
       ("FRONT PAGE — an index", 5800, 1)]
room = ceiling - sysc - 4500 - cycle._WRAP_CHARS     # the tail at its worst, as gate 4
for label, rows in (("heavy", [b for b in BOX if b[2]]), ("all", BOX)):
    parts = [blk(h, n) for h, n, _ in rows]
    out = cycle._fit(parts, room, None, big_build=True)
    want = sum(len(p) for p in parts) + 2 * len(parts)
    sent = sum(len(p) for p in out) + 2 * len(out)
    own_cut = [h for (h, n, _), o in zip(rows, out) if len(o) < n and cycle._is_own(o)]
    brd_cut = [h for (h, n, _), o in zip(rows, out) if len(o) < n and not cycle._is_own(o)]
    if label == "heavy":
        print(f"  [heavy] ceiling {ceiling}, room {room}: wanted {want}, sent {sent} | cut: "
              f"{', '.join(own_cut + brd_cut) or 'none'}")
    else:
        print(f"  [all] wanted {want}, sent {sent} | own section cut: {', '.join(own_cut) or 'none'} | "
              f"board blocks cut: {len(brd_cut)}")
