#!/bin/bash
# ==========================================================================
# The signer refuses a payout whose preimage carries an address other than
# the one in its config, and refuses `custom` signing to riffle's accounts
# even when they reach it.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Four calls to the tree's own bin/riffle-sign, sandboxed:
#     payout, the registry's preimage naming the configured address: signed
#     payout, the preimage naming another address: refused
#     custom, as if run by riffle through sudo (SUDO_USER=riffle): refused
#     custom, as if run by riffle-build: refused
#   Each prints its first 120 characters.
#
# WHY IT EXISTS
#   Audit 2026-11-14, section 7.1: with the address comparison switched
#   off, or riffle's accounts let into `custom`, every test still passed. A
#   binding to any address would be signed; arbitrary bytes could be signed
#   by the agent if the sudoers rule were ever loosened (the sudoers rule
#   is the first line; this is the second).
#
# HOW IT WORKS
#   tests/lib/sandboxed_riffle_sign.py: the throwaway key, a payout.conf
#   from the environment, and the registry's own message builders for the
#   preimage (RS_REG_ADDR sets the address the "registry" puts in it).
#   Without the builders the payout lines print SKIPPED.
#
# READING THE OUTPUT
#   `  [case] <the signer's first 120 characters>`.
#
# RUNNING IT ON ITS OWN
#   Through tests/run_all.sh, with RIFFLE_REGISTRY_MESSAGES set.
#
# CHANGELOG
#   2026-11-18  Written for the audit's section 7.1 (batch 11).
# ==========================================================================
case "$(id -un)" in riffle|riffle-signer|riffle-build)
  echo "refused: riffle's tests are a record, never run by riffle itself ($(id -un))" >&2; exit 2;; esac
[ -n "${RIFFLE_TMP:-}" ] && [ -n "${RIFFLE_TESTS:-}" ] && [ -n "${RIFFLE_TREE:-}" ] || {
  echo "refused: run this through tests/run_all.sh, which sets up its scratch paths and stand-ins" >&2; exit 2; }
S="$RIFFLE_TESTS/lib/sandboxed_riffle_sign.py"
line() { printf '  [%-16s] %s\n' "$1" "$(head -c 120 | tr '\n' ' ')"; }
RS_CEIL=none RS_PRICE=1000000 python3 "$S" payout --row=listing-16 --expiry=4102444800 2>&1 | line "own address"
RS_CEIL=none RS_PRICE=1000000 RS_REG_ADDR=0x000000000000000000000000000000000000dead \
  python3 "$S" payout --row=listing-16 --expiry=4102444800 2>&1 | line "another address"
printf 'bytes riffle wants signed' | SUDO_USER=riffle python3 "$S" custom --approved 2>&1 | line "custom as riffle"
printf 'bytes riffle wants signed' | SUDO_USER=riffle-build python3 "$S" custom --approved 2>&1 | line "custom as build"
