# ==========================================================================
# riffle-sign loads keyutil.py and ed25519_pure.py only from a directory
# nobody else can write, and refuses to sign otherwise.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks the case: `good` (both libraries in a safe
#   directory: it signs, loading them from there), `none` and `no_pure`
#   (missing: refused), `group_writable` (a library writable by its
#   group: refused) and `dir_writable` (a world-writable directory:
#   refused).
#
# WHY IT EXISTS
#   The signer holds riffle's key. If it imported its signing code from
#   a directory another user could write, that user could replace the
#   code and sign anything.
#
# HOW IT WORKS
#   Loads the tree's bin/riffle-sign as a module, points its library
#   directories at a temporary one set up for the case, and signs
#   'hello' with a fixed dummy key. It never touches a real key.
#
# READING THE OUTPUT
#   `[case] signed 64 bytes; ... from the checked dir: True` or `[case]
#   refused (exit 1): ...`.
#
# RUNNING IT ON ITS OWN
#   python3 tests/signing_and_payouts/test_the_signer_loads_its_key_libr
#   aries_only_from_a_safe_directory.py bin/riffle-sign good
#
# CHANGELOG
#   2026-10-24  Last changed in the sandbox on this date, before the round-1
#               audit of 2026-10-27; written during the earlier review that
#               preceded it (its exact start date was not recorded).
#   2026-11-05  Moved into tests/signing_and_payouts; the tree's path comes
#               from RIFFLE_TREE.
#   2026-11-18  As an ordinary user it prints SKIPPED and says why (audit
#               7.2 item 8); its scratch path is replaced before the line is
#               cut, so the path's length cannot change the record.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, tempfile, shutil, importlib.machinery, importlib.util, io, contextlib
src, case = sys.argv[1], sys.argv[2]
repo = __import__("os").environ.get("RIFFLE_TREE", ".")
ld = importlib.machinery.SourceFileLoader("rs", src)
spec = importlib.util.spec_from_loader("rs", ld); rs = importlib.util.module_from_spec(spec); ld.exec_module(rs)
rs.log = lambda *a, **k: None
# ROOT ONLY (audit 2026-11-14, 7.2 item 8). The signer loads its libraries
# only from a root-owned directory, which nobody else can make, so as an
# ordinary user every case refused for the directory's owner and differed.
# It says so instead.
if os.geteuid() != 0:
    print(f"  [{case}] SKIPPED: needs root, to make the root-owned directory the signer insists on")
    sys.exit(0)
d = tempfile.mkdtemp(); os.chmod(d, 0o755)
if case != "none":
    for f in ("keyutil.py", "ed25519_pure.py"):
        if case == "no_pure" and f == "ed25519_pure.py": continue
        shutil.copy(os.path.join(repo, f), d); os.chmod(os.path.join(d, f), 0o644)
    if case == "group_writable": os.chmod(os.path.join(d, "ed25519_pure.py"), 0o664)
    if case == "dir_writable": os.chmod(d, 0o777)
rs._KEYUTIL_DIRS = (d,)
err = io.StringIO()
try:
    with contextlib.redirect_stderr(err):
        sys.modules["cryptography"] = None          # force keyutil's lazy ed25519_pure import
        sig = rs.sign_bytes(b"\x01" * 32, b"hello")
    import ed25519_pure
    print(f"  [{case}] signed {len(sig)} bytes; ed25519_pure loaded from the checked dir: {os.path.dirname(ed25519_pure.__file__) == d}")
except SystemExit as e:
    # The scratch path out first, then the cut, so the length of the path
    # (longer since run_all.sh's TMPDIR) cannot move where the line is cut.
    print(f"  [{case}] refused (exit {e.code}): {err.getvalue().strip().replace(d, 'TMP')[:110]}")
except Exception as e:
    print(f"  [{case}] {type(e).__name__}: {str(e).replace(d, 'TMP')[:100]} | stderr: {err.getvalue().strip().replace(d, 'TMP')[:90]}")
