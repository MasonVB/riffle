# ==========================================================================
# Every refusal in bin/riffle-sign that no test reached refuses, logs the
# refusal, and signs nothing.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   Argument 2 picks one case; each runs the tree's bin/riffle-sign main()
#   once, with its own throwaway key, payout.conf and log, and prints the exit
#   code, the refusal, whether a REFUSED line was logged, and whether anything
#   was signed (a SIGNED line, or a signature on stdout).
#   payout, the registry's answer stubbed:
#     noconf        no payout.conf at all
#     confmissing   payout.conf without allowed_rows
#     badaddr       address=0x1234
#     zeroaddr      the shipped all-zero address
#     askedpast     an expiry already past, asked for: refused before the
#                   registry is asked
#     askednan      --expiry soon
#     nopre         the registry answers with no preimage
#     shortpre      a preimage with five fields
#     laterexpiry   the preimage carries a later expiry than asked for (new
#                   2026-11-27: was signed as it came)
#     badceiling    max_amount_atomic=lots
#     zeroamount    the preimage's amount is 0
#     http503       the registry answers HTTP 503
#     unreachable   the registry cannot be reached
#     payoutok      everything right: signed, for contrast
#   payout-wallet: walletnan (--expiry soon), walletnoaddr (no address),
#     walletother (the registry's preimage names another address)
#   seal: badhash, badlabel, nohandle (payout.conf without handle=)
#   attest: badsubject, emptyclaim, longclaim (501 characters),
#     badevidence (not JSON), manyevidence (11 strings)
#   custom (run as root, not through riffle's sudo): noapproved, emptystdin,
#     bigstdin (4,097 bytes), notutf8, protocol (a seal preimage)
#   keys: noseed, garbageseed (10 bytes), shortseed (16 bytes in base64url),
#     b64seed and hexseed (a key kept as text still loads, for contrast),
#     lockedseed and lockedconf (the key, or payout.conf, unreadable),
#     adoptexists, adoptunreadable, adoptnotseed, adoptwrongkey,
#     genkeyexists, badthumb
#   log: nolog, a seal when the signing log cannot be written
#
# WHY IT EXISTS
#   The coverage sweep of bin/ (2026-11-27, batch 27): of 49 lines in
#   riffle-sign that refuse, 40 were reached by no test. The signer holds
#   the citizen key and is the only thing between riffle and a payout
#   binding. Sweeping it also found the payout expiry was never compared
#   with the one asked for (laterexpiry), and that a garbage key file was
#   reported as "the key is 0 bytes" (garbageseed).
#   Two refusals are left unreached because nothing can reach them: jcs()
#   refuses a big integer or a non-JSON value, and every value attest hands
#   it is a string, a list of strings, or null.
#
# HOW IT WORKS
#   bin/riffle-sign loaded as a module, as tests/lib/sandboxed_riffle_sign.py
#   does, with SEED_PATH, CONF_PATH and LOG_PATH in a fresh directory and
#   its key libraries from $RIFFLE_SIGNER_SANDBOX. fetch() or urlopen is
#   replaced where the case needs the registry. Nothing here reaches the
#   network or a real key.
#
# READING THE OUTPUT
#   `[case] exit <code> | <first words of the refusal> | REFUSED logged: yes/no | signed: yes/no`
#
# CHANGELOG
#   2026-11-27  Written from the coverage sweep of bin/ (batch 27).
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, io, json, time, base64, tempfile, contextlib
import importlib.machinery, importlib.util, urllib.error
repo, mode = sys.argv[1], sys.argv[2]
SANDBOX = os.environ["RIFFLE_SIGNER_SANDBOX"]
ld = importlib.machinery.SourceFileLoader("rs", os.path.join(repo, "bin", "riffle-sign"))
spec = importlib.util.spec_from_loader("rs", ld)
rs = importlib.util.module_from_spec(spec); ld.exec_module(rs)

d = tempfile.mkdtemp()
rs.SEED_PATH = os.path.join(d, "seed")
rs.CONF_PATH = os.path.join(d, "payout.conf")
rs.LOG_PATH = os.path.join(d, "signatures.log")
rs._KEYUTIL_DIRS = (os.path.join(SANDBOX, "lib"),)
if os.geteuid() != 0:
    def _yours_only(path, _uid=os.geteuid(), _die=rs.die):
        st = os.stat(path)
        if st.st_uid != _uid or (st.st_mode & 0o022):
            _die(f"{path} is not owned by the test's user and unwritable by others")
    rs._root_only = _yours_only
os.environ.pop("SUDO_USER", None)

ADDR = "0x0c19bf942294235e53b35af0198f1b629c5f7080"
conf = {"handle": "riffle", "address": ADDR, "allowed_rows": "listing-*,listing-*-verifier",
        "max_amount_atomic": "none"}
SEED = os.urandom(32)
seed_bytes = SEED
EXP = int(time.time()) + 29 * 86400
args = ["payout", "--row=listing-16", f"--expiry={EXP}"]
answer = {"preimage": f"1f916.payout.v1:riffle:listing-16:1000000:8453:{rs.USDC}:{ADDR}:{EXP}"}
stdin = b""
fetch_raises = None

if mode == "noconf": conf = None
elif mode == "confmissing": del conf["allowed_rows"]
elif mode == "badaddr": conf["address"] = "0x1234"
elif mode == "zeroaddr": conf["address"] = "0x" + "0" * 40
elif mode == "askedpast": args[2] = f"--expiry={int(time.time()) - 60}"
elif mode == "askednan": args[2] = "--expiry=soon"
elif mode == "nopre": answer = {}
elif mode == "shortpre": answer = {"preimage": "1f916.payout.v1:riffle:listing-16:1000000:8453"}
elif mode == "laterexpiry": answer["preimage"] = answer["preimage"][:-len(str(EXP))] + str(EXP + 100 * 365 * 86400)
elif mode == "badceiling": conf["max_amount_atomic"] = "lots"
elif mode == "zeroamount": answer["preimage"] = answer["preimage"].replace(":1000000:", ":0:")
elif mode == "http503": fetch_raises = urllib.error.HTTPError("https://1f916.ai/x", 503, "busy", {}, None)
elif mode == "unreachable": fetch_raises = urllib.error.URLError("no route to host")
elif mode.startswith("wallet"):
    args = ["payout-wallet", f"--expiry={'soon' if mode == 'walletnan' else EXP}"]
    if mode == "walletnoaddr": del conf["address"]
    other = "0x" + "1" * 40 if mode == "walletother" else ADDR
    answer = {"preimage": f"1f916.payout-wallet.v1:riffle:8453:{other}:{EXP}"}
elif mode in ("badhash", "badlabel", "nohandle", "nolog"):
    args = ["seal", "--hash=" + ("ABC" if mode == "badhash" else "a" * 64),
            "--label=" + ("Bad Label!" if mode == "badlabel" else "memory.v1")]
    if mode == "nohandle": del conf["handle"]
    if mode == "nolog": rs.LOG_PATH = os.path.join(d, "no-such-dir", "signatures.log")
elif mode in ("badsubject", "emptyclaim", "longclaim", "badevidence", "manyevidence"):
    args = ["attest", "--subject=" + ("not a handle!" if mode == "badsubject" else "silt"),
            "--cls=replicated-total",
            "--claim=" + {"emptyclaim": "   ", "longclaim": "x" * 501}.get(mode, "replicated the census"),
            "--evidence=" + {"badevidence": "[not json", "manyevidence": json.dumps(["e"] * 11)}.get(mode, "[]")]
elif mode in ("noapproved", "emptystdin", "bigstdin", "notutf8", "protocol"):
    args = ["custom"] + ([] if mode == "noapproved" else ["--approved"])
    stdin = {"noapproved": b"hello", "emptystdin": b"", "bigstdin": b"x" * 4097,
             "notutf8": b"\xff\xfe\x00bytes", "protocol": b"1f916.seal.v1:riffle:x:" + b"a" * 64}[mode]
elif mode in ("noseed", "garbageseed", "shortseed"):
    args = ["pubkey"]
    seed_bytes = {"noseed": None, "garbageseed": b"\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a",
                  "shortseed": base64.urlsafe_b64encode(os.urandom(16)).rstrip(b"=")}[mode]
elif mode in ("lockedseed", "lockedconf"):
    # A file the signer may not read. Root reads anything, so the refusal is
    # made by the module's own open(), which raises as the kernel would.
    args = ["pubkey"] if mode == "lockedseed" else ["payout", "--row=listing-16", f"--expiry={EXP}"]
    _locked = rs.SEED_PATH if mode == "lockedseed" else rs.CONF_PATH
    def _open(path, *a, _real=open, **k):
        if path == _locked:
            raise PermissionError(13, "Permission denied", path)
        return _real(path, *a, **k)
    rs.open = _open
elif mode in ("b64seed", "hexseed"):
    # The text forms a key is kept in still load: base64url with a newline
    # (validate=True must not refuse it) and join.py's 64 hex characters.
    args = ["pubkey"]
    seed_bytes = (base64.urlsafe_b64encode(SEED).rstrip(b"=") + b"\n" if mode == "b64seed"
                  else SEED.hex().encode() + b"\n")
elif mode.startswith("adopt"):
    src = os.path.join(d, "old.seed")
    if mode != "adoptunreadable":
        open(src, "wb").write(b"not a seed at all" if mode == "adoptnotseed" else os.urandom(32))
    args = ["adopt", f"--from={src}"] + (["--expect=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"]
                                         if mode == "adoptwrongkey" else [])
    if mode != "adoptexists":
        seed_bytes = None
elif mode == "genkeyexists": args = ["genkey"]
elif mode == "badthumb": args = ["keyrevoke", "--thumbprint=has spaces/and slashes"]

if conf is not None:
    open(rs.CONF_PATH, "w").write("".join(f"{k}={v}\n" for k, v in conf.items()))
if seed_bytes is not None:
    open(rs.SEED_PATH, "wb").write(seed_bytes)
ASKED = []
def fetch(url):
    ASKED.append(url)
    return answer
if fetch_raises is not None:
    def urlopen(*a, **k):
        ASKED.append(a[0].full_url); raise fetch_raises
    rs.urllib.request.urlopen = urlopen
else:
    rs.fetch = fetch

out, err = io.StringIO(), io.StringIO()
class In:
    buffer = io.BytesIO(stdin)
sys.stdin = In()
sys.argv = ["riffle-sign"] + args
code = 0
with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
    try:
        rs.main()
    except SystemExit as e:
        code = e.code if isinstance(e.code, int) else 1
logged = open(rs.LOG_PATH).read() if os.path.exists(rs.LOG_PATH) else ""
events = [json.loads(l)["event"] for l in logged.splitlines() if l.strip()]
import re
said = err.getvalue().strip().replace("riffle-sign: ", "").replace(d, "<dir>")
said = re.sub(r"https://\S+", "<url>", said)            # the query carries the expiry
said = re.sub(r"\b\d{9,}\b", "<time>", said)           # unix times, which change each run
said = re.sub(r"\b[A-Za-z0-9_-]{43}\b", "<key>", said)  # a random key's public half
signed = "SIGNED" in events or '"signature"' in out.getvalue() or "citizen_signature" in out.getvalue()
if mode in ("b64seed", "hexseed"):
    said = "the public key of the seed written: " + str(out.getvalue().strip() == rs.b64url(rs.public_key(SEED)))
print(f"  [{mode:15}] exit {code} | {' '.join(said.split())[:78]!r} | "
      f"REFUSED logged: {'yes' if 'REFUSED' in events else 'no'} | signed: {'yes' if signed else 'no'}"
      + (f" | registry asked: {'yes' if ASKED else 'no'}" if args[0].startswith("payout") else ""))
