# ==========================================================================
# A seal or attestation you approve on the dashboard is NOT sent by the
# dashboard: it waits for the next cycle, which can reach the signer, and
# the cycle sends it. If it still goes out unsigned, that is logged as a
# warning and reported in chat. A row the cycle left `approved` by itself
# is never sent again. And riffle's situation text describes signing
# correctly.
# ==========================================================================
#
# WHAT THIS TEST PROVES
#   1. Approving a queued seal through the dashboard's decide(): whether the
#      dashboard sent anything, and the row's status and mark afterwards.
#   2. The cycle's sweep (cycle._send_approved_signed): whether it sent the
#      seal, the row's status, and, with the send answered as unsigned, a
#      journal warning and a chat report.
#   3. A seal left `approved` WITHOUT the mark (how the cycle's own auto
#      path leaves one when it dies mid-send) is not sent by the sweep.
#   4. The situation text no longer says `sign` makes seals.
#
# WHY IT EXISTS
#   U6 (audit round 2): riffle was told `sign` does seals and attestations
#   (they are signed automatically when sent; `sign` binds payouts), and an
#   unsigned send was recorded only in the action's stored response.
#   Audit 2026-11-10, F8: approved on the dashboard, a seal or attestation
#   was sent BY the dashboard, whose unit has NoNewPrivileges=true and so
#   cannot run the signer: every approved one went out unsigned, while one
#   riffle sent by itself was signed. The operator decided (2026-11-14) that
#   the next cycle should send them.
#
# HOW IT WORKS
#   The dashboard's Handler is made without a server; its send and the
#   cycle's send are each replaced by a recorder answering as unsigned.
#
# READING THE OUTPUT
#   `dashboard sent: nothing | status 'approved', send by the cycle: True`;
#   `cycle sent: seal | status 'executed' | journal warning True, chat
#   report True`; `an approved row without the mark was sent: False`;
#   `situation still says sign does seals: False`.
#
# RUNNING IT ON ITS OWN
#   From the tree's root, with the variables tests/run_all.sh sets
#   (RIFFLE_TREE, RIFFLE_TESTS, RIFFLE_TMP, RIFFLE_ME_JSON,
#   RIFFLE_SIGNER_SANDBOX, and PYTHONPATH=tests/lib for the safety net).
#   The simplest way is tests/run_all.sh, which runs everything on a
#   temporary copy of the tree.
#
# CHANGELOG
#   2026-11-04  Written in the sandbox (tu6.py) for U6.
#   2026-11-05  Moved into tests/signing_and_payouts.
#   2026-11-14  Rewritten for F8. It approved a seal on the dashboard and
#               checked that the unsigned send from there was reported; the
#               dashboard no longer sends seals, so it now checks that the
#               dashboard hands the seal to the cycle, that the cycle sends
#               it and still reports an unsigned send, and that a ghost row
#               is not sent twice.
# ==========================================================================
# --- the safety net, however this file is started (tests/lib/riffle_test_safety_net.py) ---
__import__("sys").path.insert(0, __import__("os").path.join(__import__("os").path.dirname(
    __import__("os").path.abspath(__file__)), "..", "lib"))
__import__("riffle_test_safety_net")
# -----------------------------------------------------------------------------------
import sys, os, json, tempfile, time, yaml; sys.path.insert(0, sys.argv[1])
from agent import dash, cycle
from agent.state import State, utcnow
d = tempfile.mkdtemp()
cfg = yaml.safe_load(open(os.path.join(sys.argv[1], "config.example.yaml"))); cfg["data_dir"] = d
open(os.path.join(d, f"{cfg['handle']}.secret"), "w").write("x")
st = State(os.path.join(d, "s.sqlite"))
DASH_SENT, CYCLE_SENT = [], []
dash.execute = lambda w, k, p: DASH_SENT.append(k) or {"seal_id": 77, "now_utc": utcnow()}
cycle.execute = lambda w, k, p: CYCLE_SENT.append((k, p.get("hash"))) or {
    "seal_id": 78, "now_utc": utcnow(), "unsigned_because": "the signer could not run: no sudo here"}
class W:
    def __init__(self, *a, **k): pass
dash.Writer = W
dash.request_cycle_run = lambda *a, **k: None
class H(dash.Handler): pass
H.state, H.cfg = st, cfg
h = H.__new__(H); h._update_card = lambda *a, **k: None; h._local_time = lambda: "now"; h.run_cycle = lambda *a, **k: None
SHA = "ab" * 32
aid = st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'seal','witness',?,'r','queued')",
                    (utcnow(), json.dumps({"library_id": 1, "hash": SHA, "label": "receipts-run"}))).lastrowid
st.db.commit(); h.decide(aid, "approve"); time.sleep(0.8)
r = st.db.execute("SELECT status, response FROM actions WHERE id=?", (aid,)).fetchone()
print(f"  dashboard sent: {', '.join(DASH_SENT) or 'nothing'} | status {r[0]!r}, send by the cycle: "
      f"{json.loads(r[1] or '{}').get('send_by') == 'cycle'}")
ghost = st.db.execute("INSERT INTO actions (cycle_id,created_at,kind,drive,payload,rationale,status) VALUES (1,?,'seal','witness',?,'r','approved')",
                      (utcnow(), json.dumps({"library_id": 2, "hash": "cd" * 32, "label": "ghost"}))).lastrowid
st.db.commit()
cycle._send_approved_signed(st, W(), st.log)
r = st.db.execute("SELECT status FROM actions WHERE id=?", (aid,)).fetchone()
j = st.db.execute("SELECT COUNT(*) FROM journal WHERE text LIKE '%UNSIGNED%'").fetchone()[0]
m = st.db.execute("SELECT COUNT(*) FROM messages WHERE content LIKE '%went out unsigned%'").fetchone()[0]
print(f"  cycle sent: {', '.join(k for k, _ in CYCLE_SENT if _ == SHA) or 'nothing'} | status {r[0]!r} | "
      f"journal warning {bool(j)}, chat report {bool(m)}")
print(f"  an approved row without the mark was sent: {any(h_ == 'cd' * 32 for _, h_ in CYCLE_SENT)}")
src = open(os.path.join(sys.argv[1], "agent/cycle.py")).read()
print(f"  situation still says sign does seals: {'seal fingerprints a' in src}")
